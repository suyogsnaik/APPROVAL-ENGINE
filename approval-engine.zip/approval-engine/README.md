# HSBC Corporate Digital Channels — Approval Engine

A Java / Spring Boot implementation of the file-based payments **Approval Engine**: it decides
who can approve a File / Batch / Payment, enforces Category, Signatory Group, Amount Tier,
Random/Sequential sequencing, Dual Control (Maker-Checker) and Self-Approval rules, and releases
a fully-approved File to the Back Office.

Built from `PRD_BENEAPPROVAL.docx` and `BENEAPPROVAL2.docx` (PRD + MRS + architecture pack +
API spec + DB schema + UAT pack + delivery plan). Scope covers all 6 epics in the backlog:
Policy Configuration, Entitlement & Signatory Groups, File Processing, Approval Engine Core,
Audit + Dashboard API, and Back Office release — everything **except** a graphical UI, which
was out of scope for a backend engine and is left to a separate frontend consuming these APIs.

## ⚠️ About this build

This was written in a sandboxed environment whose network policy blocks Maven Central, so
**`mvn compile` / `mvn test` could not actually be run here.** The full source tree was reviewed
by hand and with `javac`'s parser (no classpath) to rule out real syntax errors — the only errors
that surfaced were the expected "package does not exist" ones for Spring/Jakarta/Lombok, which
aren't on the classpath in this sandbox. One real bug *was* caught this way and fixed: a
constructor-injection circular dependency between `ChangeRequestService` and the setup services
(see `ChangeRequestService`'s Javadoc for the fix). You should still run the build yourself before
relying on it — see below — since manual review is not a substitute for `mvn test` actually
passing.

## Running it

Requires JDK 21 and Maven, with normal internet access to Maven Central.

```bash
mvn spring-boot:run
```

Starts on `http://localhost:8080` with an in-memory H2 database, auto-seeded with demo data
(see below). H2 console: `http://localhost:8080/h2-console` (JDBC URL `jdbc:h2:mem:approvaldb`,
user `sa`, empty password).

```bash
mvn test
```

Runs the UAT-pack test suite (see **Test coverage** below).

## Architecture

```
domain/entity, domain/enums   JPA entities matching the DB schema in the spec
repository                    Spring Data JPA repositories
service/setup                 Epics 1-2: Categories, Tiers, Combinations, Account/Beneficiary/
                               Group Policies, Signatory Groups, Entitlements, Self-Approval —
                               every mutation goes through Maker-Checker
service/makerchecker           Generic dual-control engine (ChangeRequestService + ChangeApplier)
service/fileprocessing         Epic 3: file upload, CSV/XML parsing, Batch Builder, Payment Mapper
service/engine                 Epic 4: Policy/Tier/Combination Resolvers, Entitlement Validator,
                               Sequence Engine, Approval Capture, Dashboard, Status queries
service/backoffice             Epic 6: release-to-Back-Office stub
service/audit                  Epic 5: audit log writer
controller/*                   REST surface, one controller family per epic
config/DemoDataSeeder          Seeds a coherent demo dataset (client CLIENT1, account ACC1)
exception/*                    Typed exceptions + a @RestControllerAdvice mapping them to HTTP
```

### Data model

Mirrors the SQL schema in the spec closely, with two intentional simplifications, both noted
inline in the code:

- `tier_combination_categories` / `tier_combination_sign_groups` join tables are modelled as
  `@ElementCollection Set<String>` on `TierCombination` rather than separate join entities —
  same relational shape, less boilerplate.
- A combination's Category and Signatory Group requirements are evaluated under one shared
  AND/OR flag rather than two independent ones, since every example in the spec used one axis
  at a time (either a Category-only combo like "Cat A OR Cat B", or a Signatory-Group-only
  sequential combo like "G1 + G2"). Both axes can still be populated together if a future policy
  needs it.
- `users` is mapped to table `app_users` (entity `AppUser`) because `USER` is a reserved word in
  H2 and several other SQL dialects.

### Policy Resolution

Beneficiary policy \> Beneficiary Group policy \> Account policy (fallback), exactly per MRS
2.3.1. Once a level is found to have *any* active rule for the Beneficiary, it owns the decision
outright — it does not silently fall through to a lower level just because that level lacks a
rule for the payment's specific tier (this is what TC1 in the UAT pack requires); in that edge
case resolution fails loudly with a `ValidationException` instead.

A tier can have **multiple** applicable combinations (the "up to 8 OR-based combinations per
tier" from the spec) — `Payment.appliedCombinationIds` stores all of them, and the payment is
fully approved the moment **any one** of them is satisfied (its own AND/OR logic having been
met by the approvals captured so far).

### Approval Sequence

`SequenceEngineService` enforces Sequential mode: a Signatory Group can only sign once every
group with a lower `sequenceOrder` in the same combination has already signed. Random mode
(the default) enforces nothing.

## API summary

All bodies are JSON. `makerId` / `performedBy` / `uploadedBy` are passed as query params since
there's no auth layer in this build.

| Method & path | Purpose |
|---|---|
| `POST /setup/category` (+ `PUT/DELETE /{id}`) | Categories A-N |
| `POST /setup/tier` (+ `PUT/DELETE /{id}`) | Limit Tiers |
| `POST /setup/combination` (+ `PUT/DELETE /{id}`) | AND/OR combinations per tier |
| `POST /setup/signatory-group` (+ `PUT/DELETE /{id}`), `POST /setup/signatory-group/assign` | Signatory Groups + user assignment |
| `POST /setup/account-policy` (+ `PUT/DELETE /{id}`) | Account-level policy |
| `POST /setup/beneficiary-policy`, `POST /setup/beneficiary-group-policy` | Beneficiary / Group policy |
| `POST /setup/entitlement` | Account entitlements (ONE/MULTIPLE/ALL) |
| `POST /setup/user-category` | Assign a Category to a user |
| `POST /setup/self-approval` (+ `GET /{clientId}`) | Self-approval restriction toggle |
| `POST /setup/beneficiary`, `POST /setup/beneficiary-group` | Beneficiary maintenance |
| `POST /setup/user` | User provisioning (outside Maker-Checker — see code comment) |
| `GET /setup/change-requests`, `POST /{id}/approve`, `POST /{id}/reject` | Maker-Checker inbox |
| `POST /file/upload` | Upload a CSV/XML payment file |
| `GET /file/{fileId}/status`, `GET /file/{fileId}`, `GET /file/{fileId}/batches`, `GET /batch/{batchId}/payments` | File/Batch/Payment status |
| `POST /approval/policy/resolve` | Policy Resolution API (spec 3.1) |
| `POST /approval/validate` | Entitlement Validation API (spec 3.2) |
| `POST /approval/capture` | Capture Approval API (spec 3.3) |
| `GET /dashboard/pending/{userId}` | Approval Dashboard |
| `GET /audit?entityType=&entityId=` | Audit log query |

Every setup mutation returns a `ChangeRequestResponse` (`PENDING`) rather than applying
immediately — it only takes effect once a *different* user calls the approve endpoint.

### Example flow

```bash
# 1. Upload a payment file (uses seeded demo data — see below)
curl -s -X POST http://localhost:8080/file/upload -H 'Content-Type: application/json' -d '{
  "clientId": "CLIENT1", "fileName": "batch1.csv", "format": "csv", "uploadedBy": "USR-MGR",
  "content": "debitAccountId,beneficiaryId,amount,currency\nACC1,BEN-PLAIN,15000,USD"
}'

# 2. Check what's pending for a would-be approver
curl -s http://localhost:8080/dashboard/pending/USR-MGR

# 3. Validate then capture an approval
curl -s -X POST http://localhost:8080/approval/validate -H 'Content-Type: application/json' \
  -d '{"userId":"USR-MGR","paymentId":"<paymentId from step 2>"}'
curl -s -X POST "http://localhost:8080/approval/capture?performedBy=USR-MGR" \
  -H 'Content-Type: application/json' -d '{"userId":"USR-MGR","paymentId":"<paymentId>"}'

# 4. Once every payment/batch is approved the file auto-releases to Back Office
curl -s http://localhost:8080/file/<fileId>/status
```

## Demo data (`DemoDataSeeder`)

Seeded automatically on first start-up (idempotent; disable with
`approval-engine.seed-demo-data=false`):

- Client `CLIENT1`, debit account `ACC1` (self-approval restriction ON)
- Categories `A` (CFO), `B` (Finance Manager), `C` (Supervisor)
- Signatory Groups `G1` (stage 1), `G2` (stage 2)
- Tiers: `Tier1` [0, 5000), `Tier2` [5000, 20000), `Tier3` [20000, 1000000) USD
- Account policy on `ACC1`: Tier1 → Cat A OR B, Tier2 → Cat B, Tier3 → Cat A AND B
- `BEN001` (Supplier Group `GRP01`, group policy Tier2 → Cat C), created by `USR-MGR`
- `BEN-PLAIN` (no group/policy → falls back to the account policy), created by `USR-CFO`
- `BEN-SEQ` (beneficiary-level policy Tier2 → Sequential G1 then G2), created by `USR-CFO`
- Users: `USR-CFO` (Cat A), `USR-MGR` (Cat B), `USR-SUP` (Cat C), `USR-G1`/`USR-G2` (in G1/G2),
  `USR-NOENT` (Cat B, deliberately **not** entitled to `ACC1`)

## Test coverage

`src/test/java/com/hsbc/approvalengine`, all built on the seeded demo data above:

- `PolicyResolutionTest` — TC1-TC4 (Beneficiary/Group/Account hierarchy, tier selection)
- `EntitlementValidationTest` — TC5-TC8 (category/sign-group mismatch, account entitlement,
  self-approval)
- `SequenceAndCaptureTest` — TC9-TC11 (Random any-order, Sequential ordering + rejection)
- `FileBatchCascadeTest` — TC12-TC14 (Payment → Batch → File cascading, Back Office release)
- `AuditAndMakerCheckerTest` — TC15-TC16 (audit trail) + Maker-Checker segregation of duties
- `FileProcessingServiceTest` — CSV/XML parsing, Batch Builder, missing-beneficiary exception
  handling
- `ApplicationContextTest` — full Spring context wiring smoke test

## Out of scope (per PRD)

ERP/TMS integrations, FX logic, multi-currency tiering, workflow orchestration beyond approval
routing, and any graphical UI (the Approval Dashboard is exposed as `GET /dashboard/pending/{id}`
only — a frontend would consume it). The Back Office integration is a stub that always
acknowledges immediately; wiring a real payment execution platform behind
`BackOfficeService.releaseIfFullyApproved` was explicitly out of scope.
