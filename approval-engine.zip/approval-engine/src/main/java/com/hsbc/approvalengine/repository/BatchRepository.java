package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.Batch;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BatchRepository extends JpaRepository<Batch, String> {
    List<Batch> findByFile_Id(String fileId);
}
