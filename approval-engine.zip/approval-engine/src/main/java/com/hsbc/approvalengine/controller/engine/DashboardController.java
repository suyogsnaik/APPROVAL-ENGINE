package com.hsbc.approvalengine.controller.engine;

import com.hsbc.approvalengine.dto.engine.DashboardItem;
import com.hsbc.approvalengine.service.engine.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Feature 5.1 - GET /dashboard/pending/{userId}: US36-38. */
@RestController
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/dashboard/pending/{userId}")
    public List<DashboardItem> pending(@PathVariable String userId) {
        return dashboardService.pendingFor(userId);
    }
}
