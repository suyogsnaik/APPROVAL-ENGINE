package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.dto.engine.DashboardItem;
import com.hsbc.approvalengine.dto.engine.EligibilityResult;
import com.hsbc.approvalengine.dto.engine.PolicyResolveResponse;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.repository.TierCombinationRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Feature 5.1 - Approval Dashboard: what a given user currently has open to approve. */
@Service
@RequiredArgsConstructor
public class DashboardService {

    private final AppUserRepository appUserRepository;
    private final PaymentRepository paymentRepository;
    private final TierCombinationRepository tierCombinationRepository;
    private final EntitlementValidatorService entitlementValidatorService;

    public List<DashboardItem> pendingFor(String userId) {
        AppUser user = appUserRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found: " + userId));

        List<Payment> pending = paymentRepository.findByStatus(PaymentStatus.PENDING);
        pending.addAll(paymentRepository.findByStatus(PaymentStatus.PARTIALLY_APPROVED));

        return pending.stream().map(p -> toItem(user, p)).toList();
    }

    private DashboardItem toItem(AppUser user, Payment payment) {
        EligibilityResult result = entitlementValidatorService.validate(user, payment);
        var combos = tierCombinationRepository.findAllById(payment.getAppliedCombinationIds()).stream()
                .map(c -> new PolicyResolveResponse.RequiredCombination(
                        c.getId(), c.getCombinationType().name(), c.getCategoryIds().stream().toList(),
                        c.getSignatoryGroupIds().stream().toList()))
                .toList();

        return new DashboardItem(
                payment.getBatch().getFile().getId(),
                payment.getBatch().getId(),
                payment.getId(),
                payment.getBatch().getDebitAccountId(),
                payment.getBeneficiary() != null ? payment.getBeneficiary().getId() : null,
                payment.getAmount(),
                payment.getCurrency(),
                payment.getStatus(),
                combos,
                result.eligible(),
                result.violations()
        );
    }
}
