package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.domain.enums.BatchStatus;
import com.hsbc.approvalengine.domain.enums.FileStatus;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.dto.file.FileStatusResponse;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.repository.BatchRepository;
import com.hsbc.approvalengine.repository.PaymentFileRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/** GET /file/{fileId}/status (API spec 3.4). */
@Service
@RequiredArgsConstructor
public class StatusQueryService {

    private final PaymentFileRepository paymentFileRepository;
    private final BatchRepository batchRepository;
    private final PaymentRepository paymentRepository;

    public FileStatusResponse fileStatus(String fileId) {
        PaymentFile file = paymentFileRepository.findById(fileId)
                .orElseThrow(() -> new NotFoundException("File not found: " + fileId));

        var batches = batchRepository.findByFile_Id(fileId);
        var payments = paymentRepository.findByBatch_File_Id(fileId);

        long batchesApproved = batches.stream().filter(b -> b.getStatus() == BatchStatus.APPROVED).count();
        long paymentsApproved = payments.stream().filter(p -> p.getStatus() == PaymentStatus.APPROVED).count();
        long paymentsException = payments.stream().filter(p -> p.getStatus() == PaymentStatus.EXCEPTION).count();

        return new FileStatusResponse(
                file.getId(), file.getStatus(),
                (int) batchesApproved, batches.size(),
                (int) paymentsApproved, payments.size(),
                (int) paymentsException,
                file.getStatus() == FileStatus.APPROVED || file.getStatus() == FileStatus.RELEASED
        );
    }
}
