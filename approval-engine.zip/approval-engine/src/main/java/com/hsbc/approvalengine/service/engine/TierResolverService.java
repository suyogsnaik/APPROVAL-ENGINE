package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.LimitTierRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

/**
 * Feature 4.2 - Tier Resolution: identifies the {@link LimitTier} whose [min, max) band contains
 * a payment amount. MRS NFR 3.1 requires this to complete in &lt;100ms; a simple in-memory scan
 * over at most 6 configured tiers comfortably meets that.
 */
@Service
@RequiredArgsConstructor
public class TierResolverService {

    private final LimitTierRepository limitTierRepository;

    public LimitTier resolveTier(BigDecimal amount, String currency) {
        List<LimitTier> tiers = limitTierRepository.findAllByOrderByRankOrderAsc();
        Optional<LimitTier> match = tiers.stream()
                .filter(t -> t.getCurrency() == null || t.getCurrency().equalsIgnoreCase(currency))
                .filter(t -> amount.compareTo(t.getMinAmount()) >= 0)
                .filter(t -> t.getMaxAmount() == null || amount.compareTo(t.getMaxAmount()) < 0)
                // narrowest band first in case of overlapping configuration
                .min(Comparator.comparing(t -> rangeWidth(t)));
        return match.orElseThrow(() -> new ValidationException(
                "No Limit Tier configured for amount " + amount + " " + currency));
    }

    private BigDecimal rangeWidth(LimitTier t) {
        if (t.getMaxAmount() == null) {
            return BigDecimal.valueOf(Long.MAX_VALUE);
        }
        return t.getMaxAmount().subtract(t.getMinAmount());
    }
}
