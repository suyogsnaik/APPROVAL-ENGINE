package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.AccountEntitlement;
import com.hsbc.approvalengine.domain.entity.AccountEntitlementId;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.EntitlementType;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.AccountEntitlementRequest;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.AccountEntitlementRepository;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Feature 2.2 - Account Entitlements: which Debit Account(s) a user may operate on/approve for. */
@Service
@RequiredArgsConstructor
public class AccountEntitlementService implements ChangeApplier {

    private final AccountEntitlementRepository repository;
    private final AppUserRepository appUserRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<AccountEntitlement> findByUser(String userId) {
        return repository.findById_UserId(userId);
    }

    public boolean isEntitled(String userId, String debitAccountId) {
        List<AccountEntitlement> entitlements = repository.findById_UserId(userId);
        return entitlements.stream().anyMatch(e ->
                e.getEntitlementType() == EntitlementType.ALL
                        || e.getId().getDebitAccountId().equals(debitAccountId));
    }

    public ChangeRequest requestUpsert(AccountEntitlementRequest request, String makerId) {
        if (!appUserRepository.existsById(request.userId())) {
            throw new ValidationException("Unknown userId: " + request.userId());
        }
        String entityId = request.userId() + ":" + request.debitAccountId();
        return changeRequestService.submit(SetupEntityType.ACCOUNT_ENTITLEMENT, entityId, ChangeAction.CREATE, request, makerId);
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.ACCOUNT_ENTITLEMENT;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        upsert(payload);
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        upsert(payload);
    }

    @Override
    public void applyDelete(String entityId) {
        String[] parts = entityId.split(":", 2);
        repository.deleteById(new AccountEntitlementId(parts[0], parts[1]));
    }

    private void upsert(JsonNode payload) {
        AccountEntitlementRequest r = objectMapper.convertValue(payload, AccountEntitlementRequest.class);
        repository.save(AccountEntitlement.builder()
                .id(new AccountEntitlementId(r.userId(), r.debitAccountId()))
                .entitlementType(r.entitlementType())
                .build());
    }
}
