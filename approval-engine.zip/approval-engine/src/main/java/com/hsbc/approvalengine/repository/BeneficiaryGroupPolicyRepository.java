package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.BeneficiaryGroupPolicy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BeneficiaryGroupPolicyRepository extends JpaRepository<BeneficiaryGroupPolicy, String> {
    List<BeneficiaryGroupPolicy> findByBeneficiaryGroup_IdAndActiveTrue(String beneficiaryGroupId);
    List<BeneficiaryGroupPolicy> findByBeneficiaryGroup_IdAndTier_IdAndActiveTrue(String beneficiaryGroupId, String tierId);
}
