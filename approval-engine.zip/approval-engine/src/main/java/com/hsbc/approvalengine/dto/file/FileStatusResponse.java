package com.hsbc.approvalengine.dto.file;

import com.hsbc.approvalengine.domain.enums.FileStatus;

/** GET /file/{fileId}/status response, matching API spec 3.4. */
public record FileStatusResponse(
        String fileId,
        FileStatus status,
        int batchesApproved,
        int batchesTotal,
        int paymentsApproved,
        int paymentsTotal,
        int paymentsException,
        boolean isFullyApproved
) {
}
