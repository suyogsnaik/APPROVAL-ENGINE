package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.AccountPolicy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountPolicyRepository extends JpaRepository<AccountPolicy, String> {
    List<AccountPolicy> findByDebitAccountIdAndActiveTrue(String debitAccountId);
    List<AccountPolicy> findByDebitAccountIdAndTier_IdAndActiveTrue(String debitAccountId, String tierId);
}
