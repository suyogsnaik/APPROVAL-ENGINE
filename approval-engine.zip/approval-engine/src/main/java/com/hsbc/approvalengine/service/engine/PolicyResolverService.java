package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.AccountPolicy;
import com.hsbc.approvalengine.domain.entity.Beneficiary;
import com.hsbc.approvalengine.domain.entity.BeneficiaryGroupPolicy;
import com.hsbc.approvalengine.domain.entity.BeneficiaryPolicy;
import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.domain.enums.PolicyType;
import com.hsbc.approvalengine.dto.engine.ResolvedPolicy;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.AccountPolicyRepository;
import com.hsbc.approvalengine.repository.BeneficiaryGroupPolicyRepository;
import com.hsbc.approvalengine.repository.BeneficiaryPolicyRepository;
import com.hsbc.approvalengine.repository.BeneficiaryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/**
 * Feature 4.1 - Policy Resolution (MRS 2.3.1). Walks the hierarchy Beneficiary -&gt; Beneficiary
 * Group -&gt; Account (fallback), then resolves the Tier for the payment amount and returns the
 * OR-set of required Category/Signatory-Group combinations for that (policy level, tier) pair.
 *
 * <p>Once a policy level is found to apply to a Beneficiary (i.e. it has at least one active rule
 * defined, for any tier), that level owns the decision - PolicyResolver does not fall through to
 * a lower-priority level just because that level lacks a rule for this specific tier: TC1 in the
 * UAT pack requires the Beneficiary policy to win outright.</p>
 */
@Service
@RequiredArgsConstructor
public class PolicyResolverService {

    private final BeneficiaryRepository beneficiaryRepository;
    private final BeneficiaryPolicyRepository beneficiaryPolicyRepository;
    private final BeneficiaryGroupPolicyRepository beneficiaryGroupPolicyRepository;
    private final AccountPolicyRepository accountPolicyRepository;
    private final TierResolverService tierResolverService;

    public ResolvedPolicy resolve(String debitAccountId, String beneficiaryId, BigDecimal amount, String currency) {
        LimitTier tier = tierResolverService.resolveTier(amount, currency);

        Beneficiary beneficiary = beneficiaryId == null ? null :
                beneficiaryRepository.findById(beneficiaryId).orElse(null);

        // 1. Beneficiary-level policy (highest priority).
        if (beneficiary != null && !beneficiaryPolicyRepository.findByBeneficiary_IdAndActiveTrue(beneficiaryId).isEmpty()) {
            List<BeneficiaryPolicy> rows = beneficiaryPolicyRepository
                    .findByBeneficiary_IdAndTier_IdAndActiveTrue(beneficiaryId, tier.getId());
            if (rows.isEmpty()) {
                throw new ValidationException("Beneficiary " + beneficiaryId
                        + " has an active Beneficiary-level policy but none defined for tier " + tier.getId());
            }
            return new ResolvedPolicy(PolicyType.BENEFICIARY, beneficiaryId, tier,
                    rows.stream().map(BeneficiaryPolicy::getCombination).toList());
        }

        // 2. Beneficiary Group-level policy (fallback #1).
        String groupId = beneficiary != null && beneficiary.getGroup() != null ? beneficiary.getGroup().getId() : null;
        if (groupId != null && !beneficiaryGroupPolicyRepository.findByBeneficiaryGroup_IdAndActiveTrue(groupId).isEmpty()) {
            List<BeneficiaryGroupPolicy> rows = beneficiaryGroupPolicyRepository
                    .findByBeneficiaryGroup_IdAndTier_IdAndActiveTrue(groupId, tier.getId());
            if (rows.isEmpty()) {
                throw new ValidationException("Beneficiary Group " + groupId
                        + " has an active policy but none defined for tier " + tier.getId());
            }
            return new ResolvedPolicy(PolicyType.BENEFICIARY_GROUP, groupId, tier,
                    rows.stream().map(BeneficiaryGroupPolicy::getCombination).toList());
        }

        // 3. Account-level policy (final fallback).
        List<AccountPolicy> rows = accountPolicyRepository.findByDebitAccountIdAndTier_IdAndActiveTrue(debitAccountId, tier.getId());
        if (rows.isEmpty()) {
            throw new ValidationException("No Account-level policy defined for debit account " + debitAccountId
                    + " at tier " + tier.getId());
        }
        return new ResolvedPolicy(PolicyType.ACCOUNT, debitAccountId, tier,
                rows.stream().map(AccountPolicy::getCombination).toList());
    }
}
