package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.BeneficiaryPolicy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BeneficiaryPolicyRepository extends JpaRepository<BeneficiaryPolicy, String> {
    List<BeneficiaryPolicy> findByBeneficiary_IdAndActiveTrue(String beneficiaryId);
    List<BeneficiaryPolicy> findByBeneficiary_IdAndTier_IdAndActiveTrue(String beneficiaryId, String tierId);
}
