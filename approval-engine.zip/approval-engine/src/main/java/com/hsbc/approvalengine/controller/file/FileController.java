package com.hsbc.approvalengine.controller.file;

import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.dto.file.FileStatusResponse;
import com.hsbc.approvalengine.dto.file.FileUploadRequest;
import com.hsbc.approvalengine.repository.BatchRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.service.engine.StatusQueryService;
import com.hsbc.approvalengine.service.fileprocessing.FileProcessingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Epic 3 - File Upload / Status APIs. */
@RestController
@RequiredArgsConstructor
public class FileController {

    private final FileProcessingService fileProcessingService;
    private final StatusQueryService statusQueryService;
    private final BatchRepository batchRepository;
    private final PaymentRepository paymentRepository;

    @PostMapping("/file/upload")
    public PaymentFile upload(@Valid @RequestBody FileUploadRequest request) {
        return fileProcessingService.uploadAndProcess(
                request.clientId(), request.fileName(), request.format(), request.content(), request.uploadedBy());
    }

    @GetMapping("/file/{fileId}/status")
    public FileStatusResponse status(@PathVariable String fileId) {
        return statusQueryService.fileStatus(fileId);
    }

    @GetMapping("/file/{fileId}")
    public PaymentFile get(@PathVariable String fileId) {
        return fileProcessingService.findFile(fileId);
    }

    @GetMapping("/file/{fileId}/batches")
    public List<Batch> batches(@PathVariable String fileId) {
        return batchRepository.findByFile_Id(fileId);
    }

    @GetMapping("/batch/{batchId}/payments")
    public List<Payment> payments(@PathVariable String batchId) {
        return paymentRepository.findByBatch_Id(batchId);
    }
}
