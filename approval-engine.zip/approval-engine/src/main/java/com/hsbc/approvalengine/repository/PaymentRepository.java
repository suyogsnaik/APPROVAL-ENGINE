package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, String> {
    List<Payment> findByBatch_Id(String batchId);
    List<Payment> findByBatch_File_Id(String fileId);
    List<Payment> findByStatus(PaymentStatus status);
}
