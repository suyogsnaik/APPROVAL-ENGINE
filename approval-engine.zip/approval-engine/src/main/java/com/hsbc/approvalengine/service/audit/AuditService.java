package com.hsbc.approvalengine.service.audit;

import com.hsbc.approvalengine.domain.entity.AuditLog;
import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * Writes immutable {@link AuditLog} entries. Per MRS 2.6 / PRD 5.5, every setup change
 * (Maker-Checker), beneficiary creation/edit, approval action, applied policy and exception
 * must be logged with who / when / what.
 */
@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    /** Runs in its own transaction so an audit entry for an exception survives a rollback. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(SetupEntityType entityType, String entityId, AuditAction action, String performedBy, String details) {
        AuditLog log = AuditLog.builder()
                .id("AUD-" + UUID.randomUUID())
                .entityType(entityType)
                .entityId(entityId)
                .action(action)
                .performedBy(performedBy)
                .details(details)
                .build();
        auditLogRepository.save(log);
    }
}
