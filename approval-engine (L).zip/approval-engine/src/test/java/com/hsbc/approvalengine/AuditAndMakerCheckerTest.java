package com.hsbc.approvalengine;

import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.LimitTierRequest;
import com.hsbc.approvalengine.exception.MakerCheckerException;
import com.hsbc.approvalengine.repository.AuditLogRepository;
import com.hsbc.approvalengine.service.engine.ApprovalCaptureService;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import com.hsbc.approvalengine.service.setup.LimitTierService;
import com.hsbc.approvalengine.support.AbstractEngineTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** UAT pack section E - Audit & Logging (TC15-TC16), plus Maker-Checker segregation of duties. */
class AuditAndMakerCheckerTest extends AbstractEngineTest {

    @Autowired
    private LimitTierService limitTierService;
    @Autowired
    private ChangeRequestService changeRequestService;
    @Autowired
    private AuditLogRepository auditLogRepository;
    @Autowired
    private ApprovalCaptureService approvalCaptureService;

    @Test
    void tc15_policyChangeAudit_makerSubmitsCheckerApproves() {
        LimitTierRequest update = new LimitTierRequest("Tier1", BigDecimal.ZERO, BigDecimal.valueOf(5000), "USD", 1);

        ChangeRequest cr = limitTierService.requestUpdate("Tier1", update, "USR-MGR");
        changeRequestService.approve(cr.getId(), "USR-CFO", "looks fine");

        var entries = auditLogRepository.findByEntityTypeAndEntityIdOrderByPerformedAtDesc(SetupEntityType.LIMIT_TIER, "Tier1");
        assertThat(entries).anySatisfy(e -> assertThat(e.getAction()).isEqualTo(AuditAction.SUBMIT_FOR_APPROVAL));
        assertThat(entries).anySatisfy(e -> {
            assertThat(e.getAction()).isEqualTo(AuditAction.APPROVE);
            assertThat(e.getPerformedBy()).isEqualTo("USR-CFO");
        });
    }

    @Test
    void makerCheckerSegregationOfDuties_checkerCannotEqualMaker() {
        LimitTierRequest update = new LimitTierRequest("Tier1", BigDecimal.ZERO, BigDecimal.valueOf(5000), "USD", 1);
        ChangeRequest cr = limitTierService.requestUpdate("Tier1", update, "USR-MGR");

        assertThatThrownBy(() -> changeRequestService.approve(cr.getId(), "USR-MGR", "self-approving my own change"))
                .isInstanceOf(MakerCheckerException.class);
    }

    @Test
    void tc16_approvalActionAudit() {
        Payment payment = createResolvedPayment("ACC1", "BEN-PLAIN", BigDecimal.valueOf(10000), "USD");

        approvalCaptureService.capture("USR-MGR", payment.getId(), "USR-MGR");

        var entries = auditLogRepository.findByEntityTypeAndEntityIdOrderByPerformedAtDesc(SetupEntityType.PAYMENT, payment.getId());
        assertThat(entries).anySatisfy(e -> {
            assertThat(e.getAction()).isEqualTo(AuditAction.CAPTURE_APPROVAL);
            assertThat(e.getPerformedBy()).isEqualTo("USR-MGR");
        });
    }
}
