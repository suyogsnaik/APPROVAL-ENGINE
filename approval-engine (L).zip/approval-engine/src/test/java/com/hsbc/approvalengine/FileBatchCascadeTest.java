package com.hsbc.approvalengine;

import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.domain.enums.BatchStatus;
import com.hsbc.approvalengine.domain.enums.FileStatus;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.service.engine.ApprovalCaptureService;
import com.hsbc.approvalengine.support.AbstractEngineTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/** UAT pack section D - File/Batches/Payments cascading (TC12-TC14). */
class FileBatchCascadeTest extends AbstractEngineTest {

    @Autowired
    private ApprovalCaptureService approvalCaptureService;

    @Test
    void tc12_tc13_tc14_cascadeThroughPaymentBatchFileToBackOfficeRelease() {
        PaymentFile file = createFile();
        Batch batch = addBatch(file, "ACC1");
        // Both payments fall into Tier2 -> Account policy requires just Category B (OR).
        Payment payment1 = addPayment(batch, "BEN-PLAIN", BigDecimal.valueOf(10000), "USD");
        Payment payment2 = addPayment(batch, "BEN-PLAIN", BigDecimal.valueOf(12000), "USD");

        // TC12 - partial: only payment1 approved so far.
        approvalCaptureService.capture("USR-MGR", payment1.getId(), "TEST");
        assertThat(reload(payment1).getStatus()).isEqualTo(PaymentStatus.APPROVED);
        assertThat(reload(payment2).getStatus()).isEqualTo(PaymentStatus.PENDING);
        assertThat(reload(batch).getStatus()).isEqualTo(BatchStatus.IN_APPROVAL);
        assertThat(reload(file).getStatus()).isEqualTo(FileStatus.IN_APPROVAL);

        // TC13 - approve the remaining payment -> batch fully approved.
        approvalCaptureService.capture("USR-MGR", payment2.getId(), "TEST");
        assertThat(reload(payment2).getStatus()).isEqualTo(PaymentStatus.APPROVED);
        assertThat(reload(batch).getStatus()).isEqualTo(BatchStatus.APPROVED);

        // TC14 - the file's only batch is now approved -> file approved and released to Back Office.
        PaymentFile finalFile = reload(file);
        assertThat(finalFile.getStatus()).isEqualTo(FileStatus.RELEASED);
        assertThat(finalFile.getBackOfficeAck()).isNotBlank();
        assertThat(finalFile.getReleasedAt()).isNotNull();
    }
}
