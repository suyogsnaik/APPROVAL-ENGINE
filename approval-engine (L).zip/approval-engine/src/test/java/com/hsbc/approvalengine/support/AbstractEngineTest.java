package com.hsbc.approvalengine.support;

import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.domain.entity.Beneficiary;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.domain.enums.BatchStatus;
import com.hsbc.approvalengine.domain.enums.FileStatus;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.dto.engine.ResolvedPolicy;
import com.hsbc.approvalengine.repository.BatchRepository;
import com.hsbc.approvalengine.repository.BeneficiaryRepository;
import com.hsbc.approvalengine.repository.PaymentFileRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.service.engine.PolicyResolverService;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Base class for engine tests. Each test runs inside a transaction that rolls back afterwards,
 * so every test starts from the same {@code DemoDataSeeder} baseline (CLIENT1 / ACC1 / categories
 * A-C / tiers Tier1-3 / users USR-CFO,USR-MGR,USR-SUP,USR-G1,USR-G2,USR-NOENT / beneficiaries
 * BEN001, BEN-PLAIN, BEN-SEQ) regardless of what earlier tests captured.
 */
@ExtendWith(SpringExtension.class)
@SpringBootTest
@Transactional
public abstract class AbstractEngineTest {

    @Autowired
    protected PaymentFileRepository paymentFileRepository;
    @Autowired
    protected BatchRepository batchRepository;
    @Autowired
    protected PaymentRepository paymentRepository;
    @Autowired
    protected BeneficiaryRepository beneficiaryRepository;
    @Autowired
    protected PolicyResolverService policyResolverService;

    protected PaymentFile createFile() {
        PaymentFile file = PaymentFile.builder()
                .id("FILE-" + UUID.randomUUID()).clientId("CLIENT1").fileName("test.csv")
                .status(FileStatus.IN_APPROVAL).build();
        return paymentFileRepository.save(file);
    }

    protected Batch addBatch(PaymentFile file, String debitAccountId) {
        Batch batch = Batch.builder()
                .id("BATCH-" + UUID.randomUUID()).file(file).debitAccountId(debitAccountId)
                .status(BatchStatus.IN_APPROVAL).build();
        return batchRepository.save(batch);
    }

    protected Payment addPayment(Batch batch, String beneficiaryId, BigDecimal amount, String currency) {
        Beneficiary beneficiary = beneficiaryRepository.findById(beneficiaryId).orElseThrow();
        Payment payment = Payment.builder()
                .id("PAY-" + UUID.randomUUID()).batch(batch).beneficiary(beneficiary)
                .amount(amount).currency(currency).status(PaymentStatus.PENDING).build();

        ResolvedPolicy resolved = policyResolverService.resolve(batch.getDebitAccountId(), beneficiaryId, amount, currency);
        payment.setAppliedPolicyType(resolved.policyType());
        payment.setAppliedPolicyId(resolved.policyId());
        payment.setAppliedTier(resolved.tier());
        payment.setAppliedCombinationIds(resolved.combinations().stream()
                .map(c -> c.getId()).collect(Collectors.toSet()));
        return paymentRepository.save(payment);
    }

    /** Builds a single-payment File -> Batch -> Payment chain and runs Policy Resolution, like FileProcessingService would. */
    protected Payment createResolvedPayment(String debitAccountId, String beneficiaryId, BigDecimal amount, String currency) {
        PaymentFile file = createFile();
        Batch batch = addBatch(file, debitAccountId);
        return addPayment(batch, beneficiaryId, amount, currency);
    }

    protected Payment reload(Payment payment) {
        return paymentRepository.findById(payment.getId()).orElseThrow();
    }

    protected Batch reload(Batch batch) {
        return batchRepository.findById(batch.getId()).orElseThrow();
    }

    protected PaymentFile reload(PaymentFile file) {
        return paymentFileRepository.findById(file.getId()).orElseThrow();
    }
}
