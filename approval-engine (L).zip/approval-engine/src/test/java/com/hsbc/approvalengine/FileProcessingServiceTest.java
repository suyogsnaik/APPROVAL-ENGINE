package com.hsbc.approvalengine;

import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.domain.enums.FileStatus;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.service.fileprocessing.FileProcessingService;
import com.hsbc.approvalengine.support.AbstractEngineTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** Epic 3 - File Upload / Batch Builder / Payment Mapper (US23-27), covering CSV, XML and the Missing-Beneficiary exception path. */
class FileProcessingServiceTest extends AbstractEngineTest {

    @Autowired
    private FileProcessingService fileProcessingService;
    @Autowired
    private PaymentRepository paymentRepository;

    @Test
    void uploadsCsvFile_groupsIntoOneBatchPerDebitAccount_andResolvesPolicyPerPayment() {
        String csv = """
                debitAccountId,beneficiaryId,amount,currency
                ACC1,BEN-PLAIN,1000,USD
                ACC1,BEN-PLAIN,15000,USD
                """;

        PaymentFile file = fileProcessingService.uploadAndProcess("CLIENT1", "batch1.csv", "csv", csv, "USR-MGR");

        assertThat(file.getStatus()).isEqualTo(FileStatus.IN_APPROVAL);
        var payments = paymentRepository.findByBatch_File_Id(file.getId());
        assertThat(payments).hasSize(2);
        assertThat(payments).allSatisfy(p -> assertThat(p.getStatus()).isEqualTo(PaymentStatus.PENDING));
        assertThat(payments).allSatisfy(p -> assertThat(p.getAppliedTier()).isNotNull());
    }

    @Test
    void uploadsXmlFile_equivalentToCSv() {
        String xml = """
                <PaymentFile>
                  <Payment debitAccountId="ACC1" beneficiaryId="BEN-PLAIN" amount="1000" currency="USD"/>
                </PaymentFile>
                """;

        PaymentFile file = fileProcessingService.uploadAndProcess("CLIENT1", "batch1.xml", "xml", xml, "USR-MGR");

        var payments = paymentRepository.findByBatch_File_Id(file.getId());
        assertThat(payments).hasSize(1);
    }

    @Test
    void missingBeneficiaryIsFlaggedAsExceptionRatherThanFailingTheWholeFile() {
        String csv = """
                debitAccountId,beneficiaryId,amount,currency
                ACC1,BEN-DOES-NOT-EXIST,1000,USD
                ACC1,BEN-PLAIN,1000,USD
                """;

        PaymentFile file = fileProcessingService.uploadAndProcess("CLIENT1", "batch2.csv", "csv", csv, "USR-MGR");

        var payments = paymentRepository.findByBatch_File_Id(file.getId());
        assertThat(payments).hasSize(2);
        assertThat(payments).anySatisfy(p -> {
            assertThat(p.getStatus()).isEqualTo(PaymentStatus.EXCEPTION);
            assertThat(p.getExceptionReason()).contains("Missing Beneficiary");
        });
        assertThat(payments).anySatisfy(p -> assertThat(p.getStatus()).isEqualTo(PaymentStatus.PENDING));
    }

    @Test
    void unsupportedFormatIsRejected() {
        assertThatThrownBy(() -> fileProcessingService.uploadAndProcess("CLIENT1", "f.txt", "txt", "irrelevant", "USR-MGR"))
                .isInstanceOf(ValidationException.class);
    }
}
