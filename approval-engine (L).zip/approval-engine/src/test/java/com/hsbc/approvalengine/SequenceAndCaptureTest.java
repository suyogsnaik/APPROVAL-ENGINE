package com.hsbc.approvalengine;

import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.domain.enums.ViolationType;
import com.hsbc.approvalengine.exception.EligibilityViolationException;
import com.hsbc.approvalengine.service.engine.ApprovalCaptureService;
import com.hsbc.approvalengine.support.AbstractEngineTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** UAT pack section C - Sequence vs Random (TC9-TC11). */
class SequenceAndCaptureTest extends AbstractEngineTest {

    @Autowired
    private ApprovalCaptureService approvalCaptureService;

    @Test
    void tc9_randomApproval_anyOrderReachesApproved() {
        // Tier3 account policy on ACC1 is AND(Cat A, Cat B) with no sequence enforced (Random) -
        // Manager (B) then CFO (A) should both be accepted regardless of order.
        Payment payment = createResolvedPayment("ACC1", "BEN-PLAIN", BigDecimal.valueOf(500_000), "USD");

        approvalCaptureService.capture("USR-MGR", payment.getId(), "TEST");
        assertThat(reload(payment).getStatus()).isEqualTo(PaymentStatus.PARTIALLY_APPROVED);

        approvalCaptureService.capture("USR-CFO", payment.getId(), "TEST");
        assertThat(reload(payment).getStatus()).isEqualTo(PaymentStatus.APPROVED);
    }

    @Test
    void tc9b_randomApproval_reverseOrderAlsoReachesApproved() {
        Payment payment = createResolvedPayment("ACC1", "BEN-PLAIN", BigDecimal.valueOf(500_000), "USD");

        approvalCaptureService.capture("USR-CFO", payment.getId(), "TEST");
        approvalCaptureService.capture("USR-MGR", payment.getId(), "TEST");

        assertThat(reload(payment).getStatus()).isEqualTo(PaymentStatus.APPROVED);
    }

    @Test
    void tc10_sequentialApproval_stage2BeforeStage1IsRejected() {
        // BEN-SEQ's Tier2 policy requires Signatory Group G1 then G2, in that order.
        Payment payment = createResolvedPayment("ACC1", "BEN-SEQ", BigDecimal.valueOf(10000), "USD");

        assertThatThrownBy(() -> approvalCaptureService.capture("USR-G2", payment.getId(), "TEST"))
                .isInstanceOf(EligibilityViolationException.class)
                .satisfies(e -> assertThat(((EligibilityViolationException) e).getViolations())
                        .contains(ViolationType.SEQUENCE_ORDER));
    }

    @Test
    void tc11_sequentialApproval_g1ThenG2CompletesThePayment() {
        Payment payment = createResolvedPayment("ACC1", "BEN-SEQ", BigDecimal.valueOf(10000), "USD");

        approvalCaptureService.capture("USR-G1", payment.getId(), "TEST");
        assertThat(reload(payment).getStatus()).isEqualTo(PaymentStatus.PARTIALLY_APPROVED);

        approvalCaptureService.capture("USR-G2", payment.getId(), "TEST");
        assertThat(reload(payment).getStatus()).isEqualTo(PaymentStatus.APPROVED);
    }
}
