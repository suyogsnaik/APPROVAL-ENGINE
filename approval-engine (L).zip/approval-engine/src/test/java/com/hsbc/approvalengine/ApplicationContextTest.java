package com.hsbc.approvalengine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

/** Smoke test: the full Spring context (all controllers/services/repositories) wires up cleanly. */
@SpringBootTest
class ApplicationContextTest {

    @Test
    void contextLoads() {
        // Intentionally empty - failure here means a bean wiring / circular dependency problem.
    }
}
