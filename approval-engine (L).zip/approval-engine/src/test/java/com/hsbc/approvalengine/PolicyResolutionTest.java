package com.hsbc.approvalengine;

import com.hsbc.approvalengine.domain.enums.PolicyType;
import com.hsbc.approvalengine.dto.engine.ResolvedPolicy;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.support.AbstractEngineTest;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

/** UAT pack section A - Policy Resolution (TC1-TC4). */
class PolicyResolutionTest extends AbstractEngineTest {

    @Test
    void tc1_beneficiaryLevelPolicyOverridesEverythingElse() {
        // BEN001 sits in Beneficiary Group GRP01 (which has its own group policy) AND ACC1 has an
        // account policy, but BEN-SEQ carries a beneficiary-level policy which must win outright.
        ResolvedPolicy resolved = policyResolverService.resolve("ACC1", "BEN-SEQ", BigDecimal.valueOf(10000), "USD");
        assertThat(resolved.policyType()).isEqualTo(PolicyType.BENEFICIARY);
        assertThat(resolved.policyId()).isEqualTo("BEN-SEQ");
    }

    @Test
    void tc2_beneficiaryGroupPolicyIsUsedWhenNoBeneficiaryLevelPolicyExists() {
        // BEN001 has no beneficiary-level policy of its own, but belongs to GRP01 (Supplier Group)
        // which does -> Group policy applies.
        ResolvedPolicy resolved = policyResolverService.resolve("ACC1", "BEN001", BigDecimal.valueOf(10000), "USD");
        assertThat(resolved.policyType()).isEqualTo(PolicyType.BENEFICIARY_GROUP);
        assertThat(resolved.policyId()).isEqualTo("GRP01");
    }

    @Test
    void tc3_accountLevelPolicyIsTheFallbackWhenNoBeneficiaryOrGroupPolicyExists() {
        // BEN-PLAIN has no group and no beneficiary-level policy -> falls back to ACC1's account policy.
        ResolvedPolicy resolved = policyResolverService.resolve("ACC1", "BEN-PLAIN", BigDecimal.valueOf(10000), "USD");
        assertThat(resolved.policyType()).isEqualTo(PolicyType.ACCOUNT);
        assertThat(resolved.policyId()).isEqualTo("ACC1");
    }

    @Test
    void tc4_tierSelection_amount15000FallsIntoTier2() {
        // Seeded tiers: Tier1 [0,5000), Tier2 [5000,20000), Tier3 [20000,1000000).
        ResolvedPolicy resolved = policyResolverService.resolve("ACC1", "BEN-PLAIN", BigDecimal.valueOf(15000), "USD");
        assertThat(resolved.tier().getId()).isEqualTo("Tier2");
    }

    @Test
    void noMatchingTierRaisesValidationException() {
        assertThatThrownBy(() -> policyResolverService.resolve("ACC1", "BEN-PLAIN", BigDecimal.valueOf(5_000_000), "USD"))
                .isInstanceOf(ValidationException.class);
    }
}
