package com.hsbc.approvalengine;

import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.enums.ViolationType;
import com.hsbc.approvalengine.dto.engine.EligibilityResult;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.service.engine.EntitlementValidatorService;
import com.hsbc.approvalengine.support.AbstractEngineTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

/** UAT pack section B - Entitlement & Self-Approval (TC5-TC8). */
class EntitlementValidationTest extends AbstractEngineTest {

    @Autowired
    private AppUserRepository appUserRepository;
    @Autowired
    private EntitlementValidatorService entitlementValidatorService;

    @Test
    void tc5_categoryMismatch() {
        // Tier2 account policy on ACC1 requires Category B only; USR-SUP is Category C.
        Payment payment = createResolvedPayment("ACC1", "BEN-PLAIN", BigDecimal.valueOf(10000), "USD");
        AppUser userSup = appUserRepository.findById("USR-SUP").orElseThrow();

        EligibilityResult result = entitlementValidatorService.validate(userSup, payment);

        assertThat(result.eligible()).isFalse();
        assertThat(result.violations()).contains(ViolationType.CATEGORY_MISMATCH);
    }

    @Test
    void tc6_signatoryGroupMismatch() {
        // BEN-SEQ's Tier2 beneficiary policy requires Signatory Groups G1+G2; USR-SUP belongs to none.
        Payment payment = createResolvedPayment("ACC1", "BEN-SEQ", BigDecimal.valueOf(10000), "USD");
        AppUser userSup = appUserRepository.findById("USR-SUP").orElseThrow();

        EligibilityResult result = entitlementValidatorService.validate(userSup, payment);

        assertThat(result.eligible()).isFalse();
        assertThat(result.violations()).contains(ViolationType.SIGN_GROUP_MISMATCH);
    }

    @Test
    void tc7_accountEntitlementMissing() {
        // USR-NOENT is Category B (matches the Tier2 requirement) but has no entitlement to ACC1.
        Payment payment = createResolvedPayment("ACC1", "BEN-PLAIN", BigDecimal.valueOf(10000), "USD");
        AppUser userNoEnt = appUserRepository.findById("USR-NOENT").orElseThrow();

        EligibilityResult result = entitlementValidatorService.validate(userNoEnt, payment);

        assertThat(result.eligible()).isFalse();
        assertThat(result.violations()).contains(ViolationType.ACCOUNT_NOT_ENTITLED);
    }

    @Test
    void tc8_selfApprovalRestriction() {
        // USR-CFO created BEN-PLAIN and is otherwise a fully eligible Category A approver at Tier1.
        Payment payment = createResolvedPayment("ACC1", "BEN-PLAIN", BigDecimal.valueOf(1000), "USD");
        AppUser userCfo = appUserRepository.findById("USR-CFO").orElseThrow();

        EligibilityResult result = entitlementValidatorService.validate(userCfo, payment);

        assertThat(result.eligible()).isFalse();
        assertThat(result.violations()).containsExactly(ViolationType.SELF_APPROVAL_BLOCKED);
    }
}
