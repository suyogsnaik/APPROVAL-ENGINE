package com.hsbc.approvalengine.domain.entity;

import com.hsbc.approvalengine.domain.enums.FileStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/** A payment instruction file. File -&gt; 1..N Batches -&gt; 1..N Payments. */
@Entity
@Table(name = "payment_files")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PaymentFile {

    @Id
    @Column(length = 50)
    private String id;

    @Column(name = "client_id", length = 50)
    private String clientId;

    @Column(name = "file_name")
    private String fileName;

    @Enumerated(EnumType.STRING)
    @Column(length = 20, nullable = false)
    @Builder.Default
    private FileStatus status = FileStatus.UPLOADED;

    @Column(name = "created_at")
    @Builder.Default
    private Instant createdAt = Instant.now();

    @Column(name = "back_office_ack")
    private String backOfficeAck;

    @Column(name = "released_at")
    private Instant releasedAt;

    @OneToMany(mappedBy = "file", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Batch> batches = new ArrayList<>();
}
