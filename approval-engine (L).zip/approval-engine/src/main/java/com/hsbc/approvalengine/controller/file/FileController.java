package com.hsbc.approvalengine.controller.file;

import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.dto.file.FileStatusResponse;
import com.hsbc.approvalengine.dto.file.FileUploadRequest;
import com.hsbc.approvalengine.repository.BatchRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.service.engine.FileAccessService;
import com.hsbc.approvalengine.service.engine.StatusQueryService;
import com.hsbc.approvalengine.service.fileprocessing.FileProcessingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

/**
 * Epic 3 - File Upload / Status APIs. Every read here requires {@code userId} and is gated by
 * {@link FileAccessService}: a user with no entitlement to any Debit Account touched by the File
 * gets a 404, exactly as if the File did not exist - they never learn it exists, what accounts it
 * touches, or its approval status. Approving individual payments still goes through the
 * finer-grained, per-payment ACCOUNT_NOT_ENTITLED check in the Approval Engine itself.
 */
@RestController
@RequiredArgsConstructor
public class FileController {

    private final FileProcessingService fileProcessingService;
    private final StatusQueryService statusQueryService;
    private final FileAccessService fileAccessService;
    private final BatchRepository batchRepository;
    private final PaymentRepository paymentRepository;

    @PostMapping("/file/upload")
    public PaymentFile upload(@Valid @RequestBody FileUploadRequest request) {
        return fileProcessingService.uploadAndProcess(
                request.clientId(), request.fileName(), request.format(), request.content(), request.uploadedBy());
    }

    @GetMapping("/file/{fileId}/status")
    public FileStatusResponse status(@PathVariable String fileId, @RequestParam String userId) {
        return statusQueryService.fileStatus(userId, fileId);
    }

    @GetMapping("/file/{fileId}")
    public PaymentFile get(@PathVariable String fileId, @RequestParam String userId) {
        fileAccessService.assertVisible(userId, fileId);
        return fileProcessingService.findFile(fileId);
    }

    @GetMapping("/file/{fileId}/batches")
    public java.util.List<Batch> batches(@PathVariable String fileId, @RequestParam String userId) {
        fileAccessService.assertVisible(userId, fileId);
        return batchRepository.findByFile_Id(fileId);
    }

    /** Paginated - a batch inside a 100k-line file can itself hold tens of thousands of payments. */
    @GetMapping("/batch/{batchId}/payments")
    public Page<Payment> payments(@PathVariable String batchId, @RequestParam String userId,
                                   @PageableDefault(size = 50) Pageable pageable) {
        fileAccessService.assertVisibleForBatch(userId, batchId);
        return paymentRepository.findByBatch_Id(batchId, pageable);
    }
}
