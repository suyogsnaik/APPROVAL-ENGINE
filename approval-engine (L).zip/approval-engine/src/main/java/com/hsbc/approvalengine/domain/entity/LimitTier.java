package com.hsbc.approvalengine.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;

/** A monetary threshold band (up to 6 per client) used to determine required approval combinations. */
@Entity
@Table(name = "limit_tiers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LimitTier {

    @Id
    @Column(length = 20)
    private String id; // e.g. "Tier1"

    @Column(name = "min_amount", precision = 18, scale = 2)
    private BigDecimal minAmount;

    /** Null = unbounded upper limit. */
    @Column(name = "max_amount", precision = 18, scale = 2)
    private BigDecimal maxAmount;

    @Column(length = 10)
    private String currency;

    /** Lower values are evaluated first; used to pick the narrowest matching tier deterministically. */
    @Column(name = "rank_order")
    private Integer rankOrder;
}
