package com.hsbc.approvalengine.service.makerchecker;

import com.fasterxml.jackson.databind.JsonNode;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;

/**
 * Implemented by each setup service so the generic {@link ChangeRequestService} can apply an
 * approved Maker-Checker change without knowing the entity's concrete shape.
 */
public interface ChangeApplier {

    SetupEntityType supports();

    void applyCreate(String entityId, JsonNode payload);

    void applyUpdate(String entityId, JsonNode payload);

    void applyDelete(String entityId);
}
