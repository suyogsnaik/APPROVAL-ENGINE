package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.SignatoryGroup;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.SignatoryGroupRequest;
import com.hsbc.approvalengine.dto.setup.UserSignatoryGroupAssignRequest;
import com.hsbc.approvalengine.service.setup.SignatoryGroupService;
import com.hsbc.approvalengine.service.setup.UserSignatoryGroupService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/signatory-group - Feature 2.1: manage groups (A-J) and assign users to them. */
@RestController
@RequestMapping("/setup/signatory-group")
@RequiredArgsConstructor
public class SignatoryGroupController {

    private final SignatoryGroupService signatoryGroupService;
    private final UserSignatoryGroupService userSignatoryGroupService;

    @GetMapping
    public List<SignatoryGroup> findAll() {
        return signatoryGroupService.findAll();
    }

    @GetMapping("/{id}")
    public SignatoryGroup find(@PathVariable String id) {
        return signatoryGroupService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody SignatoryGroupRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(signatoryGroupService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody SignatoryGroupRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(signatoryGroupService.requestUpdate(id, request, makerId));
    }

    @DeleteMapping("/{id}")
    public ChangeRequestResponse delete(@PathVariable String id, @RequestParam String makerId) {
        return ChangeRequestResponse.from(signatoryGroupService.requestDelete(id, makerId));
    }

    /** US19: assign a user to one or more Signatory Groups. */
    @PostMapping("/assign")
    public ChangeRequestResponse assign(@Valid @RequestBody UserSignatoryGroupAssignRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(userSignatoryGroupService.requestAssign(request, makerId));
    }
}
