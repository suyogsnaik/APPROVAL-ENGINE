package com.hsbc.approvalengine.service.audit;

import com.hsbc.approvalengine.domain.entity.AuditLog;
import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * Writes immutable {@link AuditLog} entries. Per MRS 2.6 / PRD 5.5, every setup change
 * (Maker-Checker), beneficiary creation/edit, approval action, applied policy and exception
 * must be logged with who / when / what.
 */
@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    /** Runs in its own transaction so an audit entry for an exception survives a rollback. */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void log(SetupEntityType entityType, String entityId, AuditAction action, String performedBy, String details) {
        write(entityType, entityId, action, performedBy, details);
    }

    /**
     * Same audit entry, but participates in the caller's existing transaction instead of opening
     * a new one. Use this only where the entry has no meaning independent of that transaction
     * committing anyway - e.g. "payment N of File X was created", which is moot if the whole
     * upload rolls back. A 100k-line file upload logging one entry per line via {@link #log} would
     * mean 100k separate transaction commits; this keeps it to one write, batched with the rest of
     * the upload. Entries that must survive a later rollback (exceptions, capture failures) still
     * go through {@link #log}.
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public void logWithinTransaction(SetupEntityType entityType, String entityId, AuditAction action, String performedBy, String details) {
        write(entityType, entityId, action, performedBy, details);
    }

    private void write(SetupEntityType entityType, String entityId, AuditAction action, String performedBy, String details) {
        AuditLog log = AuditLog.builder()
                .id("AUD-" + UUID.randomUUID())
                .entityType(entityType)
                .entityId(entityId)
                .action(action)
                .performedBy(performedBy)
                .details(details)
                .build();
        auditLogRepository.save(log);
    }
}
