package com.hsbc.approvalengine.service.backoffice;

import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.FileStatus;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.repository.PaymentFileRepository;
import com.hsbc.approvalengine.service.audit.AuditService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.UUID;

/**
 * Epic 6 - Back Office Integration (Feature 6.1). Receives only fully-approved files (US42) and
 * stores the acknowledgement (US43). This is a stub standing in for the real payment execution
 * platform - out of scope per PRD "Out of Scope: ERP/TMS integrations" - but the release
 * contract (only ever called once a File is fully APPROVED, synchronous ack, audited) is real.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class BackOfficeService {

    private final PaymentFileRepository paymentFileRepository;
    private final AuditService auditService;

    @Transactional
    public void releaseIfFullyApproved(PaymentFile file, String performedBy) {
        if (file.getStatus() != FileStatus.APPROVED) {
            return;
        }
        log.info("Releasing fully approved file {} to Back Office", file.getId());
        auditService.log(SetupEntityType.FILE, file.getId(), AuditAction.RELEASE_TO_BACK_OFFICE, performedBy,
                "File released to Back Office for execution");

        // Stand-in for the real Back Office execution call (out of scope per PRD).
        String ack = "ACK-" + UUID.randomUUID();

        file.setStatus(FileStatus.RELEASED);
        file.setBackOfficeAck(ack);
        file.setReleasedAt(Instant.now());
        paymentFileRepository.save(file);

        auditService.log(SetupEntityType.FILE, file.getId(), AuditAction.BACK_OFFICE_ACK, "BACK_OFFICE",
                "Back Office acknowledged receipt: " + ack);
    }
}
