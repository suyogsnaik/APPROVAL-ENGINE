package com.hsbc.approvalengine.dto.file;

import java.math.BigDecimal;

/** One payment instruction line as extracted from an uploaded XML/CSV file, before DB mapping. */
public record ParsedPaymentLine(
        String debitAccountId,
        String beneficiaryId,
        BigDecimal amount,
        String currency
) {
}
