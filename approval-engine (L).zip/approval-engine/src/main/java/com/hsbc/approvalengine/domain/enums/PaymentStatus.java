package com.hsbc.approvalengine.domain.enums;

public enum PaymentStatus {
    PENDING,
    PARTIALLY_APPROVED,
    APPROVED,
    REJECTED,
    EXCEPTION
}
