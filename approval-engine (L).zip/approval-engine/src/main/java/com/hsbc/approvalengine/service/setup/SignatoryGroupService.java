package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.SignatoryGroup;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.SignatoryGroupRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.SignatoryGroupRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Feature 2.1 - Signatory Groups: up to 10 groups (A-J), up to 8 sequential stages. */
@Service
@RequiredArgsConstructor
public class SignatoryGroupService implements ChangeApplier {

    private static final int MAX_GROUPS = 10;
    private static final int MAX_STAGE = 8;

    private final SignatoryGroupRepository signatoryGroupRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<SignatoryGroup> findAll() {
        return signatoryGroupRepository.findAll();
    }

    public SignatoryGroup find(String id) {
        return signatoryGroupRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Signatory group not found: " + id));
    }

    public ChangeRequest requestCreate(SignatoryGroupRequest request, String makerId) {
        if (signatoryGroupRepository.existsById(request.id())) {
            throw new ValidationException("Signatory group already exists: " + request.id());
        }
        if (signatoryGroupRepository.count() >= MAX_GROUPS) {
            throw new ValidationException("Maximum of " + MAX_GROUPS + " signatory groups (A-J) already defined");
        }
        if (request.sequenceOrder() != null && (request.sequenceOrder() < 1 || request.sequenceOrder() > MAX_STAGE)) {
            throw new ValidationException("sequenceOrder must be between 1 and " + MAX_STAGE);
        }
        return changeRequestService.submit(SetupEntityType.SIGNATORY_GROUP, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, SignatoryGroupRequest request, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.SIGNATORY_GROUP, id, ChangeAction.UPDATE, request, makerId);
    }

    public ChangeRequest requestDelete(String id, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.SIGNATORY_GROUP, id, ChangeAction.DELETE, java.util.Map.of("id", id), makerId);
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.SIGNATORY_GROUP;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        SignatoryGroupRequest r = objectMapper.convertValue(payload, SignatoryGroupRequest.class);
        signatoryGroupRepository.save(SignatoryGroup.builder()
                .id(r.id()).name(r.name()).sequenceOrder(r.sequenceOrder()).sequential(r.sequential()).build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        SignatoryGroupRequest r = objectMapper.convertValue(payload, SignatoryGroupRequest.class);
        SignatoryGroup g = find(entityId);
        g.setName(r.name());
        g.setSequenceOrder(r.sequenceOrder());
        g.setSequential(r.sequential());
        signatoryGroupRepository.save(g);
    }

    @Override
    public void applyDelete(String entityId) {
        signatoryGroupRepository.deleteById(entityId);
    }
}
