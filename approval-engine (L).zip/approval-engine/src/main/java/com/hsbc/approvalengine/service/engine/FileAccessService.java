package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.repository.BatchRepository;
import com.hsbc.approvalengine.service.setup.AccountEntitlementService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * File-level visibility gate. A File is made up of one or more Batches, each tied to exactly one
 * Debit Account (MRS 2.1: "Batch = grouped by Debit Account"). Before a user can see a File - or
 * any Batch/Payment inside it - at all, they must be entitled to <em>at least one</em> of the
 * Debit Accounts it touches. This is deliberately separate from, and checked before, the
 * per-payment approval eligibility in {@link EntitlementValidatorService}: a user with authority
 * over even one account in the file can see the whole file (so they have context on what they're
 * approving), but they still can't approve individual payments on accounts they aren't entitled
 * to - that per-payment ACCOUNT_NOT_ENTITLED check is unchanged.
 *
 * <p>Visibility failures surface as {@link NotFoundException} (HTTP 404) rather than a 403: a
 * user with zero entitlement on a file should not be able to tell whether it exists at all, which
 * account(s) it touches, or who else it belongs to.</p>
 */
@Service
@RequiredArgsConstructor
public class FileAccessService {

    private final BatchRepository batchRepository;
    private final AccountEntitlementService accountEntitlementService;

    public boolean isVisible(String userId, String fileId) {
        Set<String> debitAccountIds = debitAccountsOf(fileId);
        return accountEntitlementService.isEntitledToAnyAccount(userId, debitAccountIds);
    }

    /** Throws {@link NotFoundException} - not 403 - if the user has no entitlement to any account in the file. */
    public void assertVisible(String userId, String fileId) {
        if (!isVisible(userId, fileId)) {
            throw new NotFoundException("File not found: " + fileId);
        }
    }

    /** Same gate, entered from a Batch id rather than a File id (e.g. GET /batch/{batchId}/payments). */
    public void assertVisibleForBatch(String userId, String batchId) {
        Batch batch = batchRepository.findById(batchId)
                .orElseThrow(() -> new NotFoundException("Batch not found: " + batchId));
        assertVisible(userId, batch.getFile().getId());
    }

    private Set<String> debitAccountsOf(String fileId) {
        List<Batch> batches = batchRepository.findByFile_Id(fileId);
        return batches.stream().map(Batch::getDebitAccountId).collect(Collectors.toSet());
    }
}
