package com.hsbc.approvalengine.dto.engine;

import jakarta.validation.constraints.NotBlank;

/** POST /approval/validate request body, per API spec 3.2. */
public record ValidateRequest(
        @NotBlank String userId,
        @NotBlank String paymentId
) {
}
