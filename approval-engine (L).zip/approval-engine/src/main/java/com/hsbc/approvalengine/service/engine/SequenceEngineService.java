package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.Approval;
import com.hsbc.approvalengine.domain.entity.SignatoryGroup;
import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.repository.SignatoryGroupRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;

/**
 * Feature 4.5 - Approval Sequence Engine.
 *
 * <p><b>Random (default)</b>: any entitled approver may sign at any time, no stage ordering.</p>
 * <p><b>Sequential</b>: a combination flagged {@code sequenceRequired} enforces that every
 * Signatory Group with a lower {@code sequenceOrder} than the one the current approver belongs to
 * must already have a captured approval on this payment before this stage can be signed
 * (MRS 2.3.5 / state machine "Approval Sequence Check").</p>
 */
@Service
@RequiredArgsConstructor
public class SequenceEngineService {

    private final SignatoryGroupRepository signatoryGroupRepository;

    /** True if {@code candidateGroupId} is allowed to sign next given the approvals already captured. */
    public boolean isNextInSequence(TierCombination combo, String candidateGroupId, List<Approval> existingApprovals) {
        if (!combo.isSequenceRequired() || candidateGroupId == null) {
            return true; // Random approval - no ordering enforced.
        }
        SignatoryGroup candidate = signatoryGroupRepository.findById(candidateGroupId).orElse(null);
        if (candidate == null || candidate.getSequenceOrder() == null) {
            return true; // no defined stage order for this group - nothing to enforce.
        }

        Set<String> alreadyApprovedGroupIds = existingApprovals.stream()
                .map(Approval::getSignatoryGroupId)
                .filter(java.util.Objects::nonNull)
                .collect(java.util.stream.Collectors.toSet());

        for (String requiredGroupId : combo.getSignatoryGroupIds()) {
            if (requiredGroupId.equals(candidateGroupId)) {
                continue;
            }
            SignatoryGroup other = signatoryGroupRepository.findById(requiredGroupId).orElse(null);
            if (other == null || other.getSequenceOrder() == null) {
                continue;
            }
            if (other.getSequenceOrder() < candidate.getSequenceOrder() && !alreadyApprovedGroupIds.contains(requiredGroupId)) {
                return false; // an earlier stage hasn't signed yet
            }
        }
        return true;
    }
}
