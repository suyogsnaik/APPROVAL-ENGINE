package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.TierCombinationRequest;
import com.hsbc.approvalengine.service.setup.TierCombinationService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/combination - Feature 1.3: Define AND/OR combinations per tier (up to 8). */
@RestController
@RequestMapping("/setup/combination")
@RequiredArgsConstructor
public class TierCombinationController {

    private final TierCombinationService tierCombinationService;

    @GetMapping
    public List<TierCombination> findAll() {
        return tierCombinationService.findAll();
    }

    @GetMapping("/{id}")
    public TierCombination find(@PathVariable String id) {
        return tierCombinationService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody TierCombinationRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(tierCombinationService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody TierCombinationRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(tierCombinationService.requestUpdate(id, request, makerId));
    }

    @DeleteMapping("/{id}")
    public ChangeRequestResponse delete(@PathVariable String id, @RequestParam String makerId) {
        return ChangeRequestResponse.from(tierCombinationService.requestDelete(id, makerId));
    }
}
