package com.hsbc.approvalengine.domain.enums;

public enum FileStatus {
    UPLOADED,
    IN_APPROVAL,
    APPROVED,
    RELEASED,
    REJECTED
}
