package com.hsbc.approvalengine.dto.file;

import com.hsbc.approvalengine.domain.enums.FileStatus;

import java.util.List;

/**
 * GET /file/{fileId}/status response, matching API spec 3.4. {@code appliedPolicies} surfaces the
 * approval policy/policies the engine resolved for this file's payments, once the caller is
 * entitled to see the file at all - one entry per distinct (policy level, policy id, tier) the
 * engine applied, not per payment line, so this stays small even for a 100k-line file.
 */
public record FileStatusResponse(
        String fileId,
        FileStatus status,
        int batchesApproved,
        int batchesTotal,
        long paymentsApproved,
        long paymentsTotal,
        long paymentsException,
        boolean isFullyApproved,
        List<AppliedPolicySummary> appliedPolicies
) {
}
