package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.Category;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.CategoryRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.CategoryRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Feature 1.1 - Category Setup (A-N, up to 14 categories). All changes go through Maker-Checker. */
@Service
@RequiredArgsConstructor
public class CategoryService implements ChangeApplier {

    private static final int MAX_CATEGORIES = 14;

    private final CategoryRepository categoryRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<Category> findAll() {
        return categoryRepository.findAll();
    }

    public Category find(String id) {
        return categoryRepository.findById(id).orElseThrow(() -> new NotFoundException("Category not found: " + id));
    }

    public ChangeRequest requestCreate(CategoryRequest request, String makerId) {
        if (categoryRepository.existsById(request.id())) {
            throw new ValidationException("Category already exists: " + request.id());
        }
        if (categoryRepository.count() >= MAX_CATEGORIES) {
            throw new ValidationException("Maximum of " + MAX_CATEGORIES + " categories (A-N) already defined");
        }
        return changeRequestService.submit(SetupEntityType.CATEGORY, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, CategoryRequest request, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.CATEGORY, id, ChangeAction.UPDATE, request, makerId);
    }

    public ChangeRequest requestDelete(String id, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.CATEGORY, id, ChangeAction.DELETE, java.util.Map.of("id", id), makerId);
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.CATEGORY;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        CategoryRequest r = objectMapper.convertValue(payload, CategoryRequest.class);
        categoryRepository.save(Category.builder().id(r.id()).name(r.name()).description(r.description()).build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        CategoryRequest r = objectMapper.convertValue(payload, CategoryRequest.class);
        Category c = find(entityId);
        c.setName(r.name());
        c.setDescription(r.description());
        categoryRepository.save(c);
    }

    @Override
    public void applyDelete(String entityId) {
        categoryRepository.deleteById(entityId);
    }
}
