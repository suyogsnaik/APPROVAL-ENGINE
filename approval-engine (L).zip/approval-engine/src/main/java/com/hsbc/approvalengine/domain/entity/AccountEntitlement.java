package com.hsbc.approvalengine.domain.entity;

import com.hsbc.approvalengine.domain.enums.EntitlementType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Which Debit Account(s) a user is entitled to operate on / approve payments against. */
@Entity
@Table(name = "account_entitlements")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountEntitlement {

    @EmbeddedId
    private AccountEntitlementId id;

    @Enumerated(EnumType.STRING)
    @Column(name = "entitlement_type", length = 20, nullable = false)
    private EntitlementType entitlementType;
}
