package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.TierCombination;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TierCombinationRepository extends JpaRepository<TierCombination, String> {
}
