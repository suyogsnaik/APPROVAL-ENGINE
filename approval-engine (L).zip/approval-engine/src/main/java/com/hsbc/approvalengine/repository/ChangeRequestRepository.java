package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.ChangeRequestStatus;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ChangeRequestRepository extends JpaRepository<ChangeRequest, String> {
    List<ChangeRequest> findByStatus(ChangeRequestStatus status);
    List<ChangeRequest> findByEntityTypeAndStatus(SetupEntityType entityType, ChangeRequestStatus status);
}
