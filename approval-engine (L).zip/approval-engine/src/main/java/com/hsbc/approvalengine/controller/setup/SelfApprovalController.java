package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.SelfApprovalSettingRequest;
import com.hsbc.approvalengine.service.setup.SelfApprovalSettingService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/** POST /setup/self-approval - Feature 1.6: enable/disable self-approval restriction per client. */
@RestController
@RequestMapping("/setup/self-approval")
@RequiredArgsConstructor
public class SelfApprovalController {

    private final SelfApprovalSettingService selfApprovalSettingService;

    @GetMapping("/{clientId}")
    public Map<String, Object> get(@PathVariable String clientId) {
        return Map.of("clientId", clientId, "restrictSelfApproval", selfApprovalSettingService.isRestricted(clientId));
    }

    @PostMapping
    public ChangeRequestResponse upsert(@Valid @RequestBody SelfApprovalSettingRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(selfApprovalSettingService.requestUpsert(request, makerId));
    }
}
