package com.hsbc.approvalengine.service.fileprocessing;

import com.hsbc.approvalengine.dto.file.ParsedPaymentLine;
import com.hsbc.approvalengine.exception.ValidationException;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * Parses a simple CSV payment file. Expected header (order-independent):
 * {@code debitAccountId,beneficiaryId,amount,currency}
 */
@Component
public class CsvPaymentFileParser implements PaymentFileParser {

    @Override
    public boolean supports(String format) {
        return "csv".equalsIgnoreCase(format);
    }

    @Override
    public List<ParsedPaymentLine> parse(String content) {
        List<String> lines = content.lines().map(String::strip).filter(l -> !l.isEmpty()).toList();
        if (lines.isEmpty()) {
            throw new ValidationException("CSV file is empty");
        }
        String[] header = lines.get(0).split(",");
        int debitIdx = indexOf(header, "debitAccountId");
        int beneIdx = indexOf(header, "beneficiaryId");
        int amtIdx = indexOf(header, "amount");
        int ccyIdx = indexOf(header, "currency");

        List<ParsedPaymentLine> result = new ArrayList<>();
        for (int i = 1; i < lines.size(); i++) {
            String[] cols = lines.get(i).split(",", -1);
            if (cols.length < header.length) {
                throw new ValidationException("Malformed CSV row " + (i + 1) + ": " + lines.get(i));
            }
            try {
                result.add(new ParsedPaymentLine(
                        cols[debitIdx].strip(),
                        cols[beneIdx].strip(),
                        new BigDecimal(cols[amtIdx].strip()),
                        cols[ccyIdx].strip()
                ));
            } catch (NumberFormatException e) {
                throw new ValidationException("Invalid amount on CSV row " + (i + 1) + ": " + lines.get(i));
            }
        }
        return result;
    }

    private int indexOf(String[] header, String name) {
        for (int i = 0; i < header.length; i++) {
            if (header[i].strip().equalsIgnoreCase(name)) {
                return i;
            }
        }
        throw new ValidationException("CSV file missing required column: " + name);
    }
}
