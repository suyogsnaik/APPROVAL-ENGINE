package com.hsbc.approvalengine.service.fileprocessing;

import com.hsbc.approvalengine.dto.file.ParsedPaymentLine;
import com.hsbc.approvalengine.exception.ValidationException;
import org.springframework.stereotype.Component;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Parses a simple XML payment file:
 * {@code <PaymentFile><Payment debitAccountId="" beneficiaryId="" amount="" currency=""/></PaymentFile>}
 */
@Component
public class XmlPaymentFileParser implements PaymentFileParser {

    @Override
    public boolean supports(String format) {
        return "xml".equalsIgnoreCase(format);
    }

    @Override
    public List<ParsedPaymentLine> parse(String content) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Harden against XXE per NFR 3.2 Security.
            factory.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true);
            factory.setXIncludeAware(false);
            factory.setExpandEntityReferences(false);
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_DTD, "");
            factory.setAttribute(XMLConstants.ACCESS_EXTERNAL_SCHEMA, "");
            DocumentBuilder builder = factory.newDocumentBuilder();
            InputStream in = new ByteArrayInputStream(content.getBytes(StandardCharsets.UTF_8));
            Document doc = builder.parse(in);

            NodeList paymentNodes = doc.getElementsByTagName("Payment");
            if (paymentNodes.getLength() == 0) {
                throw new ValidationException("XML file contains no <Payment> elements");
            }
            List<ParsedPaymentLine> result = new ArrayList<>();
            for (int i = 0; i < paymentNodes.getLength(); i++) {
                Element el = (Element) paymentNodes.item(i);
                String debitAccountId = required(el, "debitAccountId", i);
                String beneficiaryId = required(el, "beneficiaryId", i);
                String amount = required(el, "amount", i);
                String currency = required(el, "currency", i);
                try {
                    result.add(new ParsedPaymentLine(debitAccountId, beneficiaryId, new BigDecimal(amount), currency));
                } catch (NumberFormatException e) {
                    throw new ValidationException("Invalid amount on <Payment> #" + (i + 1) + ": " + amount);
                }
            }
            return result;
        } catch (ValidationException e) {
            throw e;
        } catch (Exception e) {
            throw new ValidationException("Unable to parse XML payment file: " + e.getMessage());
        }
    }

    private String required(Element el, String attr, int index) {
        String v = el.getAttribute(attr);
        if (v == null || v.isBlank()) {
            throw new ValidationException("<Payment> #" + (index + 1) + " missing required attribute: " + attr);
        }
        return v;
    }
}
