package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, String> {
}
