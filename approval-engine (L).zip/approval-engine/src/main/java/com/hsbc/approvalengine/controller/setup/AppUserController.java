package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.dto.setup.AppUserRequest;
import com.hsbc.approvalengine.service.setup.AppUserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/user - user provisioning (outside the Approval Engine's Maker-Checker backlog, see AppUserService). */
@RestController
@RequestMapping("/setup/user")
@RequiredArgsConstructor
public class AppUserController {

    private final AppUserService appUserService;

    @GetMapping
    public List<AppUser> findAll() {
        return appUserService.findAll();
    }

    @GetMapping("/{id}")
    public AppUser find(@PathVariable String id) {
        return appUserService.find(id);
    }

    @PostMapping
    public AppUser create(@Valid @RequestBody AppUserRequest request, @RequestParam(defaultValue = "SYSTEM") String performedBy) {
        return appUserService.createOrUpdate(request, performedBy);
    }
}
