package com.hsbc.approvalengine.dto.engine;

import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.domain.enums.ViolationType;

import java.math.BigDecimal;
import java.util.List;

/** Feature 5.1 - Approval Dashboard (US36-38): one pending item shown to a would-be approver. */
public record DashboardItem(
        String fileId,
        String batchId,
        String paymentId,
        String debitAccountId,
        String beneficiaryId,
        BigDecimal amount,
        String currency,
        PaymentStatus status,
        List<PolicyResolveResponse.RequiredCombination> requiredCombinations,
        boolean eligibleNow,
        List<ViolationType> violationsIfIneligible
) {
}
