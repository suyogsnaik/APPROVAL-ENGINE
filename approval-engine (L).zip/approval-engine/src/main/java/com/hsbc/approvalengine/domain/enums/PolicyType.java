package com.hsbc.approvalengine.domain.enums;

/** Policy Resolution hierarchy: Beneficiary policy beats Beneficiary Group policy beats Account policy. */
public enum PolicyType {
    BENEFICIARY,
    BENEFICIARY_GROUP,
    ACCOUNT
}
