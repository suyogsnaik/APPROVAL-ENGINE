package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.SelfApprovalSetting;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.SelfApprovalSettingRequest;
import com.hsbc.approvalengine.repository.SelfApprovalSettingRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/** Feature 1.6 - Self-Approval Restriction: per-client on/off switch, itself Maker-Checker governed. */
@Service
@RequiredArgsConstructor
public class SelfApprovalSettingService implements ChangeApplier {

    private final SelfApprovalSettingRepository repository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    /** Defaults to restricted (true) per PRD 3.7 when no explicit setting has been configured yet. */
    public boolean isRestricted(String clientId) {
        return repository.findById(clientId).map(SelfApprovalSetting::isRestrictSelfApproval).orElse(true);
    }

    public ChangeRequest requestUpsert(SelfApprovalSettingRequest request, String makerId) {
        SetupEntityType type = SetupEntityType.SELF_APPROVAL_SETTING;
        ChangeAction action = repository.existsById(request.clientId()) ? ChangeAction.UPDATE : ChangeAction.CREATE;
        return changeRequestService.submit(type, request.clientId(), action, request, makerId);
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.SELF_APPROVAL_SETTING;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        upsert(payload);
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        upsert(payload);
    }

    @Override
    public void applyDelete(String entityId) {
        repository.deleteById(entityId);
    }

    private void upsert(JsonNode payload) {
        SelfApprovalSettingRequest r = objectMapper.convertValue(payload, SelfApprovalSettingRequest.class);
        repository.save(SelfApprovalSetting.builder()
                .clientId(r.clientId()).restrictSelfApproval(r.restrictSelfApproval()).build());
    }
}
