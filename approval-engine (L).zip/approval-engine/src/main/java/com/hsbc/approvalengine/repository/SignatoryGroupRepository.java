package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.SignatoryGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SignatoryGroupRepository extends JpaRepository<SignatoryGroup, String> {
}
