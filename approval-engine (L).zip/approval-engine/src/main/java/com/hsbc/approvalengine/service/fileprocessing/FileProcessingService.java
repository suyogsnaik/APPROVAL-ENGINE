package com.hsbc.approvalengine.service.fileprocessing;

import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.domain.entity.Beneficiary;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.BatchStatus;
import com.hsbc.approvalengine.domain.enums.FileStatus;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.engine.ResolvedPolicy;
import com.hsbc.approvalengine.dto.file.ParsedPaymentLine;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.BatchRepository;
import com.hsbc.approvalengine.repository.BeneficiaryRepository;
import com.hsbc.approvalengine.repository.PaymentFileRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.service.audit.AuditService;
import com.hsbc.approvalengine.service.engine.PolicyResolverService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * Epic 3 - File Processing Layer: File Upload (US23/24), Batch Builder (US25, groups payments by
 * Debit Account) and Payment Line Mapper (US26/27, resolves Beneficiary/Beneficiary Group).
 * Immediately after building the File/Batch/Payment structure it runs Policy Resolution
 * (Feature 4.1) for every payment, per the End-to-end flow step 3 in the architecture pack.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class FileProcessingService {

    private final List<PaymentFileParser> parsers;
    private final PaymentFileRepository paymentFileRepository;
    private final BatchRepository batchRepository;
    private final PaymentRepository paymentRepository;
    private final BeneficiaryRepository beneficiaryRepository;
    private final PolicyResolverService policyResolverService;
    private final AuditService auditService;

    @Value("${approval-engine.performance.max-payment-lines-per-file:10000}")
    private int maxPaymentLines;

    @Transactional
    public PaymentFile uploadAndProcess(String clientId, String fileName, String format, String content, String uploadedBy) {
        PaymentFileParser parser = parsers.stream().filter(p -> p.supports(format)).findFirst()
                .orElseThrow(() -> new ValidationException("Unsupported file format: " + format + " (use csv or xml)"));

        List<ParsedPaymentLine> lines = parser.parse(content);
        if (lines.isEmpty()) {
            throw new ValidationException("File contains no payment lines");
        }
        if (lines.size() > maxPaymentLines) {
            throw new ValidationException("File exceeds max supported " + maxPaymentLines + " payment lines (NFR 3.1): " + lines.size());
        }

        PaymentFile file = PaymentFile.builder()
                .id("FILE-" + UUID.randomUUID())
                .clientId(clientId)
                .fileName(fileName)
                .status(FileStatus.UPLOADED)
                .build();
        paymentFileRepository.save(file);
        auditService.log(SetupEntityType.FILE, file.getId(), AuditAction.CREATE, uploadedBy,
                "File uploaded: " + fileName + " (" + lines.size() + " payment lines, format=" + format + ")");

        // Batch Builder: group payment lines by Debit Account (US25).
        Map<String, List<ParsedPaymentLine>> byAccount = lines.stream()
                .collect(Collectors.groupingBy(ParsedPaymentLine::debitAccountId, LinkedHashMap::new, Collectors.toList()));

        // Bulk-preload everything Policy Resolution needs for the whole file - a handful of
        // queries total instead of ~4 per payment line - so this scales to a 100k-line file
        // (NFR 3.1) instead of issuing hundreds of thousands of individual lookups.
        Set<String> beneficiaryIds = lines.stream().map(ParsedPaymentLine::beneficiaryId).collect(Collectors.toSet());
        PolicyResolverService.PolicyContext policyContext = policyResolverService.loadContext(byAccount.keySet(), beneficiaryIds);

        for (Map.Entry<String, List<ParsedPaymentLine>> entry : byAccount.entrySet()) {
            Batch batch = Batch.builder()
                    .id("BATCH-" + UUID.randomUUID())
                    .file(file)
                    .debitAccountId(entry.getKey())
                    .status(BatchStatus.IN_APPROVAL)
                    .build();
            batchRepository.save(batch);

            int resolvedCount = 0;
            int exceptionCount = 0;
            for (ParsedPaymentLine line : entry.getValue()) {
                if (mapAndResolvePayment(batch, line, policyContext, uploadedBy)) {
                    resolvedCount++;
                } else {
                    exceptionCount++;
                }
            }
            // One summary entry per Batch instead of one per payment line (which for a 100k-line
            // file would mean 100k separate REQUIRES_NEW transaction commits); participates in
            // this upload's own transaction since it has no meaning if the upload rolls back.
            auditService.logWithinTransaction(SetupEntityType.BATCH, batch.getId(), AuditAction.CREATE, uploadedBy,
                    "Batch created for debit account " + entry.getKey() + " with " + entry.getValue().size()
                            + " payments (" + resolvedCount + " resolved, " + exceptionCount + " exceptions)");
        }

        file.setStatus(FileStatus.IN_APPROVAL);
        paymentFileRepository.save(file);
        return file;
    }

    /**
     * Payment Line Mapper (US26/27) + immediate Policy Resolution for the new payment, resolved
     * against the file-wide {@link PolicyResolverService.PolicyContext} rather than per-line
     * database lookups. Returns true if the payment resolved cleanly, false if it was flagged as
     * an EXCEPTION (each exception is still individually audited via {@link
     * AuditService#log} since it must survive even if the surrounding upload later fails).
     */
    private boolean mapAndResolvePayment(Batch batch, ParsedPaymentLine line, PolicyResolverService.PolicyContext policyContext, String uploadedBy) {
        Payment.PaymentBuilder builder = Payment.builder()
                .id("PAY-" + UUID.randomUUID())
                .batch(batch)
                .amount(line.amount())
                .currency(line.currency())
                .status(PaymentStatus.PENDING);

        Beneficiary beneficiary = policyContext.beneficiariesById().get(line.beneficiaryId());
        if (beneficiary == null) {
            // Exception Handling 6.4 - Missing Beneficiary -> flag for manual review.
            Payment payment = builder.status(PaymentStatus.EXCEPTION)
                    .exceptionReason("Missing Beneficiary: " + line.beneficiaryId())
                    .build();
            paymentRepository.save(payment);
            auditService.log(SetupEntityType.PAYMENT, payment.getId(), AuditAction.EXCEPTION, uploadedBy,
                    payment.getExceptionReason());
            return false;
        }
        builder.beneficiary(beneficiary);
        Payment payment = builder.build();

        try {
            ResolvedPolicy resolved = policyResolverService.resolve(
                    policyContext, batch.getDebitAccountId(), beneficiary.getId(), line.amount(), line.currency());
            payment.setAppliedPolicyType(resolved.policyType());
            payment.setAppliedPolicyId(resolved.policyId());
            payment.setAppliedTier(resolved.tier());
            payment.setAppliedCombinationIds(resolved.combinations().stream()
                    .map(c -> c.getId()).collect(Collectors.toSet()));
            paymentRepository.save(payment);
            return true;
        } catch (ValidationException e) {
            payment.setStatus(PaymentStatus.EXCEPTION);
            payment.setExceptionReason(e.getMessage());
            paymentRepository.save(payment);
            auditService.log(SetupEntityType.PAYMENT, payment.getId(), AuditAction.EXCEPTION, uploadedBy, e.getMessage());
            return false;
        }
    }

    public PaymentFile findFile(String fileId) {
        return paymentFileRepository.findById(fileId).orElseThrow(() -> new NotFoundException("File not found: " + fileId));
    }
}
