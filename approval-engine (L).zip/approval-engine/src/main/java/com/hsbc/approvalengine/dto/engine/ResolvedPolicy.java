package com.hsbc.approvalengine.dto.engine;

import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.domain.enums.PolicyType;

import java.util.List;

/**
 * Result of Policy Resolution (MRS 2.3.1) + Tier/Combination Resolution (2.3.2/2.3.3) for one
 * payment: which policy hierarchy level won, the tier it fell into, and the OR-set of
 * combinations (any one of which fully approves the payment).
 */
public record ResolvedPolicy(
        PolicyType policyType,
        String policyId,
        LimitTier tier,
        List<TierCombination> combinations
) {
}
