package com.hsbc.approvalengine.domain.entity;

import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.domain.enums.PolicyType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * A single payment line: Beneficiary + Amount + Currency, plus the policy/tier resolved for it
 * by the Approval Engine and the running list of captured approvals.
 *
 * <p>Indexed on {@code batch_id} and {@code (batch_id, status)} - the cascade "are all payments
 * in this batch approved yet" check in ApprovalCaptureService and the file status roll-up in
 * StatusQueryService are both COUNT queries against these columns, and need to stay index
 * lookups rather than table scans for a 100k-line file (NFR 3.1) - and on {@code status} for the
 * Dashboard's open-items query.</p>
 */
@Entity
@Table(name = "payments", indexes = {
        @Index(name = "idx_payment_batch_id", columnList = "batch_id"),
        @Index(name = "idx_payment_batch_id_status", columnList = "batch_id,status"),
        @Index(name = "idx_payment_status", columnList = "status")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Payment {

    @Id
    @Column(length = 50)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "batch_id")
    private Batch batch;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "beneficiary_id")
    private Beneficiary beneficiary;

    @Column(precision = 18, scale = 2, nullable = false)
    private BigDecimal amount;

    @Column(length = 10, nullable = false)
    private String currency;

    @Enumerated(EnumType.STRING)
    @Column(length = 20, nullable = false)
    @Builder.Default
    private PaymentStatus status = PaymentStatus.PENDING;

    /** Which policy tier the resolver used to reach this payment's required combinations. */
    @Enumerated(EnumType.STRING)
    @Column(name = "applied_policy_type", length = 20)
    private PolicyType appliedPolicyType;

    @Column(name = "applied_policy_id", length = 50)
    private String appliedPolicyId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "applied_tier_id")
    private LimitTier appliedTier;

    /** OR-set of TierCombination ids: satisfying any one fully approves the payment. */
    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "payment_applied_combinations", joinColumns = @JoinColumn(name = "payment_id"))
    @Column(name = "combination_id")
    @Builder.Default
    private Set<String> appliedCombinationIds = new HashSet<>();

    @Column(name = "exception_reason")
    private String exceptionReason;

    @Column(name = "created_at")
    @Builder.Default
    private Instant createdAt = Instant.now();

    @OneToMany(mappedBy = "payment", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Approval> approvals = new ArrayList<>();
}
