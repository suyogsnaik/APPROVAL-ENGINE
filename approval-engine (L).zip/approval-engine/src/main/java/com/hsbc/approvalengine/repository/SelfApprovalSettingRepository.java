package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.SelfApprovalSetting;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SelfApprovalSettingRepository extends JpaRepository<SelfApprovalSetting, String> {
}
