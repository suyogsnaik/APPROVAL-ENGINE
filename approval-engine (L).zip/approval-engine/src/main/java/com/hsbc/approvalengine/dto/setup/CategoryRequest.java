package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

/** Categories A-N (up to 14) represent user seniority, e.g. CFO -> Cat A. */
public record CategoryRequest(
        @NotBlank @Pattern(regexp = "[A-N]", message = "Category id must be a single letter A-N") String id,
        @NotBlank String name,
        String description
) {
}
