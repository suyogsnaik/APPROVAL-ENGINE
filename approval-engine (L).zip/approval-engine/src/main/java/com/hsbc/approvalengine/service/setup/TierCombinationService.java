package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.TierCombinationRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.CategoryRepository;
import com.hsbc.approvalengine.repository.LimitTierRepository;
import com.hsbc.approvalengine.repository.SignatoryGroupRepository;
import com.hsbc.approvalengine.repository.TierCombinationRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Feature 1.3 - Combination Logic Setup: up to 8 OR-based combinations per tier, each combination
 * itself AND/OR across the Categories and Signatory Groups it lists.
 */
@Service
@RequiredArgsConstructor
public class TierCombinationService implements ChangeApplier {

    private static final int MAX_COMBINATIONS_PER_TIER = 8;

    private final TierCombinationRepository tierCombinationRepository;
    private final LimitTierRepository limitTierRepository;
    private final CategoryRepository categoryRepository;
    private final SignatoryGroupRepository signatoryGroupRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<TierCombination> findAll() {
        return tierCombinationRepository.findAll();
    }

    public TierCombination find(String id) {
        return tierCombinationRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Combination not found: " + id));
    }

    public ChangeRequest requestCreate(TierCombinationRequest request, String makerId) {
        validate(request);
        return changeRequestService.submit(SetupEntityType.TIER_COMBINATION, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, TierCombinationRequest request, String makerId) {
        find(id);
        validate(request);
        return changeRequestService.submit(SetupEntityType.TIER_COMBINATION, id, ChangeAction.UPDATE, request, makerId);
    }

    public ChangeRequest requestDelete(String id, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.TIER_COMBINATION, id, ChangeAction.DELETE, java.util.Map.of("id", id), makerId);
    }

    private void validate(TierCombinationRequest request) {
        if (!limitTierRepository.existsById(request.tierId())) {
            throw new ValidationException("Unknown tierId: " + request.tierId());
        }
        long existingForTier = tierCombinationRepository.findAll().stream()
                .filter(c -> c.getTier() != null && c.getTier().getId().equals(request.tierId()))
                .filter(c -> !c.getId().equals(request.id()))
                .count();
        if (existingForTier >= MAX_COMBINATIONS_PER_TIER) {
            throw new ValidationException("Maximum of " + MAX_COMBINATIONS_PER_TIER + " combinations already defined for tier " + request.tierId());
        }
        for (String catId : request.categoryIds()) {
            if (!categoryRepository.existsById(catId)) {
                throw new ValidationException("Unknown categoryId in combination: " + catId);
            }
        }
        if (request.signatoryGroupIds() != null) {
            for (String sgId : request.signatoryGroupIds()) {
                if (!signatoryGroupRepository.existsById(sgId)) {
                    throw new ValidationException("Unknown signatoryGroupId in combination: " + sgId);
                }
            }
        }
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.TIER_COMBINATION;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        TierCombinationRequest r = objectMapper.convertValue(payload, TierCombinationRequest.class);
        LimitTier tier = limitTierRepository.findById(r.tierId())
                .orElseThrow(() -> new NotFoundException("Tier not found: " + r.tierId()));
        tierCombinationRepository.save(TierCombination.builder()
                .id(r.id()).tier(tier).combinationType(r.combinationType())
                .sequenceRequired(r.sequenceRequired())
                .categoryIds(new HashSet<>(r.categoryIds()))
                .signatoryGroupIds(r.signatoryGroupIds() == null ? Set.of() : new HashSet<>(r.signatoryGroupIds()))
                .build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        TierCombinationRequest r = objectMapper.convertValue(payload, TierCombinationRequest.class);
        LimitTier tier = limitTierRepository.findById(r.tierId())
                .orElseThrow(() -> new NotFoundException("Tier not found: " + r.tierId()));
        TierCombination c = find(entityId);
        c.setTier(tier);
        c.setCombinationType(r.combinationType());
        c.setSequenceRequired(r.sequenceRequired());
        c.setCategoryIds(new HashSet<>(r.categoryIds()));
        c.setSignatoryGroupIds(r.signatoryGroupIds() == null ? Set.of() : new HashSet<>(r.signatoryGroupIds()));
        tierCombinationRepository.save(c);
    }

    @Override
    public void applyDelete(String entityId) {
        tierCombinationRepository.deleteById(entityId);
    }
}
