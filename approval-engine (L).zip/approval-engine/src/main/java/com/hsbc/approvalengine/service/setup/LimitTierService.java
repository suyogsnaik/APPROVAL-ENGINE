package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.LimitTierRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.LimitTierRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Feature 1.2 - Limit Tier Setup: up to 6 monetary tiers, each with min/max amount + currency. */
@Service
@RequiredArgsConstructor
public class LimitTierService implements ChangeApplier {

    private static final int MAX_TIERS = 6;

    private final LimitTierRepository limitTierRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<LimitTier> findAll() {
        return limitTierRepository.findAllByOrderByRankOrderAsc();
    }

    public LimitTier find(String id) {
        return limitTierRepository.findById(id).orElseThrow(() -> new NotFoundException("Tier not found: " + id));
    }

    public ChangeRequest requestCreate(LimitTierRequest request, String makerId) {
        if (limitTierRepository.existsById(request.id())) {
            throw new ValidationException("Tier already exists: " + request.id());
        }
        if (limitTierRepository.count() >= MAX_TIERS) {
            throw new ValidationException("Maximum of " + MAX_TIERS + " limit tiers already defined");
        }
        return changeRequestService.submit(SetupEntityType.LIMIT_TIER, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, LimitTierRequest request, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.LIMIT_TIER, id, ChangeAction.UPDATE, request, makerId);
    }

    public ChangeRequest requestDelete(String id, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.LIMIT_TIER, id, ChangeAction.DELETE, java.util.Map.of("id", id), makerId);
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.LIMIT_TIER;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        LimitTierRequest r = objectMapper.convertValue(payload, LimitTierRequest.class);
        limitTierRepository.save(LimitTier.builder()
                .id(r.id()).minAmount(r.minAmount()).maxAmount(r.maxAmount())
                .currency(r.currency()).rankOrder(r.rankOrder()).build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        LimitTierRequest r = objectMapper.convertValue(payload, LimitTierRequest.class);
        LimitTier t = find(entityId);
        t.setMinAmount(r.minAmount());
        t.setMaxAmount(r.maxAmount());
        t.setCurrency(r.currency());
        t.setRankOrder(r.rankOrder());
        limitTierRepository.save(t);
    }

    @Override
    public void applyDelete(String entityId) {
        limitTierRepository.deleteById(entityId);
    }
}
