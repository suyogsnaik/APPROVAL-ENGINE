package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

public record AppUserRequest(
        @NotBlank String id,
        @NotBlank String loginId,
        String displayName,
        String categoryId,
        boolean active
) {
}
