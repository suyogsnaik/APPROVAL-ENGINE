package com.hsbc.approvalengine.domain.enums;

/** How a user is entitled to Debit Accounts. */
public enum EntitlementType {
    ONE,
    MULTIPLE,
    ALL
}
