package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.LimitTier;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface LimitTierRepository extends JpaRepository<LimitTier, String> {
    List<LimitTier> findAllByOrderByRankOrderAsc();
}
