package com.hsbc.approvalengine.service.makerchecker;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.ChangeRequestStatus;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.exception.MakerCheckerException;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.repository.ChangeRequestRepository;
import com.hsbc.approvalengine.service.audit.AuditService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Generic Maker-Checker (dual control) engine used by every setup service in Epics 1 and 2.
 *
 * <p>A maker calls {@link #submit} with the target entity type/id, the action and the requested
 * new-state DTO. The change sits as {@code PENDING} until a <em>different</em> user (the
 * checker) calls {@link #approve} (which applies it via the matching {@link ChangeApplier}) or
 * {@link #reject} (which discards it). Every transition is audited.</p>
 *
 * <p>Every setup service (CategoryService, LimitTierService, ...) both implements
 * {@link ChangeApplier} <em>and</em> depends on this class to submit changes - a genuine
 * constructor-injection cycle. Rather than take {@code List<ChangeApplier>} as a constructor
 * argument (which Spring cannot resolve when the cycle runs through pure constructor injection),
 * this class resolves the appliers lazily from the {@link ApplicationContext} the first time one
 * is needed, once the whole context has finished starting up.</p>
 */
@Service
@Slf4j
public class ChangeRequestService {

    private final ChangeRequestRepository changeRequestRepository;
    private final AuditService auditService;
    private final ObjectMapper objectMapper;
    private final ApplicationContext applicationContext;
    private volatile Map<SetupEntityType, ChangeApplier> appliers;

    public ChangeRequestService(ChangeRequestRepository changeRequestRepository,
                                 AuditService auditService,
                                 ObjectMapper objectMapper,
                                 ApplicationContext applicationContext) {
        this.changeRequestRepository = changeRequestRepository;
        this.auditService = auditService;
        this.objectMapper = objectMapper;
        this.applicationContext = applicationContext;
    }

    private Map<SetupEntityType, ChangeApplier> appliers() {
        Map<SetupEntityType, ChangeApplier> local = appliers;
        if (local == null) {
            synchronized (this) {
                local = appliers;
                if (local == null) {
                    local = new EnumMap<>(SetupEntityType.class);
                    for (ChangeApplier applier : applicationContext.getBeansOfType(ChangeApplier.class).values()) {
                        local.put(applier.supports(), applier);
                    }
                    appliers = local;
                }
            }
        }
        return local;
    }

    @Transactional
    public ChangeRequest submit(SetupEntityType entityType, String entityId, ChangeAction action,
                                 Object payloadDto, String makerId) {
        String payloadJson;
        try {
            payloadJson = objectMapper.writeValueAsString(payloadDto);
        } catch (Exception e) {
            throw new IllegalStateException("Unable to serialise change request payload", e);
        }

        ChangeRequest cr = ChangeRequest.builder()
                .id("CR-" + UUID.randomUUID())
                .entityType(entityType)
                .entityId(entityId)
                .action(action)
                .payload(payloadJson)
                .status(ChangeRequestStatus.PENDING)
                .makerId(makerId)
                .build();
        changeRequestRepository.save(cr);

        auditService.log(entityType, entityId, AuditAction.SUBMIT_FOR_APPROVAL, makerId,
                action + " submitted for checker approval (changeRequestId=" + cr.getId() + ")");
        return cr;
    }

    @Transactional
    public ChangeRequest approve(String changeRequestId, String checkerId, String comment) {
        ChangeRequest cr = getPending(changeRequestId);

        if (checkerId.equals(cr.getMakerId())) {
            throw new MakerCheckerException("Checker must be different from Maker (segregation of duties): "
                    + "maker=" + cr.getMakerId());
        }

        ChangeApplier applier = appliers().get(cr.getEntityType());
        if (applier == null) {
            throw new IllegalStateException("No ChangeApplier registered for " + cr.getEntityType());
        }

        JsonNode payload;
        try {
            payload = objectMapper.readTree(cr.getPayload());
        } catch (Exception e) {
            throw new IllegalStateException("Corrupt change request payload", e);
        }

        switch (cr.getAction()) {
            case CREATE -> applier.applyCreate(cr.getEntityId(), payload);
            case UPDATE -> applier.applyUpdate(cr.getEntityId(), payload);
            case DELETE -> applier.applyDelete(cr.getEntityId());
        }

        cr.setStatus(ChangeRequestStatus.APPROVED);
        cr.setCheckerId(checkerId);
        cr.setDecidedAt(Instant.now());
        cr.setCheckerComment(comment);
        changeRequestRepository.save(cr);

        auditService.log(cr.getEntityType(), cr.getEntityId(), AuditAction.APPROVE, checkerId,
                "Checker approved " + cr.getAction() + " (changeRequestId=" + cr.getId() + ")"
                        + (comment != null ? " comment=" + comment : ""));
        return cr;
    }

    @Transactional
    public ChangeRequest reject(String changeRequestId, String checkerId, String comment) {
        ChangeRequest cr = getPending(changeRequestId);

        if (checkerId.equals(cr.getMakerId())) {
            throw new MakerCheckerException("Checker must be different from Maker (segregation of duties): "
                    + "maker=" + cr.getMakerId());
        }

        cr.setStatus(ChangeRequestStatus.REJECTED);
        cr.setCheckerId(checkerId);
        cr.setDecidedAt(Instant.now());
        cr.setCheckerComment(comment);
        changeRequestRepository.save(cr);

        auditService.log(cr.getEntityType(), cr.getEntityId(), AuditAction.REJECT, checkerId,
                "Checker rejected " + cr.getAction() + " (changeRequestId=" + cr.getId() + ")"
                        + (comment != null ? " comment=" + comment : ""));
        return cr;
    }

    public List<ChangeRequest> pending() {
        return changeRequestRepository.findByStatus(ChangeRequestStatus.PENDING);
    }

    public List<ChangeRequest> pendingFor(SetupEntityType entityType) {
        return changeRequestRepository.findByEntityTypeAndStatus(entityType, ChangeRequestStatus.PENDING);
    }

    private ChangeRequest getPending(String changeRequestId) {
        ChangeRequest cr = changeRequestRepository.findById(changeRequestId)
                .orElseThrow(() -> new NotFoundException("ChangeRequest not found: " + changeRequestId));
        if (cr.getStatus() != ChangeRequestStatus.PENDING) {
            throw new MakerCheckerException("ChangeRequest " + changeRequestId + " already " + cr.getStatus());
        }
        return cr;
    }
}
