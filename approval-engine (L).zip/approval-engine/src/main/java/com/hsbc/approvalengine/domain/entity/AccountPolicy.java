package com.hsbc.approvalengine.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Fallback approval policy applied per Debit Account when no Beneficiary/Group policy exists. */
@Entity
@Table(name = "account_policies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AccountPolicy {

    @Id
    @Column(length = 50)
    private String id;

    @Column(name = "debit_account_id", length = 50, nullable = false)
    private String debitAccountId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tier_id")
    private LimitTier tier;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "combination_id")
    private TierCombination combination;

    @Column(name = "is_active")
    @Builder.Default
    private boolean active = true;
}
