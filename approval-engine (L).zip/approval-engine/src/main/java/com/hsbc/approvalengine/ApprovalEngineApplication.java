package com.hsbc.approvalengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * HSBC Corporate Digital Channels - File-Based Payments Approval Engine.
 *
 * <p>Determines who can approve file-based payments based on Debit Account,
 * Beneficiary/Beneficiary Group, User Entitlement, Amount Tier, Category /
 * Signatory Group combinations, approval sequence (Random/Sequential) and
 * Dual Control / Self-Approval restrictions. Once a File is fully approved
 * it is released to the Back Office for execution.</p>
 */
@SpringBootApplication
public class ApprovalEngineApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApprovalEngineApplication.class, args);
    }
}
