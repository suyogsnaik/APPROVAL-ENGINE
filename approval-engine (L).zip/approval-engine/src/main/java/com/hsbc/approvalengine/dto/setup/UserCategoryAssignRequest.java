package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

public record UserCategoryAssignRequest(
        @NotBlank String userId,
        @NotBlank String categoryId
) {
}
