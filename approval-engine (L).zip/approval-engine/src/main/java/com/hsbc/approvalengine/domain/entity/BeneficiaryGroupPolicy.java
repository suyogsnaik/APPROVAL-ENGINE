package com.hsbc.approvalengine.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Second-priority policy: applies when no Beneficiary-level policy exists, overrides Account policy. */
@Entity
@Table(name = "beneficiary_group_policies")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BeneficiaryGroupPolicy {

    @Id
    @Column(length = 50)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "beneficiary_group_id")
    private BeneficiaryGroup beneficiaryGroup;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tier_id")
    private LimitTier tier;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "combination_id")
    private TierCombination combination;

    @Column(name = "is_active")
    @Builder.Default
    private boolean active = true;
}
