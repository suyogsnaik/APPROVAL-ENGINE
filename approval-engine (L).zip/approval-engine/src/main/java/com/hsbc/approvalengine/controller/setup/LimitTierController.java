package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.LimitTierRequest;
import com.hsbc.approvalengine.service.setup.LimitTierService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/tier - Feature 1.2: Define monetary tiers (up to 6). */
@RestController
@RequestMapping("/setup/tier")
@RequiredArgsConstructor
public class LimitTierController {

    private final LimitTierService limitTierService;

    @GetMapping
    public List<LimitTier> findAll() {
        return limitTierService.findAll();
    }

    @GetMapping("/{id}")
    public LimitTier find(@PathVariable String id) {
        return limitTierService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody LimitTierRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(limitTierService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody LimitTierRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(limitTierService.requestUpdate(id, request, makerId));
    }

    @DeleteMapping("/{id}")
    public ChangeRequestResponse delete(@PathVariable String id, @RequestParam String makerId) {
        return ChangeRequestResponse.from(limitTierService.requestDelete(id, makerId));
    }
}
