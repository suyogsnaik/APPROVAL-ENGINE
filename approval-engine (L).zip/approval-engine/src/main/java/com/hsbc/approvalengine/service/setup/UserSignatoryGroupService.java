package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.SignatoryGroup;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.UserSignatoryGroupAssignRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.repository.SignatoryGroupRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.stream.Collectors;

/** Feature 2.1 (cont.) - Assign users to Signatory Groups (a user may belong to multiple groups). */
@Service
@RequiredArgsConstructor
public class UserSignatoryGroupService implements ChangeApplier {

    private final AppUserRepository appUserRepository;
    private final SignatoryGroupRepository signatoryGroupRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public ChangeRequest requestAssign(UserSignatoryGroupAssignRequest request, String makerId) {
        if (!appUserRepository.existsById(request.userId())) {
            throw new ValidationException("Unknown userId: " + request.userId());
        }
        for (String sg : request.signatoryGroupIds()) {
            if (!signatoryGroupRepository.existsById(sg)) {
                throw new ValidationException("Unknown signatoryGroupId: " + sg);
            }
        }
        return changeRequestService.submit(SetupEntityType.USER_SIGNATORY_GROUP, request.userId(),
                ChangeAction.UPDATE, request, makerId);
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.USER_SIGNATORY_GROUP;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        applyUpdate(entityId, payload);
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        UserSignatoryGroupAssignRequest r = objectMapper.convertValue(payload, UserSignatoryGroupAssignRequest.class);
        AppUser user = appUserRepository.findById(r.userId())
                .orElseThrow(() -> new NotFoundException("User not found: " + r.userId()));
        var groups = r.signatoryGroupIds().stream()
                .map(id -> signatoryGroupRepository.findById(id)
                        .orElseThrow(() -> new NotFoundException("Signatory group not found: " + id)))
                .collect(Collectors.toCollection(HashSet<SignatoryGroup>::new));
        user.setSignatoryGroups(groups);
        appUserRepository.save(user);
    }

    @Override
    public void applyDelete(String entityId) {
        AppUser user = appUserRepository.findById(entityId)
                .orElseThrow(() -> new NotFoundException("User not found: " + entityId));
        user.setSignatoryGroups(new HashSet<>());
        appUserRepository.save(user);
    }
}
