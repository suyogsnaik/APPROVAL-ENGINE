package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.UserCategoryAssignRequest;
import com.hsbc.approvalengine.service.setup.UserCategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** POST /setup/user-category - Feature 1.1 US2: assign a Category to a User. */
@RestController
@RequestMapping("/setup/user-category")
@RequiredArgsConstructor
public class UserCategoryController {

    private final UserCategoryService userCategoryService;

    @PostMapping
    public ChangeRequestResponse assign(@Valid @RequestBody UserCategoryAssignRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(userCategoryService.requestAssign(request, makerId));
    }
}
