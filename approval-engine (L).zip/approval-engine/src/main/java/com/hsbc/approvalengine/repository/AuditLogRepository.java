package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.AuditLog;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AuditLogRepository extends JpaRepository<AuditLog, String> {
    List<AuditLog> findByEntityTypeAndEntityIdOrderByPerformedAtDesc(SetupEntityType entityType, String entityId);
    List<AuditLog> findAllByOrderByPerformedAtDesc();
}
