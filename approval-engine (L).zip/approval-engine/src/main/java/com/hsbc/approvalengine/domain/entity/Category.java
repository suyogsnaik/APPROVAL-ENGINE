package com.hsbc.approvalengine.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Authorisation Category (A-N, up to 14) representing user seniority, e.g. CFO -> Cat A. */
@Entity
@Table(name = "categories")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Category {

    @Id
    @Column(length = 20)
    private String id; // e.g. "A".."N"

    @Column(length = 100)
    private String name;

    @Column(length = 255)
    private String description;
}
