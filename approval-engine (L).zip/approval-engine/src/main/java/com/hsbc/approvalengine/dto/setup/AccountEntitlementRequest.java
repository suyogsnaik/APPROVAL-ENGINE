package com.hsbc.approvalengine.dto.setup;

import com.hsbc.approvalengine.domain.enums.EntitlementType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

public record AccountEntitlementRequest(
        @NotBlank String userId,
        @NotBlank String debitAccountId,
        @NotNull EntitlementType entitlementType
) {
}
