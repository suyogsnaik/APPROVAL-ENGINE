package com.hsbc.approvalengine.dto.engine;

import com.hsbc.approvalengine.domain.enums.ViolationType;

import java.util.List;

/** POST /approval/validate response, per API spec 3.2. */
public record ValidateResponse(
        boolean isEligible,
        List<ViolationType> violations
) {
    public static ValidateResponse from(EligibilityResult r) {
        return new ValidateResponse(r.eligible(), r.violations());
    }
}
