package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.Beneficiary;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BeneficiaryRepository extends JpaRepository<Beneficiary, String> {
}
