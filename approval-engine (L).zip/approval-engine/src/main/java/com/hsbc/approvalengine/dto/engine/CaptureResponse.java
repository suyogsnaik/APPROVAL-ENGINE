package com.hsbc.approvalengine.dto.engine;

/** POST /approval/capture response, per API spec 3.3. */
public record CaptureResponse(
        String paymentStatus,
        int remainingStages
) {
}
