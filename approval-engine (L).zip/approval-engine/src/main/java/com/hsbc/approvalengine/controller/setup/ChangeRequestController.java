package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.common.ChangeRequestActionRequest;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Generic Maker-Checker inbox: every pending setup change across all entity types lands here for a Checker. */
@RestController
@RequestMapping("/setup/change-requests")
@RequiredArgsConstructor
public class ChangeRequestController {

    private final ChangeRequestService changeRequestService;

    @GetMapping
    public List<ChangeRequestResponse> pending(@RequestParam(required = false) SetupEntityType entityType) {
        List<ChangeRequest> list = entityType == null ? changeRequestService.pending() : changeRequestService.pendingFor(entityType);
        return list.stream().map(ChangeRequestResponse::from).toList();
    }

    @PostMapping("/{id}/approve")
    public ChangeRequestResponse approve(@PathVariable String id, @Valid @RequestBody ChangeRequestActionRequest request) {
        return ChangeRequestResponse.from(changeRequestService.approve(id, request.checkerId(), request.comment()));
    }

    @PostMapping("/{id}/reject")
    public ChangeRequestResponse reject(@PathVariable String id, @Valid @RequestBody ChangeRequestActionRequest request) {
        return ChangeRequestResponse.from(changeRequestService.reject(id, request.checkerId(), request.comment()));
    }
}
