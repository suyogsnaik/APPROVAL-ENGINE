package com.hsbc.approvalengine.domain.entity;

import com.hsbc.approvalengine.domain.enums.BatchStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

/**
 * A group of payments sharing the same Debit Account within a File. Indexed on {@code file_id}
 * (status roll-up/cascade queries in StatusQueryService and ApprovalCaptureService) and {@code
 * debit_account_id} (the FileAccessService visibility check and the Dashboard's entitlement-
 * scoped query) so those stay index lookups rather than table scans as files scale to 100k lines.
 */
@Entity
@Table(name = "batches", indexes = {
        @Index(name = "idx_batch_file_id", columnList = "file_id"),
        @Index(name = "idx_batch_file_id_status", columnList = "file_id,status"),
        @Index(name = "idx_batch_debit_account_id", columnList = "debit_account_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Batch {

    @Id
    @Column(length = 50)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "file_id")
    private PaymentFile file;

    @Column(name = "debit_account_id", length = 50, nullable = false)
    private String debitAccountId;

    @Enumerated(EnumType.STRING)
    @Column(length = 20, nullable = false)
    @Builder.Default
    private BatchStatus status = BatchStatus.IN_APPROVAL;

    @Column(name = "created_at")
    @Builder.Default
    private Instant createdAt = Instant.now();

    @OneToMany(mappedBy = "batch", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<Payment> payments = new ArrayList<>();
}
