package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.AccountPolicy;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.AccountPolicyRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.AccountPolicyRepository;
import com.hsbc.approvalengine.repository.LimitTierRepository;
import com.hsbc.approvalengine.repository.TierCombinationRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Feature 1.4 - Account-Level Approval Policy: fallback rules per Debit Account (Tier -> Combination). */
@Service
@RequiredArgsConstructor
public class AccountPolicyService implements ChangeApplier {

    private final AccountPolicyRepository accountPolicyRepository;
    private final LimitTierRepository limitTierRepository;
    private final TierCombinationRepository tierCombinationRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<AccountPolicy> findAll() {
        return accountPolicyRepository.findAll();
    }

    public List<AccountPolicy> findByAccount(String debitAccountId) {
        return accountPolicyRepository.findByDebitAccountIdAndActiveTrue(debitAccountId);
    }

    public AccountPolicy find(String id) {
        return accountPolicyRepository.findById(id).orElseThrow(() -> new NotFoundException("Account policy not found: " + id));
    }

    public ChangeRequest requestCreate(AccountPolicyRequest request, String makerId) {
        validate(request);
        return changeRequestService.submit(SetupEntityType.ACCOUNT_POLICY, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, AccountPolicyRequest request, String makerId) {
        find(id);
        validate(request);
        return changeRequestService.submit(SetupEntityType.ACCOUNT_POLICY, id, ChangeAction.UPDATE, request, makerId);
    }

    public ChangeRequest requestDelete(String id, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.ACCOUNT_POLICY, id, ChangeAction.DELETE, java.util.Map.of("id", id), makerId);
    }

    private void validate(AccountPolicyRequest r) {
        if (!limitTierRepository.existsById(r.tierId())) {
            throw new ValidationException("Unknown tierId: " + r.tierId());
        }
        if (!tierCombinationRepository.existsById(r.combinationId())) {
            throw new ValidationException("Unknown combinationId: " + r.combinationId());
        }
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.ACCOUNT_POLICY;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        AccountPolicyRequest r = objectMapper.convertValue(payload, AccountPolicyRequest.class);
        LimitTier tier = limitTierRepository.getReferenceById(r.tierId());
        TierCombination combo = tierCombinationRepository.getReferenceById(r.combinationId());
        accountPolicyRepository.save(AccountPolicy.builder()
                .id(r.id()).debitAccountId(r.debitAccountId()).tier(tier).combination(combo).active(r.active())
                .build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        AccountPolicyRequest r = objectMapper.convertValue(payload, AccountPolicyRequest.class);
        AccountPolicy p = find(entityId);
        p.setDebitAccountId(r.debitAccountId());
        p.setTier(limitTierRepository.getReferenceById(r.tierId()));
        p.setCombination(tierCombinationRepository.getReferenceById(r.combinationId()));
        p.setActive(r.active());
        accountPolicyRepository.save(p);
    }

    @Override
    public void applyDelete(String entityId) {
        accountPolicyRepository.deleteById(entityId);
    }
}
