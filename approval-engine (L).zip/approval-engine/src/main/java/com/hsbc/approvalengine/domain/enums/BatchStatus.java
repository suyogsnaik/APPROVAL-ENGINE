package com.hsbc.approvalengine.domain.enums;

public enum BatchStatus {
    IN_APPROVAL,
    APPROVED,
    REJECTED
}
