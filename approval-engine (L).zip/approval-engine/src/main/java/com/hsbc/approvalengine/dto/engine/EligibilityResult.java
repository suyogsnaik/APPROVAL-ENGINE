package com.hsbc.approvalengine.dto.engine;

import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.domain.enums.ViolationType;

import java.util.List;

/**
 * Result of the Entitlement Validator (Feature 4.4) + Sequence Engine (Feature 4.5) for one
 * (user, payment) approval attempt. When {@code eligible} is true, {@code matchedCombination}
 * and {@code matchedStage} identify which OR-combination / stage the approval will be recorded
 * against.
 */
public record EligibilityResult(
        boolean eligible,
        List<ViolationType> violations,
        TierCombination matchedCombination,
        String matchedCategoryId,
        String matchedSignatoryGroupId,
        Integer matchedStage
) {
    public static EligibilityResult ineligible(List<ViolationType> violations) {
        return new EligibilityResult(false, violations, null, null, null, null);
    }

    public static EligibilityResult eligible(TierCombination combo, String categoryId, String signGroupId, Integer stage) {
        return new EligibilityResult(true, List.of(), combo, categoryId, signGroupId, stage);
    }
}
