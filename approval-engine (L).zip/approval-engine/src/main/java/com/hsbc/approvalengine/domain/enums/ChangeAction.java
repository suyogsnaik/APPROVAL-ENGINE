package com.hsbc.approvalengine.domain.enums;

public enum ChangeAction {
    CREATE,
    UPDATE,
    DELETE
}
