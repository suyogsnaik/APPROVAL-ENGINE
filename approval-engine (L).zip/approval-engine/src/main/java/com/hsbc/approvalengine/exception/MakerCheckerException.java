package com.hsbc.approvalengine.exception;

/** Thrown when Maker-Checker segregation of duties is violated, e.g. checker == maker. */
public class MakerCheckerException extends RuntimeException {
    public MakerCheckerException(String message) {
        super(message);
    }
}
