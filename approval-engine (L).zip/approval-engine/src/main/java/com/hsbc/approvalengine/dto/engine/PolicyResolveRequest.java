package com.hsbc.approvalengine.dto.engine;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/** POST /approval/policy/resolve request body, per API spec 3.1. */
public record PolicyResolveRequest(
        @NotBlank String debitAccountId,
        String beneficiaryId,
        String beneficiaryGroupId, // accepted for API-spec compatibility; resolved from beneficiaryId internally
        @NotNull BigDecimal amount,
        @NotBlank String currency
) {
}
