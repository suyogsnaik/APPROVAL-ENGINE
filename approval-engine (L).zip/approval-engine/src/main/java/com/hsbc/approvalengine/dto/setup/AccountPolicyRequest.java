package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

public record AccountPolicyRequest(
        @NotBlank String id,
        @NotBlank String debitAccountId,
        @NotBlank String tierId,
        @NotBlank String combinationId,
        boolean active
) {
}
