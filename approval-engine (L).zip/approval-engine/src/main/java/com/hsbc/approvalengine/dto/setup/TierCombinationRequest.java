package com.hsbc.approvalengine.dto.setup;

import com.hsbc.approvalengine.domain.enums.CombinationType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;

import java.util.Set;

/** Up to 8 OR-based combinations per tier; each combination is AND or OR across its own members. */
public record TierCombinationRequest(
        @NotBlank String id,
        @NotBlank String tierId,
        @NotNull CombinationType combinationType,
        boolean sequenceRequired,
        @NotEmpty Set<String> categoryIds,
        Set<String> signatoryGroupIds
) {
}
