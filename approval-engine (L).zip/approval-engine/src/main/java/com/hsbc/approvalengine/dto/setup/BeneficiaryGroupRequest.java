package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

public record BeneficiaryGroupRequest(
        @NotBlank String id,
        @NotBlank String name
) {
}
