package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface PaymentRepository extends JpaRepository<Payment, String> {

    List<Payment> findByBatch_Id(String batchId);

    /** Paginated - a single Batch inside a 100k-line File can itself hold tens of thousands of payments. */
    Page<Payment> findByBatch_Id(String batchId, Pageable pageable);

    List<Payment> findByBatch_File_Id(String fileId);

    List<Payment> findByStatus(PaymentStatus status);

    // --- COUNT-based queries: used for status/cascade checks on large files so we never load
    //     every Payment row into memory just to answer "are they all approved yet?". ---

    long countByBatch_Id(String batchId);

    long countByBatch_IdAndStatusNot(String batchId, PaymentStatus status);

    long countByBatch_File_Id(String fileId);

    long countByBatch_File_IdAndStatus(String fileId, PaymentStatus status);

    // --- Dashboard scoping: fetch only the pending/partially-approved payments for the Debit
    //     Accounts a user is actually entitled to, one page at a time, instead of scanning every
    //     pending payment system-wide. ---

    Page<Payment> findByStatusInAndBatch_DebitAccountIdIn(Collection<PaymentStatus> statuses, Collection<String> debitAccountIds, Pageable pageable);

    /** Used only for a user holding an EntitlementType.ALL entitlement (no account list to filter by). */
    Page<Payment> findByStatusIn(Collection<PaymentStatus> statuses, Pageable pageable);

    /**
     * Surfaces which approval policy the engine actually applied within a File, once it is
     * visible to the caller. One row per distinct (policy level, policy id, tier), aggregated in
     * the database - bounded by the number of distinct policies in play, not by how many payment
     * lines the file holds, so this is safe to run even for a 100k-line file.
     */
    @Query("SELECT p.appliedPolicyType as policyType, p.appliedPolicyId as policyId, p.appliedTier.id as tierId, COUNT(p) as paymentCount " +
            "FROM Payment p WHERE p.batch.file.id = :fileId AND p.appliedPolicyType IS NOT NULL " +
            "GROUP BY p.appliedPolicyType, p.appliedPolicyId, p.appliedTier.id")
    List<AppliedPolicySummaryProjection> summarizeAppliedPolicies(@Param("fileId") String fileId);
}
