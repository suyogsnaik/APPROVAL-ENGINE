package com.hsbc.approvalengine.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

/**
 * A corporate portal user. Maps to the {@code users} table in the spec (renamed to
 * {@code app_users} because USER is a reserved word in several SQL dialects, including H2).
 */
@Entity
@Table(name = "app_users")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AppUser {

    @Id
    @Column(length = 50)
    private String id;

    @Column(name = "login_id", length = 100, unique = true, nullable = false)
    private String loginId;

    @Column(name = "display_name", length = 200)
    private String displayName;

    /** FK -> categories.id. Each corporate user is assigned exactly one Category (A-N). */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "category_id")
    private Category category;

    @Column(name = "is_active", nullable = false)
    @Builder.Default
    private boolean active = true;

    @ManyToMany
    @JoinTable(
            name = "user_signatory_group",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "signatory_group_id")
    )
    @Builder.Default
    private Set<SignatoryGroup> signatoryGroups = new HashSet<>();
}
