package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.Beneficiary;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.BeneficiaryRequest;
import com.hsbc.approvalengine.service.setup.BeneficiaryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/beneficiary - beneficiary maintenance (PRD 3.6), always Maker-Checker governed. */
@RestController
@RequestMapping("/setup/beneficiary")
@RequiredArgsConstructor
public class BeneficiaryController {

    private final BeneficiaryService beneficiaryService;

    @GetMapping
    public List<Beneficiary> findAll() {
        return beneficiaryService.findAll();
    }

    @GetMapping("/{id}")
    public Beneficiary find(@PathVariable String id) {
        return beneficiaryService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody BeneficiaryRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody BeneficiaryRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryService.requestUpdate(id, request, makerId));
    }
}
