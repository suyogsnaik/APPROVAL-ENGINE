package com.hsbc.approvalengine.controller.engine;

import com.hsbc.approvalengine.domain.entity.AuditLog;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Feature 5.2 - Audit Logging query API: US39-41. */
@RestController
@RequiredArgsConstructor
public class AuditController {

    private final AuditLogRepository auditLogRepository;

    @GetMapping("/audit")
    public List<AuditLog> query(@RequestParam(required = false) SetupEntityType entityType,
                                 @RequestParam(required = false) String entityId) {
        if (entityType != null && entityId != null) {
            return auditLogRepository.findByEntityTypeAndEntityIdOrderByPerformedAtDesc(entityType, entityId);
        }
        return auditLogRepository.findAllByOrderByPerformedAtDesc();
    }
}
