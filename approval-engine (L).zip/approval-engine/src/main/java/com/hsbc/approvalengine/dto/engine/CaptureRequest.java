package com.hsbc.approvalengine.dto.engine;

import jakarta.validation.constraints.NotBlank;

/** POST /approval/capture request body, per API spec 3.3. */
public record CaptureRequest(
        @NotBlank String userId,
        @NotBlank String paymentId
) {
}
