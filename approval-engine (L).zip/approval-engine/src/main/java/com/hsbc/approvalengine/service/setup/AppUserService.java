package com.hsbc.approvalengine.service.setup;

import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.Category;
import com.hsbc.approvalengine.dto.setup.AppUserRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.repository.CategoryRepository;
import com.hsbc.approvalengine.service.audit.AuditService;
import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Plain administrative provisioning for corporate portal users - identity/HR-fed data that sits
 * outside the Approval Engine's own Maker-Checker backlog (Epics 1-2 govern what a user is
 * *entitled to*, not user provisioning itself, which the PRD treats as out-of-scope ERP/HR
 * integration). Kept simple and unguarded so the rest of the engine has users to work with.
 */
@Service
@RequiredArgsConstructor
public class AppUserService {

    private final AppUserRepository appUserRepository;
    private final CategoryRepository categoryRepository;
    private final AuditService auditService;

    public List<AppUser> findAll() {
        return appUserRepository.findAll();
    }

    public AppUser find(String id) {
        return appUserRepository.findById(id).orElseThrow(() -> new NotFoundException("User not found: " + id));
    }

    public AppUser createOrUpdate(AppUserRequest request, String performedBy) {
        Category category = request.categoryId() == null ? null : categoryRepository.findById(request.categoryId())
                .orElseThrow(() -> new NotFoundException("Category not found: " + request.categoryId()));
        AppUser user = appUserRepository.findById(request.id()).orElse(AppUser.builder().id(request.id()).build());
        user.setLoginId(request.loginId());
        user.setDisplayName(request.displayName());
        user.setCategory(category);
        user.setActive(request.active());
        appUserRepository.save(user);
        auditService.log(SetupEntityType.USER, user.getId(), AuditAction.CREATE, performedBy, "User provisioned/updated: " + user.getLoginId());
        return user;
    }
}
