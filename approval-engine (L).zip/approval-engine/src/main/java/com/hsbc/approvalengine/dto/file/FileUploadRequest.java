package com.hsbc.approvalengine.dto.file;

import jakarta.validation.constraints.NotBlank;

/**
 * Body for POST /file/upload. {@code content} is the raw file text (CSV or XML) - kept as a JSON
 * string field rather than multipart so the API matches the spec's minimal REST style; a real
 * front-door would accept multipart/form-data and stream it through the same parser.
 */
public record FileUploadRequest(
        @NotBlank String clientId,
        @NotBlank String fileName,
        @NotBlank String format, // "csv" | "xml"
        @NotBlank String content,
        @NotBlank String uploadedBy
) {
}
