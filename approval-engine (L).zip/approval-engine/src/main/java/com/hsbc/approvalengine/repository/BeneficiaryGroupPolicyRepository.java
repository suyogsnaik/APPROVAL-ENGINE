package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.BeneficiaryGroupPolicy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface BeneficiaryGroupPolicyRepository extends JpaRepository<BeneficiaryGroupPolicy, String> {
    List<BeneficiaryGroupPolicy> findByBeneficiaryGroup_IdAndActiveTrue(String beneficiaryGroupId);
    List<BeneficiaryGroupPolicy> findByBeneficiaryGroup_IdAndTier_IdAndActiveTrue(String beneficiaryGroupId, String tierId);

    /** Bulk variant for large-file policy resolution: one query for every Beneficiary Group in the file instead of one per line. */
    List<BeneficiaryGroupPolicy> findByBeneficiaryGroup_IdInAndActiveTrue(Collection<String> beneficiaryGroupIds);
}
