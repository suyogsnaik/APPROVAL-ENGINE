package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.BeneficiaryGroup;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.BeneficiaryGroupRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.BeneficiaryGroupRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BeneficiaryGroupService implements ChangeApplier {

    private final BeneficiaryGroupRepository repository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<BeneficiaryGroup> findAll() {
        return repository.findAll();
    }

    public BeneficiaryGroup find(String id) {
        return repository.findById(id).orElseThrow(() -> new NotFoundException("Beneficiary group not found: " + id));
    }

    public ChangeRequest requestCreate(BeneficiaryGroupRequest request, String makerId) {
        if (repository.existsById(request.id())) {
            throw new ValidationException("Beneficiary group already exists: " + request.id());
        }
        return changeRequestService.submit(SetupEntityType.BENEFICIARY_GROUP, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, BeneficiaryGroupRequest request, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY_GROUP, id, ChangeAction.UPDATE, request, makerId);
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.BENEFICIARY_GROUP;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        BeneficiaryGroupRequest r = objectMapper.convertValue(payload, BeneficiaryGroupRequest.class);
        repository.save(BeneficiaryGroup.builder().id(r.id()).name(r.name()).build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        BeneficiaryGroupRequest r = objectMapper.convertValue(payload, BeneficiaryGroupRequest.class);
        BeneficiaryGroup g = find(entityId);
        g.setName(r.name());
        repository.save(g);
    }

    @Override
    public void applyDelete(String entityId) {
        repository.deleteById(entityId);
    }
}
