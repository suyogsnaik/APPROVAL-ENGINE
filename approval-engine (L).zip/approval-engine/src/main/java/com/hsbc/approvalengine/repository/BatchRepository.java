package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.domain.enums.BatchStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface BatchRepository extends JpaRepository<Batch, String> {

    /** Bounded by the number of distinct Debit Accounts in the file, not its transaction count - fine as a List even for a 100k-line file. */
    List<Batch> findByFile_Id(String fileId);

    long countByFile_Id(String fileId);

    long countByFile_IdAndStatus(String fileId, BatchStatus status);
}
