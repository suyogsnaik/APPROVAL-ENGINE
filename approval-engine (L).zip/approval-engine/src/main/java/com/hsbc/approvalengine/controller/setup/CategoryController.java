package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.Category;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.CategoryRequest;
import com.hsbc.approvalengine.service.setup.CategoryService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/category - Feature 1.1: Create/update/delete Categories (A-N). All via Maker-Checker. */
@RestController
@RequestMapping("/setup/category")
@RequiredArgsConstructor
public class CategoryController {

    private final CategoryService categoryService;

    @GetMapping
    public List<Category> findAll() {
        return categoryService.findAll();
    }

    @GetMapping("/{id}")
    public Category find(@PathVariable String id) {
        return categoryService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody CategoryRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(categoryService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody CategoryRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(categoryService.requestUpdate(id, request, makerId));
    }

    @DeleteMapping("/{id}")
    public ChangeRequestResponse delete(@PathVariable String id, @RequestParam String makerId) {
        return ChangeRequestResponse.from(categoryService.requestDelete(id, makerId));
    }
}
