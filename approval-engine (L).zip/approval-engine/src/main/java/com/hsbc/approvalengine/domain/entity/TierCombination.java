package com.hsbc.approvalengine.domain.entity;

import com.hsbc.approvalengine.domain.enums.CombinationType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

/**
 * Up to 8 OR-based combinations per tier. Each combination lists the Categories and Signatory
 * Groups that must sign (AND = all required, OR = any one) to approve a payment in that tier.
 */
@Entity
@Table(name = "tier_combinations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TierCombination {

    @Id
    @Column(length = 50)
    private String id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tier_id")
    private LimitTier tier;

    @Enumerated(EnumType.STRING)
    @Column(name = "combination_type", length = 10)
    private CombinationType combinationType;

    @Column(name = "sequence_required")
    @Builder.Default
    private boolean sequenceRequired = false;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "tier_combination_categories", joinColumns = @JoinColumn(name = "combination_id"))
    @Column(name = "category_id")
    @Builder.Default
    private Set<String> categoryIds = new HashSet<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "tier_combination_sign_groups", joinColumns = @JoinColumn(name = "combination_id"))
    @Column(name = "signatory_group_id")
    @Builder.Default
    private Set<String> signatoryGroupIds = new HashSet<>();
}
