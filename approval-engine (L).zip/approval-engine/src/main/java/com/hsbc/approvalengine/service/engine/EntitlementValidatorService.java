package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.Approval;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.domain.enums.ViolationType;
import com.hsbc.approvalengine.dto.engine.EligibilityResult;
import com.hsbc.approvalengine.repository.ApprovalRepository;
import com.hsbc.approvalengine.repository.SignatoryGroupRepository;
import com.hsbc.approvalengine.repository.TierCombinationRepository;
import com.hsbc.approvalengine.service.setup.AccountEntitlementService;
import com.hsbc.approvalengine.service.setup.SelfApprovalSettingService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * Feature 4.4 - Entitlement Validation (MRS 2.3.4). For a candidate approver + payment, checks
 * (in order): user active, account entitlement, self-approval restriction, not already approved
 * by this user, Category/Signatory-Group match against the payment's applied combinations, and
 * finally sequence order via {@link SequenceEngineService}. Mirrors POST /approval/validate.
 */
@Service
@RequiredArgsConstructor
public class EntitlementValidatorService {

    private final AccountEntitlementService accountEntitlementService;
    private final SelfApprovalSettingService selfApprovalSettingService;
    private final ApprovalRepository approvalRepository;
    private final TierCombinationRepository tierCombinationRepository;
    private final SignatoryGroupRepository signatoryGroupRepository;
    private final SequenceEngineService sequenceEngineService;

    public EligibilityResult validate(AppUser user, Payment payment) {
        List<ViolationType> violations = new ArrayList<>();

        if (!user.isActive()) {
            violations.add(ViolationType.USER_INACTIVE);
        }
        if (payment.getStatus() != PaymentStatus.PENDING && payment.getStatus() != PaymentStatus.PARTIALLY_APPROVED) {
            violations.add(ViolationType.PAYMENT_NOT_PENDING);
        }
        if (!accountEntitlementService.isEntitled(user.getId(), payment.getBatch().getDebitAccountId())) {
            violations.add(ViolationType.ACCOUNT_NOT_ENTITLED);
        }
        if (payment.getBeneficiary() != null && payment.getBeneficiary().getCreatedBy() != null
                && payment.getBeneficiary().getCreatedBy().getId().equals(user.getId())
                && selfApprovalSettingService.isRestricted(clientIdOf(payment))) {
            violations.add(ViolationType.SELF_APPROVAL_BLOCKED);
        }
        List<Approval> existing = approvalRepository.findByPayment_Id(payment.getId());
        boolean alreadyApproved = existing.stream().anyMatch(a -> a.getUser().getId().equals(user.getId()));
        if (alreadyApproved) {
            violations.add(ViolationType.ALREADY_APPROVED_BY_USER);
        }

        // Category / Signatory-Group role match against any of the payment's applied combinations.
        List<TierCombination> combos = tierCombinationRepository.findAllById(payment.getAppliedCombinationIds());
        MatchAttempt match = findBestMatch(user, combos, existing);

        if (match == null) {
            boolean anyCategoryConstraint = combos.stream().anyMatch(c -> !c.getCategoryIds().isEmpty());
            boolean anySignGroupConstraint = combos.stream().anyMatch(c -> !c.getSignatoryGroupIds().isEmpty());
            if (anyCategoryConstraint) {
                violations.add(ViolationType.CATEGORY_MISMATCH);
            }
            if (anySignGroupConstraint) {
                violations.add(ViolationType.SIGN_GROUP_MISMATCH);
            }
            if (!anyCategoryConstraint && !anySignGroupConstraint) {
                violations.add(ViolationType.NO_POLICY_FOUND);
            }
        } else if (!violations.contains(ViolationType.USER_INACTIVE) && !violations.contains(ViolationType.PAYMENT_NOT_PENDING)) {
            boolean sequenceOk = sequenceEngineService.isNextInSequence(match.combo, match.signGroupId, existing);
            if (!sequenceOk) {
                violations.add(ViolationType.SEQUENCE_ORDER);
            }
        }

        if (!violations.isEmpty()) {
            return EligibilityResult.ineligible(violations);
        }
        return EligibilityResult.eligible(match.combo, match.categoryId, match.signGroupId, match.stage);
    }

    private String clientIdOf(Payment payment) {
        return payment.getBatch().getFile().getClientId();
    }

    private record MatchAttempt(TierCombination combo, String categoryId, String signGroupId, Integer stage) {
    }

    /** Prefers a combination that isn't fully satisfied yet and where the user hasn't signed for that role. */
    private MatchAttempt findBestMatch(AppUser user, List<TierCombination> combos, List<Approval> existing) {
        String userCategoryId = user.getCategory() != null ? user.getCategory().getId() : null;
        var userGroupIds = user.getSignatoryGroups().stream().map(g -> g.getId()).toList();

        for (TierCombination combo : combos) {
            if (userCategoryId != null && combo.getCategoryIds().contains(userCategoryId)) {
                boolean roleAlreadyFilled = combo.getCombinationType() == com.hsbc.approvalengine.domain.enums.CombinationType.OR
                        && existing.stream().anyMatch(a -> combo.getCategoryIds().contains(a.getCategoryId()));
                if (!roleAlreadyFilled) {
                    return new MatchAttempt(combo, userCategoryId, null, null);
                }
            }
            for (String groupId : userGroupIds) {
                if (combo.getSignatoryGroupIds().contains(groupId)) {
                    boolean roleAlreadyFilled = combo.getCombinationType() == com.hsbc.approvalengine.domain.enums.CombinationType.OR
                            && existing.stream().anyMatch(a -> combo.getSignatoryGroupIds().contains(a.getSignatoryGroupId()));
                    if (!roleAlreadyFilled) {
                        return new MatchAttempt(combo, null, groupId, resolveStage(groupId));
                    }
                }
            }
        }
        return null;
    }

    private Integer resolveStage(String groupId) {
        return signatoryGroupRepository.findById(groupId).map(g -> g.getSequenceOrder()).orElse(null);
    }
}
