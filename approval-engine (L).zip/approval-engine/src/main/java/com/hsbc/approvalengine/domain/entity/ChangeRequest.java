package com.hsbc.approvalengine.domain.entity;

import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.ChangeRequestStatus;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * Generic Maker-Checker envelope. A "maker" submits a CREATE/UPDATE/DELETE against a setup
 * entity as a pending change; the requested new-state is captured as JSON in {@code payload}.
 * A "checker" (who must differ from the maker) then approves (the change is applied to the real
 * table) or rejects (the change is discarded) it. Every transition is written to {@link AuditLog}.
 */
@Entity
@Table(name = "change_requests")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ChangeRequest {

    @Id
    @Column(length = 50)
    private String id;

    @Enumerated(EnumType.STRING)
    @Column(name = "entity_type", length = 30, nullable = false)
    private SetupEntityType entityType;

    /** id of the target row (for UPDATE/DELETE); for CREATE this is the id the new row will get. */
    @Column(name = "entity_id", length = 50, nullable = false)
    private String entityId;

    @Enumerated(EnumType.STRING)
    @Column(length = 20, nullable = false)
    private ChangeAction action;

    /** JSON snapshot of the requested new state (the DTO submitted by the maker). */
    @Lob
    @Column(name = "payload", nullable = false)
    private String payload;

    @Enumerated(EnumType.STRING)
    @Column(length = 20, nullable = false)
    @Builder.Default
    private ChangeRequestStatus status = ChangeRequestStatus.PENDING;

    @Column(name = "maker_id", length = 50, nullable = false)
    private String makerId;

    @Column(name = "checker_id", length = 50)
    private String checkerId;

    @Column(name = "created_at")
    @Builder.Default
    private Instant createdAt = Instant.now();

    @Column(name = "decided_at")
    private Instant decidedAt;

    @Column(name = "checker_comment")
    private String checkerComment;
}
