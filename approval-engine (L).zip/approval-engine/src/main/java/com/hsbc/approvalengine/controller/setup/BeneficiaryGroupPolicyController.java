package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.BeneficiaryGroupPolicy;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.BeneficiaryGroupPolicyRequest;
import com.hsbc.approvalengine.service.setup.BeneficiaryGroupPolicyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/beneficiary-group-policy - Feature 1.5: approval rules per Beneficiary Group. */
@RestController
@RequestMapping("/setup/beneficiary-group-policy")
@RequiredArgsConstructor
public class BeneficiaryGroupPolicyController {

    private final BeneficiaryGroupPolicyService beneficiaryGroupPolicyService;

    @GetMapping
    public List<BeneficiaryGroupPolicy> findAll() {
        return beneficiaryGroupPolicyService.findAll();
    }

    @GetMapping("/{id}")
    public BeneficiaryGroupPolicy find(@PathVariable String id) {
        return beneficiaryGroupPolicyService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody BeneficiaryGroupPolicyRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryGroupPolicyService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody BeneficiaryGroupPolicyRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryGroupPolicyService.requestUpdate(id, request, makerId));
    }

    @DeleteMapping("/{id}")
    public ChangeRequestResponse delete(@PathVariable String id, @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryGroupPolicyService.requestDelete(id, makerId));
    }
}
