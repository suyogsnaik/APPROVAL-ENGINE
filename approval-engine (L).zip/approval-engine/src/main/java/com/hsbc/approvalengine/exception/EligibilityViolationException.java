package com.hsbc.approvalengine.exception;

import com.hsbc.approvalengine.domain.enums.ViolationType;

import java.util.List;

/** Thrown by POST /approval/capture when the Entitlement Validator / Sequence Engine reject the attempt. */
public class EligibilityViolationException extends RuntimeException {

    private final List<ViolationType> violations;

    public EligibilityViolationException(List<ViolationType> violations) {
        super("Approval rejected: " + violations);
        this.violations = violations;
    }

    public List<ViolationType> getViolations() {
        return violations;
    }
}
