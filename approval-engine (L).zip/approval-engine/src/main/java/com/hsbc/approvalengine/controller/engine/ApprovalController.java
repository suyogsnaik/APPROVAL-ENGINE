package com.hsbc.approvalengine.controller.engine;

import com.hsbc.approvalengine.domain.entity.Approval;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.dto.engine.*;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.service.engine.ApprovalCaptureService;
import com.hsbc.approvalengine.service.engine.PolicyResolverService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Feature 4 - Approval Engine Core REST surface, per API spec sections 3.1-3.3. */
@RestController
@RequiredArgsConstructor
public class ApprovalController {

    private final PolicyResolverService policyResolverService;
    private final ApprovalCaptureService approvalCaptureService;
    private final PaymentRepository paymentRepository;

    @PostMapping("/approval/policy/resolve")
    public PolicyResolveResponse resolvePolicy(@Valid @RequestBody PolicyResolveRequest request) {
        var resolved = policyResolverService.resolve(request.debitAccountId(), request.beneficiaryId(),
                request.amount(), request.currency());
        var combos = resolved.combinations().stream()
                .map(c -> new PolicyResolveResponse.RequiredCombination(
                        c.getId(), c.getCombinationType().name(), c.getCategoryIds().stream().toList(),
                        c.getSignatoryGroupIds().stream().toList()))
                .toList();
        return new PolicyResolveResponse(resolved.policyType(), resolved.tier().getId(), combos);
    }

    @PostMapping("/approval/validate")
    public ValidateResponse validate(@Valid @RequestBody ValidateRequest request) {
        return ValidateResponse.from(approvalCaptureService.validate(request.userId(), request.paymentId()));
    }

    @PostMapping("/approval/capture")
    public CaptureResponse capture(@Valid @RequestBody CaptureRequest request, @RequestParam(defaultValue = "SYSTEM") String performedBy) {
        Approval approval = approvalCaptureService.capture(request.userId(), request.paymentId(), performedBy);
        Payment payment = paymentRepository.findById(request.paymentId()).orElseThrow();
        int remaining = switch (payment.getStatus()) {
            case APPROVED -> 0;
            default -> 1;
        };
        return new CaptureResponse(payment.getStatus().name(), remaining);
    }
}
