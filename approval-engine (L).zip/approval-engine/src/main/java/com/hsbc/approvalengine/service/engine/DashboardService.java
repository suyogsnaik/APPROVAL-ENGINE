package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.dto.engine.DashboardItem;
import com.hsbc.approvalengine.dto.engine.EligibilityResult;
import com.hsbc.approvalengine.dto.engine.PolicyResolveResponse;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.repository.TierCombinationRepository;
import com.hsbc.approvalengine.service.setup.AccountEntitlementService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Feature 5.1 - Approval Dashboard: what a given user currently has open to approve.
 *
 * <p>Scoped and paginated for scale: rather than loading every pending/partially-approved
 * Payment system-wide (which does not scale once files run to tens of thousands of lines), this
 * queries only the Debit Accounts the user is actually entitled to - the same visibility rule
 * {@link FileAccessService} enforces per-file - and returns one page at a time. A user holding an
 * {@code EntitlementType.ALL} grant has no bounded account list, so their query is unscoped by
 * account but still paginated.</p>
 */
@Service
@RequiredArgsConstructor
public class DashboardService {

    private static final List<PaymentStatus> OPEN_STATUSES = List.of(PaymentStatus.PENDING, PaymentStatus.PARTIALLY_APPROVED);

    private final AppUserRepository appUserRepository;
    private final PaymentRepository paymentRepository;
    private final TierCombinationRepository tierCombinationRepository;
    private final AccountEntitlementService accountEntitlementService;
    private final EntitlementValidatorService entitlementValidatorService;

    public Page<DashboardItem> pendingFor(String userId, Pageable pageable) {
        AppUser user = appUserRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found: " + userId));

        AccountEntitlementService.EntitlementScope scope = accountEntitlementService.scopeFor(userId);
        Page<Payment> page;
        if (scope.allAccounts()) {
            page = paymentRepository.findByStatusIn(OPEN_STATUSES, pageable);
        } else if (scope.debitAccountIds().isEmpty()) {
            page = Page.empty(pageable); // no entitlements at all -> nothing is visible
        } else {
            page = paymentRepository.findByStatusInAndBatch_DebitAccountIdIn(OPEN_STATUSES, scope.debitAccountIds(), pageable);
        }

        return page.map(p -> toItem(user, p));
    }

    private DashboardItem toItem(AppUser user, Payment payment) {
        EligibilityResult result = entitlementValidatorService.validate(user, payment);
        var combos = tierCombinationRepository.findAllById(payment.getAppliedCombinationIds()).stream()
                .map(c -> new PolicyResolveResponse.RequiredCombination(
                        c.getId(), c.getCombinationType().name(), c.getCategoryIds().stream().toList(),
                        c.getSignatoryGroupIds().stream().toList()))
                .toList();

        return new DashboardItem(
                payment.getBatch().getFile().getId(),
                payment.getBatch().getId(),
                payment.getId(),
                payment.getBatch().getDebitAccountId(),
                payment.getBeneficiary() != null ? payment.getBeneficiary().getId() : null,
                payment.getAmount(),
                payment.getCurrency(),
                payment.getStatus(),
                combos,
                result.eligible(),
                result.violations()
        );
    }
}
