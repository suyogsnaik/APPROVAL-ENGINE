package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

public record BeneficiaryPolicyRequest(
        @NotBlank String id,
        @NotBlank String beneficiaryId,
        @NotBlank String tierId,
        @NotBlank String combinationId,
        boolean active
) {
}
