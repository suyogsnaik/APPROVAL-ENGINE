package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.BeneficiaryGroup;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BeneficiaryGroupRepository extends JpaRepository<BeneficiaryGroup, String> {
}
