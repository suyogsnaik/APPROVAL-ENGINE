package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.PaymentFile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PaymentFileRepository extends JpaRepository<PaymentFile, String> {
}
