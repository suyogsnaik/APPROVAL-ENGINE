package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.BeneficiaryGroup;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.BeneficiaryGroupRequest;
import com.hsbc.approvalengine.service.setup.BeneficiaryGroupService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/setup/beneficiary-group")
@RequiredArgsConstructor
public class BeneficiaryGroupController {

    private final BeneficiaryGroupService beneficiaryGroupService;

    @GetMapping
    public List<BeneficiaryGroup> findAll() {
        return beneficiaryGroupService.findAll();
    }

    @GetMapping("/{id}")
    public BeneficiaryGroup find(@PathVariable String id) {
        return beneficiaryGroupService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody BeneficiaryGroupRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryGroupService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody BeneficiaryGroupRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryGroupService.requestUpdate(id, request, makerId));
    }
}
