package com.hsbc.approvalengine.controller.engine;

import com.hsbc.approvalengine.dto.engine.DashboardItem;
import com.hsbc.approvalengine.service.engine.DashboardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

/** Feature 5.1 - GET /dashboard/pending/{userId}: US36-38. Paginated - see DashboardService. */
@RestController
@RequiredArgsConstructor
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/dashboard/pending/{userId}")
    public Page<DashboardItem> pending(@PathVariable String userId, @PageableDefault(size = 50) Pageable pageable) {
        return dashboardService.pendingFor(userId, pageable);
    }
}
