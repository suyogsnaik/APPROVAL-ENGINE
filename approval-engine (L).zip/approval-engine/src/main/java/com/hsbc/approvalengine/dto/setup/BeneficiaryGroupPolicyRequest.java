package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

public record BeneficiaryGroupPolicyRequest(
        @NotBlank String id,
        @NotBlank String beneficiaryGroupId,
        @NotBlank String tierId,
        @NotBlank String combinationId,
        boolean active
) {
}
