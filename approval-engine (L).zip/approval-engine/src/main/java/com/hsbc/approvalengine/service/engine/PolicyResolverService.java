package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.AccountPolicy;
import com.hsbc.approvalengine.domain.entity.Beneficiary;
import com.hsbc.approvalengine.domain.entity.BeneficiaryGroupPolicy;
import com.hsbc.approvalengine.domain.entity.BeneficiaryPolicy;
import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.domain.enums.PolicyType;
import com.hsbc.approvalengine.dto.engine.ResolvedPolicy;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.AccountPolicyRepository;
import com.hsbc.approvalengine.repository.BeneficiaryGroupPolicyRepository;
import com.hsbc.approvalengine.repository.BeneficiaryPolicyRepository;
import com.hsbc.approvalengine.repository.BeneficiaryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Feature 4.1 - Policy Resolution (MRS 2.3.1). Walks the hierarchy Beneficiary -&gt; Beneficiary
 * Group -&gt; Account (fallback), then resolves the Tier for the payment amount and returns the
 * OR-set of required Category/Signatory-Group combinations for that (policy level, tier) pair.
 *
 * <p>Once a policy level is found to apply to a Beneficiary (i.e. it has at least one active rule
 * defined, for any tier), that level owns the decision - PolicyResolver does not fall through to
 * a lower-priority level just because that level lacks a rule for this specific tier: TC1 in the
 * UAT pack requires the Beneficiary policy to win outright.</p>
 */
@Service
@RequiredArgsConstructor
public class PolicyResolverService {

    private final BeneficiaryRepository beneficiaryRepository;
    private final BeneficiaryPolicyRepository beneficiaryPolicyRepository;
    private final BeneficiaryGroupPolicyRepository beneficiaryGroupPolicyRepository;
    private final AccountPolicyRepository accountPolicyRepository;
    private final TierResolverService tierResolverService;

    public ResolvedPolicy resolve(String debitAccountId, String beneficiaryId, BigDecimal amount, String currency) {
        LimitTier tier = tierResolverService.resolveTier(amount, currency);

        Beneficiary beneficiary = beneficiaryId == null ? null :
                beneficiaryRepository.findById(beneficiaryId).orElse(null);

        // 1. Beneficiary-level policy (highest priority).
        if (beneficiary != null && !beneficiaryPolicyRepository.findByBeneficiary_IdAndActiveTrue(beneficiaryId).isEmpty()) {
            List<BeneficiaryPolicy> rows = beneficiaryPolicyRepository
                    .findByBeneficiary_IdAndTier_IdAndActiveTrue(beneficiaryId, tier.getId());
            if (rows.isEmpty()) {
                throw new ValidationException("Beneficiary " + beneficiaryId
                        + " has an active Beneficiary-level policy but none defined for tier " + tier.getId());
            }
            return new ResolvedPolicy(PolicyType.BENEFICIARY, beneficiaryId, tier,
                    rows.stream().map(BeneficiaryPolicy::getCombination).toList());
        }

        // 2. Beneficiary Group-level policy (fallback #1).
        String groupId = beneficiary != null && beneficiary.getGroup() != null ? beneficiary.getGroup().getId() : null;
        if (groupId != null && !beneficiaryGroupPolicyRepository.findByBeneficiaryGroup_IdAndActiveTrue(groupId).isEmpty()) {
            List<BeneficiaryGroupPolicy> rows = beneficiaryGroupPolicyRepository
                    .findByBeneficiaryGroup_IdAndTier_IdAndActiveTrue(groupId, tier.getId());
            if (rows.isEmpty()) {
                throw new ValidationException("Beneficiary Group " + groupId
                        + " has an active policy but none defined for tier " + tier.getId());
            }
            return new ResolvedPolicy(PolicyType.BENEFICIARY_GROUP, groupId, tier,
                    rows.stream().map(BeneficiaryGroupPolicy::getCombination).toList());
        }

        // 3. Account-level policy (final fallback).
        List<AccountPolicy> rows = accountPolicyRepository.findByDebitAccountIdAndTier_IdAndActiveTrue(debitAccountId, tier.getId());
        if (rows.isEmpty()) {
            throw new ValidationException("No Account-level policy defined for debit account " + debitAccountId
                    + " at tier " + tier.getId());
        }
        return new ResolvedPolicy(PolicyType.ACCOUNT, debitAccountId, tier,
                rows.stream().map(AccountPolicy::getCombination).toList());
    }

    /**
     * Preloaded lookups for resolving an entire File's worth of payment lines without one round
     * trip to the database per line. Built once per file upload by {@link #loadContext}, then
     * reused for every line via {@link #resolve(PolicyContext, String, String, BigDecimal,
     * String)} - the same hierarchy/priority logic as {@link #resolve(String, String,
     * BigDecimal, String)}, just evaluated in memory against the preloaded maps.
     */
    public record PolicyContext(
            Map<String, Beneficiary> beneficiariesById,
            Map<String, List<BeneficiaryPolicy>> beneficiaryPoliciesByBeneficiaryId,
            Map<String, List<BeneficiaryGroupPolicy>> groupPoliciesByGroupId,
            Map<String, List<AccountPolicy>> accountPoliciesByDebitAccountId,
            List<LimitTier> tiers
    ) {
    }

    /**
     * Bulk-loads everything {@link #resolve(PolicyContext, String, String, BigDecimal, String)}
     * needs for every line of a file: a handful of queries total instead of ~4 per payment line,
     * which is what makes Policy Resolution scale to a 100k-line file (NFR 3.1).
     */
    public PolicyContext loadContext(Collection<String> debitAccountIds, Collection<String> beneficiaryIds) {
        Map<String, Beneficiary> beneficiaries = beneficiaryIds.isEmpty() ? Map.of() :
                beneficiaryRepository.findAllById(beneficiaryIds).stream()
                        .collect(Collectors.toMap(Beneficiary::getId, b -> b));

        Set<String> groupIds = beneficiaries.values().stream()
                .map(b -> b.getGroup() != null ? b.getGroup().getId() : null)
                .filter(Objects::nonNull)
                .collect(Collectors.toSet());

        Map<String, List<BeneficiaryPolicy>> beneficiaryPolicies = beneficiaryIds.isEmpty() ? Map.of() :
                beneficiaryPolicyRepository.findByBeneficiary_IdInAndActiveTrue(beneficiaryIds).stream()
                        .collect(Collectors.groupingBy(p -> p.getBeneficiary().getId()));

        Map<String, List<BeneficiaryGroupPolicy>> groupPolicies = groupIds.isEmpty() ? Map.of() :
                beneficiaryGroupPolicyRepository.findByBeneficiaryGroup_IdInAndActiveTrue(groupIds).stream()
                        .collect(Collectors.groupingBy(p -> p.getBeneficiaryGroup().getId()));

        Map<String, List<AccountPolicy>> accountPolicies = debitAccountIds.isEmpty() ? Map.of() :
                accountPolicyRepository.findByDebitAccountIdInAndActiveTrue(debitAccountIds).stream()
                        .collect(Collectors.groupingBy(AccountPolicy::getDebitAccountId));

        return new PolicyContext(beneficiaries, beneficiaryPolicies, groupPolicies, accountPolicies,
                tierResolverService.loadOrderedTiers());
    }

    /** In-memory equivalent of {@link #resolve(String, String, BigDecimal, String)} against a preloaded {@link PolicyContext}. */
    public ResolvedPolicy resolve(PolicyContext ctx, String debitAccountId, String beneficiaryId, BigDecimal amount, String currency) {
        LimitTier tier = tierResolverService.resolveTier(ctx.tiers(), amount, currency);
        Beneficiary beneficiary = beneficiaryId == null ? null : ctx.beneficiariesById().get(beneficiaryId);

        // 1. Beneficiary-level policy (highest priority).
        List<BeneficiaryPolicy> allBenRows = beneficiary == null ? List.of() :
                ctx.beneficiaryPoliciesByBeneficiaryId().getOrDefault(beneficiaryId, List.of());
        if (!allBenRows.isEmpty()) {
            List<BeneficiaryPolicy> rows = allBenRows.stream()
                    .filter(r -> r.getTier().getId().equals(tier.getId())).toList();
            if (rows.isEmpty()) {
                throw new ValidationException("Beneficiary " + beneficiaryId
                        + " has an active Beneficiary-level policy but none defined for tier " + tier.getId());
            }
            return new ResolvedPolicy(PolicyType.BENEFICIARY, beneficiaryId, tier,
                    rows.stream().map(BeneficiaryPolicy::getCombination).toList());
        }

        // 2. Beneficiary Group-level policy (fallback #1).
        String groupId = beneficiary != null && beneficiary.getGroup() != null ? beneficiary.getGroup().getId() : null;
        List<BeneficiaryGroupPolicy> allGroupRows = groupId == null ? List.of() :
                ctx.groupPoliciesByGroupId().getOrDefault(groupId, List.of());
        if (!allGroupRows.isEmpty()) {
            List<BeneficiaryGroupPolicy> rows = allGroupRows.stream()
                    .filter(r -> r.getTier().getId().equals(tier.getId())).toList();
            if (rows.isEmpty()) {
                throw new ValidationException("Beneficiary Group " + groupId
                        + " has an active policy but none defined for tier " + tier.getId());
            }
            return new ResolvedPolicy(PolicyType.BENEFICIARY_GROUP, groupId, tier,
                    rows.stream().map(BeneficiaryGroupPolicy::getCombination).toList());
        }

        // 3. Account-level policy (final fallback).
        List<AccountPolicy> allAcctRows = ctx.accountPoliciesByDebitAccountId().getOrDefault(debitAccountId, List.of());
        List<AccountPolicy> rows = allAcctRows.stream()
                .filter(r -> r.getTier().getId().equals(tier.getId())).toList();
        if (rows.isEmpty()) {
            throw new ValidationException("No Account-level policy defined for debit account " + debitAccountId
                    + " at tier " + tier.getId());
        }
        return new ResolvedPolicy(PolicyType.ACCOUNT, debitAccountId, tier,
                rows.stream().map(AccountPolicy::getCombination).toList());
    }
}
