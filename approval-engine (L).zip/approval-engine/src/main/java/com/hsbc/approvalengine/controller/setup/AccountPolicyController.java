package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.AccountPolicy;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.AccountPolicyRequest;
import com.hsbc.approvalengine.service.setup.AccountPolicyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/account-policy - Feature 1.4: approval rules per Debit Account. */
@RestController
@RequestMapping("/setup/account-policy")
@RequiredArgsConstructor
public class AccountPolicyController {

    private final AccountPolicyService accountPolicyService;

    @GetMapping
    public List<AccountPolicy> findAll(@RequestParam(required = false) String debitAccountId) {
        return debitAccountId == null ? accountPolicyService.findAll() : accountPolicyService.findByAccount(debitAccountId);
    }

    @GetMapping("/{id}")
    public AccountPolicy find(@PathVariable String id) {
        return accountPolicyService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody AccountPolicyRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(accountPolicyService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody AccountPolicyRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(accountPolicyService.requestUpdate(id, request, makerId));
    }

    @DeleteMapping("/{id}")
    public ChangeRequestResponse delete(@PathVariable String id, @RequestParam String makerId) {
        return ChangeRequestResponse.from(accountPolicyService.requestDelete(id, makerId));
    }
}
