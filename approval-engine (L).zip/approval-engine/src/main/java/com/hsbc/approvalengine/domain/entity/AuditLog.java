package com.hsbc.approvalengine.domain.entity;

import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/** Immutable record of setup changes, approval actions and exceptions. Never updated, only inserted. */
@Entity
@Table(name = "audit_log")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditLog {

    @Id
    @Column(length = 50)
    private String id;

    @Enumerated(EnumType.STRING)
    @Column(name = "entity_type", length = 30, nullable = false)
    private SetupEntityType entityType;

    @Column(name = "entity_id", length = 50)
    private String entityId;

    @Enumerated(EnumType.STRING)
    @Column(length = 30, nullable = false)
    private AuditAction action;

    @Column(name = "performed_by", length = 50)
    private String performedBy;

    @Column(name = "performed_at")
    @Builder.Default
    private Instant performedAt = Instant.now();

    @Lob
    @Column(name = "details")
    private String details;
}
