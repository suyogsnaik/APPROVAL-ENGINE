package com.hsbc.approvalengine.domain.enums;

/** AND requires every category/signatory-group in the combination to sign; OR requires any one. */
public enum CombinationType {
    AND,
    OR
}
