package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.BeneficiaryGroup;
import com.hsbc.approvalengine.domain.entity.BeneficiaryGroupPolicy;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.BeneficiaryGroupPolicyRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.BeneficiaryGroupPolicyRepository;
import com.hsbc.approvalengine.repository.BeneficiaryGroupRepository;
import com.hsbc.approvalengine.repository.LimitTierRepository;
import com.hsbc.approvalengine.repository.TierCombinationRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Feature 1.5 (cont.) - Beneficiary Group-Level Approval Policy: fallback below Beneficiary, overrides Account. */
@Service
@RequiredArgsConstructor
public class BeneficiaryGroupPolicyService implements ChangeApplier {

    private final BeneficiaryGroupPolicyRepository beneficiaryGroupPolicyRepository;
    private final BeneficiaryGroupRepository beneficiaryGroupRepository;
    private final LimitTierRepository limitTierRepository;
    private final TierCombinationRepository tierCombinationRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<BeneficiaryGroupPolicy> findAll() {
        return beneficiaryGroupPolicyRepository.findAll();
    }

    public BeneficiaryGroupPolicy find(String id) {
        return beneficiaryGroupPolicyRepository.findById(id).orElseThrow(() -> new NotFoundException("Beneficiary group policy not found: " + id));
    }

    public ChangeRequest requestCreate(BeneficiaryGroupPolicyRequest request, String makerId) {
        validate(request);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY_GROUP_POLICY, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, BeneficiaryGroupPolicyRequest request, String makerId) {
        find(id);
        validate(request);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY_GROUP_POLICY, id, ChangeAction.UPDATE, request, makerId);
    }

    public ChangeRequest requestDelete(String id, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY_GROUP_POLICY, id, ChangeAction.DELETE, java.util.Map.of("id", id), makerId);
    }

    private void validate(BeneficiaryGroupPolicyRequest r) {
        if (!beneficiaryGroupRepository.existsById(r.beneficiaryGroupId())) {
            throw new ValidationException("Unknown beneficiaryGroupId: " + r.beneficiaryGroupId());
        }
        if (!limitTierRepository.existsById(r.tierId())) {
            throw new ValidationException("Unknown tierId: " + r.tierId());
        }
        if (!tierCombinationRepository.existsById(r.combinationId())) {
            throw new ValidationException("Unknown combinationId: " + r.combinationId());
        }
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.BENEFICIARY_GROUP_POLICY;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        BeneficiaryGroupPolicyRequest r = objectMapper.convertValue(payload, BeneficiaryGroupPolicyRequest.class);
        BeneficiaryGroup g = beneficiaryGroupRepository.getReferenceById(r.beneficiaryGroupId());
        LimitTier tier = limitTierRepository.getReferenceById(r.tierId());
        TierCombination combo = tierCombinationRepository.getReferenceById(r.combinationId());
        beneficiaryGroupPolicyRepository.save(BeneficiaryGroupPolicy.builder()
                .id(r.id()).beneficiaryGroup(g).tier(tier).combination(combo).active(r.active()).build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        BeneficiaryGroupPolicyRequest r = objectMapper.convertValue(payload, BeneficiaryGroupPolicyRequest.class);
        BeneficiaryGroupPolicy p = find(entityId);
        p.setBeneficiaryGroup(beneficiaryGroupRepository.getReferenceById(r.beneficiaryGroupId()));
        p.setTier(limitTierRepository.getReferenceById(r.tierId()));
        p.setCombination(tierCombinationRepository.getReferenceById(r.combinationId()));
        p.setActive(r.active());
        beneficiaryGroupPolicyRepository.save(p);
    }

    @Override
    public void applyDelete(String entityId) {
        beneficiaryGroupPolicyRepository.deleteById(entityId);
    }
}
