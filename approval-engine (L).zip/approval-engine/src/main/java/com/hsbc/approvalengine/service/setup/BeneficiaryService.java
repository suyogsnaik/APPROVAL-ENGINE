package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.Beneficiary;
import com.hsbc.approvalengine.domain.entity.BeneficiaryGroup;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.BeneficiaryRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.repository.BeneficiaryGroupRepository;
import com.hsbc.approvalengine.repository.BeneficiaryRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;

/**
 * Beneficiary maintenance (PRD 3.6): must follow Maker-Checker. {@code createdBy} always reflects
 * whoever most recently created/edited the beneficiary and is what the Self-Approval Validator
 * checks - editing a beneficiary re-triggers the restriction for the editor, per PRD 3.7.
 */
@Service
@RequiredArgsConstructor
public class BeneficiaryService implements ChangeApplier {

    private final BeneficiaryRepository beneficiaryRepository;
    private final BeneficiaryGroupRepository beneficiaryGroupRepository;
    private final AppUserRepository appUserRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<Beneficiary> findAll() {
        return beneficiaryRepository.findAll();
    }

    public Beneficiary find(String id) {
        return beneficiaryRepository.findById(id).orElseThrow(() -> new NotFoundException("Beneficiary not found: " + id));
    }

    public ChangeRequest requestCreate(BeneficiaryRequest request, String makerId) {
        if (beneficiaryRepository.existsById(request.id())) {
            throw new ValidationException("Beneficiary already exists: " + request.id());
        }
        validate(request);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, BeneficiaryRequest request, String makerId) {
        find(id);
        validate(request);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY, id, ChangeAction.UPDATE, request, makerId);
    }

    private void validate(BeneficiaryRequest r) {
        if (r.groupId() != null && !beneficiaryGroupRepository.existsById(r.groupId())) {
            throw new ValidationException("Unknown beneficiary groupId: " + r.groupId());
        }
        if (!appUserRepository.existsById(r.createdBy())) {
            throw new ValidationException("Unknown createdBy userId: " + r.createdBy());
        }
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.BENEFICIARY;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        BeneficiaryRequest r = objectMapper.convertValue(payload, BeneficiaryRequest.class);
        BeneficiaryGroup group = r.groupId() == null ? null : beneficiaryGroupRepository.getReferenceById(r.groupId());
        AppUser creator = appUserRepository.getReferenceById(r.createdBy());
        beneficiaryRepository.save(Beneficiary.builder()
                .id(r.id()).name(r.name()).group(group).createdBy(creator).createdAt(Instant.now()).build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        BeneficiaryRequest r = objectMapper.convertValue(payload, BeneficiaryRequest.class);
        Beneficiary b = find(entityId);
        b.setName(r.name());
        b.setGroup(r.groupId() == null ? null : beneficiaryGroupRepository.getReferenceById(r.groupId()));
        b.setCreatedBy(appUserRepository.getReferenceById(r.createdBy()));
        b.setCreatedAt(Instant.now());
        beneficiaryRepository.save(b);
    }

    @Override
    public void applyDelete(String entityId) {
        beneficiaryRepository.deleteById(entityId);
    }
}
