package com.hsbc.approvalengine.service.fileprocessing;

import com.hsbc.approvalengine.dto.file.ParsedPaymentLine;

import java.util.List;

/** US23/US24 - File Upload: parses a raw payment instruction file into payment lines. */
public interface PaymentFileParser {

    /** File extensions / format tokens this parser handles, e.g. "csv" or "xml". */
    boolean supports(String format);

    List<ParsedPaymentLine> parse(String content);
}
