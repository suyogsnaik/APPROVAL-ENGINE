package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;

import java.util.Set;

/** Replaces the full set of Signatory Groups a user belongs to (a user may belong to multiple). */
public record UserSignatoryGroupAssignRequest(
        @NotBlank String userId,
        @NotEmpty Set<String> signatoryGroupIds
) {
}
