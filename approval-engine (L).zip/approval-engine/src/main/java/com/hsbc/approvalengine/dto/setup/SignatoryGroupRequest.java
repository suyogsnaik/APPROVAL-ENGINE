package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

public record SignatoryGroupRequest(
        @NotBlank String id,
        @NotBlank String name,
        Integer sequenceOrder,
        boolean sequential
) {
}
