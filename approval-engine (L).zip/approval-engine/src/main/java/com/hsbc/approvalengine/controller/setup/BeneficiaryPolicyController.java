package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.BeneficiaryPolicy;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.BeneficiaryPolicyRequest;
import com.hsbc.approvalengine.service.setup.BeneficiaryPolicyService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/beneficiary-policy - Feature 1.5: approval rules per Beneficiary (highest priority). */
@RestController
@RequestMapping("/setup/beneficiary-policy")
@RequiredArgsConstructor
public class BeneficiaryPolicyController {

    private final BeneficiaryPolicyService beneficiaryPolicyService;

    @GetMapping
    public List<BeneficiaryPolicy> findAll() {
        return beneficiaryPolicyService.findAll();
    }

    @GetMapping("/{id}")
    public BeneficiaryPolicy find(@PathVariable String id) {
        return beneficiaryPolicyService.find(id);
    }

    @PostMapping
    public ChangeRequestResponse create(@Valid @RequestBody BeneficiaryPolicyRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryPolicyService.requestCreate(request, makerId));
    }

    @PutMapping("/{id}")
    public ChangeRequestResponse update(@PathVariable String id, @Valid @RequestBody BeneficiaryPolicyRequest request,
                                         @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryPolicyService.requestUpdate(id, request, makerId));
    }

    @DeleteMapping("/{id}")
    public ChangeRequestResponse delete(@PathVariable String id, @RequestParam String makerId) {
        return ChangeRequestResponse.from(beneficiaryPolicyService.requestDelete(id, makerId));
    }
}
