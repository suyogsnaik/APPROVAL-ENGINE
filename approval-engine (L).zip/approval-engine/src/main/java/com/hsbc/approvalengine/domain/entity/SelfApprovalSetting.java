package com.hsbc.approvalengine.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Per-client switch: when true, a beneficiary's creator cannot approve payments to it. */
@Entity
@Table(name = "self_approval_settings")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SelfApprovalSetting {

    @Id
    @Column(name = "client_id", length = 50)
    private String clientId;

    @Column(name = "restrict_self_approval")
    @Builder.Default
    private boolean restrictSelfApproval = true;
}
