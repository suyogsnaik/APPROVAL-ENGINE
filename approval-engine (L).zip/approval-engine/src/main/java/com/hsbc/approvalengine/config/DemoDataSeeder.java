package com.hsbc.approvalengine.config;

import com.hsbc.approvalengine.domain.entity.*;
import com.hsbc.approvalengine.domain.enums.CombinationType;
import com.hsbc.approvalengine.domain.enums.EntitlementType;
import com.hsbc.approvalengine.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Set;

/**
 * Seeds a small, coherent demo/UAT dataset so the API is usable immediately after start-up and
 * so the test suite (TC1-TC16) has realistic fixtures to exercise. Seeding is idempotent (skips
 * if Categories already exist) and can be disabled via {@code approval-engine.seed-demo-data}.
 *
 * <p>Demo client: {@code CLIENT1}. Demo debit account: {@code ACC1}.</p>
 */
@Component
@RequiredArgsConstructor
@Slf4j
public class DemoDataSeeder implements CommandLineRunner {

    private final CategoryRepository categoryRepository;
    private final SignatoryGroupRepository signatoryGroupRepository;
    private final AppUserRepository appUserRepository;
    private final LimitTierRepository limitTierRepository;
    private final TierCombinationRepository tierCombinationRepository;
    private final AccountPolicyRepository accountPolicyRepository;
    private final BeneficiaryGroupRepository beneficiaryGroupRepository;
    private final BeneficiaryRepository beneficiaryRepository;
    private final BeneficiaryPolicyRepository beneficiaryPolicyRepository;
    private final BeneficiaryGroupPolicyRepository beneficiaryGroupPolicyRepository;
    private final AccountEntitlementRepository accountEntitlementRepository;
    private final SelfApprovalSettingRepository selfApprovalSettingRepository;

    @Value("${approval-engine.seed-demo-data:true}")
    private boolean seedEnabled;

    @Override
    @Transactional
    public void run(String... args) {
        if (!seedEnabled || categoryRepository.count() > 0) {
            return;
        }
        log.info("Seeding demo data for client CLIENT1 / debit account ACC1 ...");

        Category catA = categoryRepository.save(Category.builder().id("A").name("Chief Financial Officer").description("Cat A - most senior").build());
        Category catB = categoryRepository.save(Category.builder().id("B").name("Finance Manager").description("Cat B").build());
        Category catC = categoryRepository.save(Category.builder().id("C").name("Supervisor").description("Cat C").build());

        SignatoryGroup g1 = signatoryGroupRepository.save(SignatoryGroup.builder().id("G1").name("Stage 1 Signatories").sequenceOrder(1).sequential(true).build());
        SignatoryGroup g2 = signatoryGroupRepository.save(SignatoryGroup.builder().id("G2").name("Stage 2 Signatories").sequenceOrder(2).sequential(true).build());

        AppUser userCfo = appUserRepository.save(AppUser.builder().id("USR-CFO").loginId("cfo").displayName("Chidi Okafor (CFO)").category(catA).active(true).build());
        AppUser userMgr = appUserRepository.save(AppUser.builder().id("USR-MGR").loginId("mgr").displayName("Maria Garcia (Finance Mgr)").category(catB).active(true).build());
        AppUser userSup = appUserRepository.save(AppUser.builder().id("USR-SUP").loginId("sup").displayName("Sam Patel (Supervisor)").category(catC).active(true).build());
        AppUser userG1 = appUserRepository.save(AppUser.builder().id("USR-G1").loginId("g1approver").displayName("Grace Lee (Stage 1)").active(true)
                .signatoryGroups(Set.of(g1)).build());
        AppUser userG2 = appUserRepository.save(AppUser.builder().id("USR-G2").loginId("g2approver").displayName("Gus Osei (Stage 2)").active(true)
                .signatoryGroups(Set.of(g2)).build());
        AppUser userNoEnt = appUserRepository.save(AppUser.builder().id("USR-NOENT").loginId("noent").displayName("Nina Ortiz (no account entitlement)").category(catB).active(true).build());

        LimitTier tier1 = limitTierRepository.save(LimitTier.builder().id("Tier1").minAmount(BigDecimal.ZERO).maxAmount(BigDecimal.valueOf(5000)).currency("USD").rankOrder(1).build());
        LimitTier tier2 = limitTierRepository.save(LimitTier.builder().id("Tier2").minAmount(BigDecimal.valueOf(5000)).maxAmount(BigDecimal.valueOf(20000)).currency("USD").rankOrder(2).build());
        LimitTier tier3 = limitTierRepository.save(LimitTier.builder().id("Tier3").minAmount(BigDecimal.valueOf(20000)).maxAmount(BigDecimal.valueOf(1000000)).currency("USD").rankOrder(3).build());

        TierCombination comboT1Or = tierCombinationRepository.save(TierCombination.builder().id("COMBO-T1-OR").tier(tier1)
                .combinationType(CombinationType.OR).categoryIds(Set.of("A", "B")).build());
        TierCombination comboT2Or = tierCombinationRepository.save(TierCombination.builder().id("COMBO-T2-OR").tier(tier2)
                .combinationType(CombinationType.OR).categoryIds(Set.of("B")).build());
        TierCombination comboT3And = tierCombinationRepository.save(TierCombination.builder().id("COMBO-T3-AND").tier(tier3)
                .combinationType(CombinationType.AND).categoryIds(Set.of("A", "B")).build());
        TierCombination comboSeq = tierCombinationRepository.save(TierCombination.builder().id("COMBO-T2-SEQ").tier(tier2)
                .combinationType(CombinationType.AND).sequenceRequired(true).signatoryGroupIds(Set.of("G1", "G2")).build());
        TierCombination comboGrpC = tierCombinationRepository.save(TierCombination.builder().id("COMBO-GRP-C").tier(tier2)
                .combinationType(CombinationType.OR).categoryIds(Set.of("C")).build());

        // Account-level policy (fallback) for ACC1: Tier1 -> A OR B; Tier2 -> B; Tier3 -> A AND B.
        accountPolicyRepository.save(AccountPolicy.builder().id("AP-ACC1-T1").debitAccountId("ACC1").tier(tier1).combination(comboT1Or).active(true).build());
        accountPolicyRepository.save(AccountPolicy.builder().id("AP-ACC1-T2").debitAccountId("ACC1").tier(tier2).combination(comboT2Or).active(true).build());
        accountPolicyRepository.save(AccountPolicy.builder().id("AP-ACC1-T3").debitAccountId("ACC1").tier(tier3).combination(comboT3And).active(true).build());

        BeneficiaryGroup supplierGroup = beneficiaryGroupRepository.save(BeneficiaryGroup.builder().id("GRP01").name("Supplier Group").build());
        beneficiaryGroupPolicyRepository.save(BeneficiaryGroupPolicy.builder().id("BGP-GRP01-T2").beneficiaryGroup(supplierGroup).tier(tier2).combination(comboGrpC).active(true).build());

        Beneficiary ben001 = beneficiaryRepository.save(Beneficiary.builder().id("BEN001").name("Acme Supplies Ltd").group(supplierGroup).createdBy(userMgr).build());
        Beneficiary benPlain = beneficiaryRepository.save(Beneficiary.builder().id("BEN-PLAIN").name("Globex Trading Co").createdBy(userCfo).build());
        Beneficiary benSeq = beneficiaryRepository.save(Beneficiary.builder().id("BEN-SEQ").name("Northwind Logistics").createdBy(userCfo).build());
        beneficiaryPolicyRepository.save(BeneficiaryPolicy.builder().id("BP-BENSEQ-T2").beneficiary(benSeq).tier(tier2).combination(comboSeq).active(true).build());

        for (String userId : new String[]{"USR-CFO", "USR-MGR", "USR-SUP", "USR-G1", "USR-G2"}) {
            accountEntitlementRepository.save(AccountEntitlement.builder()
                    .id(new AccountEntitlementId(userId, "ACC1")).entitlementType(EntitlementType.ALL).build());
        }
        // USR-NOENT is deliberately left without an ACC1 entitlement (ACCOUNT_NOT_ENTITLED fixture).

        selfApprovalSettingRepository.save(SelfApprovalSetting.builder().clientId("CLIENT1").restrictSelfApproval(true).build());

        log.info("Demo data seeded: categories A-C, tiers Tier1-3, signatory groups G1-G2, "
                + "beneficiaries BEN001 (Supplier Group)/BEN-PLAIN (account fallback)/BEN-SEQ (sequential), "
                + "users USR-CFO/USR-MGR/USR-SUP/USR-G1/USR-G2/USR-NOENT, debit account ACC1, client CLIENT1.");
    }
}
