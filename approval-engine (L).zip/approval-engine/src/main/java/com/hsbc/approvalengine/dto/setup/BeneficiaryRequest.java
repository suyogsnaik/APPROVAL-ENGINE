package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

/** {@code createdBy} drives the Self-Approval restriction (PRD 3.7 / MRS 2.2.9). */
public record BeneficiaryRequest(
        @NotBlank String id,
        @NotBlank String name,
        String groupId,
        @NotBlank String createdBy
) {
}
