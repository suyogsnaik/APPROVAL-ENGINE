package com.hsbc.approvalengine.controller.setup;

import com.hsbc.approvalengine.domain.entity.AccountEntitlement;
import com.hsbc.approvalengine.dto.common.ChangeRequestResponse;
import com.hsbc.approvalengine.dto.setup.AccountEntitlementRequest;
import com.hsbc.approvalengine.service.setup.AccountEntitlementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** POST /setup/entitlement - Feature 2.2: assign users to Debit Accounts (ONE/MULTIPLE/ALL). */
@RestController
@RequestMapping("/setup/entitlement")
@RequiredArgsConstructor
public class EntitlementController {

    private final AccountEntitlementService accountEntitlementService;

    @GetMapping("/user/{userId}")
    public List<AccountEntitlement> findByUser(@PathVariable String userId) {
        return accountEntitlementService.findByUser(userId);
    }

    @PostMapping
    public ChangeRequestResponse upsert(@Valid @RequestBody AccountEntitlementRequest request, @RequestParam String makerId) {
        return ChangeRequestResponse.from(accountEntitlementService.requestUpsert(request, makerId));
    }
}
