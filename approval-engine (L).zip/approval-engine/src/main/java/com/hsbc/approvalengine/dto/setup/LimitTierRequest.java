package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record LimitTierRequest(
        @NotBlank String id,
        @NotNull BigDecimal minAmount,
        BigDecimal maxAmount,
        @NotBlank String currency,
        Integer rankOrder
) {
}
