package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.enums.PolicyType;

/**
 * Task "surface the resolved approval policy once a file is visible": one row per distinct
 * (policy level, policy id, tier) combination the engine actually applied within a File, with how
 * many payment lines landed on it. Produced by a single {@code GROUP BY} query in the database -
 * bounded by the number of distinct policies in play (typically a handful), never by the file's
 * payment-line count, so this stays cheap even for a 100k-line file.
 */
public interface AppliedPolicySummaryProjection {
    PolicyType getPolicyType();
    String getPolicyId();
    String getTierId();
    long getPaymentCount();
}
