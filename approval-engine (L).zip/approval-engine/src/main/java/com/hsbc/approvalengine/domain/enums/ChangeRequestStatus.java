package com.hsbc.approvalengine.domain.enums;

public enum ChangeRequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
