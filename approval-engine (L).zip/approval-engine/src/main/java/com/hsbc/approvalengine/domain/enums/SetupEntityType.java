package com.hsbc.approvalengine.domain.enums;

/** The kind of setup entity a Maker-Checker ChangeRequest or AuditLog entry refers to. */
public enum SetupEntityType {
    CATEGORY,
    LIMIT_TIER,
    TIER_COMBINATION,
    ACCOUNT_POLICY,
    BENEFICIARY_POLICY,
    BENEFICIARY_GROUP_POLICY,
    SIGNATORY_GROUP,
    USER_SIGNATORY_GROUP,
    ACCOUNT_ENTITLEMENT,
    SELF_APPROVAL_SETTING,
    BENEFICIARY,
    BENEFICIARY_GROUP,
    USER,
    PAYMENT,
    BATCH,
    FILE
}
