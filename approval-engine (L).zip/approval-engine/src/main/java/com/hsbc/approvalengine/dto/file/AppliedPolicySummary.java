package com.hsbc.approvalengine.dto.file;

import com.hsbc.approvalengine.domain.enums.PolicyType;

/**
 * One row of "what approval policy did the engine actually apply within this file" - surfaced on
 * {@link FileStatusResponse} once the caller is allowed to see the File at all (see
 * FileAccessService). {@code paymentCount} is how many payment lines landed on this exact
 * (policyType, policyId, tierId) combination.
 */
public record AppliedPolicySummary(
        PolicyType policyType,
        String policyId,
        String tierId,
        long paymentCount
) {
}
