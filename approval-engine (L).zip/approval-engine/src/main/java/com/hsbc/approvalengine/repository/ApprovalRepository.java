package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.Approval;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ApprovalRepository extends JpaRepository<Approval, String> {
    List<Approval> findByPayment_Id(String paymentId);
    List<Approval> findByPayment_IdAndUser_Id(String paymentId, String userId);
}
