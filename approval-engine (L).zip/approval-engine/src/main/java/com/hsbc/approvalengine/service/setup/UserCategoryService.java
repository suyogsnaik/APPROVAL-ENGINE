package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.Category;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.UserCategoryAssignRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.repository.CategoryRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/** Feature 1.1 (cont.) - US2: Assign a Category to a User, Maker-Checker governed. */
@Service
@RequiredArgsConstructor
public class UserCategoryService implements ChangeApplier {

    private final AppUserRepository appUserRepository;
    private final CategoryRepository categoryRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public ChangeRequest requestAssign(UserCategoryAssignRequest request, String makerId) {
        if (!appUserRepository.existsById(request.userId())) {
            throw new ValidationException("Unknown userId: " + request.userId());
        }
        if (!categoryRepository.existsById(request.categoryId())) {
            throw new ValidationException("Unknown categoryId: " + request.categoryId());
        }
        return changeRequestService.submit(SetupEntityType.USER, request.userId(), ChangeAction.UPDATE, request, makerId);
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.USER;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        applyUpdate(entityId, payload);
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        UserCategoryAssignRequest r = objectMapper.convertValue(payload, UserCategoryAssignRequest.class);
        AppUser user = appUserRepository.findById(r.userId())
                .orElseThrow(() -> new NotFoundException("User not found: " + r.userId()));
        Category category = categoryRepository.findById(r.categoryId())
                .orElseThrow(() -> new NotFoundException("Category not found: " + r.categoryId()));
        user.setCategory(category);
        appUserRepository.save(user);
    }

    @Override
    public void applyDelete(String entityId) {
        AppUser user = appUserRepository.findById(entityId)
                .orElseThrow(() -> new NotFoundException("User not found: " + entityId));
        user.setCategory(null);
        appUserRepository.save(user);
    }
}
