package com.hsbc.approvalengine.service.setup;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.hsbc.approvalengine.domain.entity.Beneficiary;
import com.hsbc.approvalengine.domain.entity.BeneficiaryPolicy;
import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.entity.LimitTier;
import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.setup.BeneficiaryPolicyRequest;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.exception.ValidationException;
import com.hsbc.approvalengine.repository.BeneficiaryPolicyRepository;
import com.hsbc.approvalengine.repository.BeneficiaryRepository;
import com.hsbc.approvalengine.repository.LimitTierRepository;
import com.hsbc.approvalengine.repository.TierCombinationRepository;
import com.hsbc.approvalengine.service.makerchecker.ChangeApplier;
import com.hsbc.approvalengine.service.makerchecker.ChangeRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/** Feature 1.5 - Beneficiary-Level Approval Policy: highest priority, overrides Account policy. */
@Service
@RequiredArgsConstructor
public class BeneficiaryPolicyService implements ChangeApplier {

    private final BeneficiaryPolicyRepository beneficiaryPolicyRepository;
    private final BeneficiaryRepository beneficiaryRepository;
    private final LimitTierRepository limitTierRepository;
    private final TierCombinationRepository tierCombinationRepository;
    private final ChangeRequestService changeRequestService;
    private final ObjectMapper objectMapper;

    public List<BeneficiaryPolicy> findAll() {
        return beneficiaryPolicyRepository.findAll();
    }

    public BeneficiaryPolicy find(String id) {
        return beneficiaryPolicyRepository.findById(id).orElseThrow(() -> new NotFoundException("Beneficiary policy not found: " + id));
    }

    public ChangeRequest requestCreate(BeneficiaryPolicyRequest request, String makerId) {
        validate(request);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY_POLICY, request.id(), ChangeAction.CREATE, request, makerId);
    }

    public ChangeRequest requestUpdate(String id, BeneficiaryPolicyRequest request, String makerId) {
        find(id);
        validate(request);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY_POLICY, id, ChangeAction.UPDATE, request, makerId);
    }

    public ChangeRequest requestDelete(String id, String makerId) {
        find(id);
        return changeRequestService.submit(SetupEntityType.BENEFICIARY_POLICY, id, ChangeAction.DELETE, java.util.Map.of("id", id), makerId);
    }

    private void validate(BeneficiaryPolicyRequest r) {
        if (!beneficiaryRepository.existsById(r.beneficiaryId())) {
            throw new ValidationException("Unknown beneficiaryId: " + r.beneficiaryId());
        }
        if (!limitTierRepository.existsById(r.tierId())) {
            throw new ValidationException("Unknown tierId: " + r.tierId());
        }
        if (!tierCombinationRepository.existsById(r.combinationId())) {
            throw new ValidationException("Unknown combinationId: " + r.combinationId());
        }
    }

    @Override
    public SetupEntityType supports() {
        return SetupEntityType.BENEFICIARY_POLICY;
    }

    @Override
    public void applyCreate(String entityId, JsonNode payload) {
        BeneficiaryPolicyRequest r = objectMapper.convertValue(payload, BeneficiaryPolicyRequest.class);
        Beneficiary b = beneficiaryRepository.getReferenceById(r.beneficiaryId());
        LimitTier tier = limitTierRepository.getReferenceById(r.tierId());
        TierCombination combo = tierCombinationRepository.getReferenceById(r.combinationId());
        beneficiaryPolicyRepository.save(BeneficiaryPolicy.builder()
                .id(r.id()).beneficiary(b).tier(tier).combination(combo).active(r.active()).build());
    }

    @Override
    public void applyUpdate(String entityId, JsonNode payload) {
        BeneficiaryPolicyRequest r = objectMapper.convertValue(payload, BeneficiaryPolicyRequest.class);
        BeneficiaryPolicy p = find(entityId);
        p.setBeneficiary(beneficiaryRepository.getReferenceById(r.beneficiaryId()));
        p.setTier(limitTierRepository.getReferenceById(r.tierId()));
        p.setCombination(tierCombinationRepository.getReferenceById(r.combinationId()));
        p.setActive(r.active());
        beneficiaryPolicyRepository.save(p);
    }

    @Override
    public void applyDelete(String entityId) {
        beneficiaryPolicyRepository.deleteById(entityId);
    }
}
