package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.AccountEntitlement;
import com.hsbc.approvalengine.domain.entity.AccountEntitlementId;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AccountEntitlementRepository extends JpaRepository<AccountEntitlement, AccountEntitlementId> {
    List<AccountEntitlement> findById_UserId(String userId);
}
