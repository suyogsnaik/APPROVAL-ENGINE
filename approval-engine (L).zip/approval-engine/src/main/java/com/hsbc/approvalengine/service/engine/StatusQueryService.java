package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.domain.enums.BatchStatus;
import com.hsbc.approvalengine.domain.enums.FileStatus;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.dto.file.AppliedPolicySummary;
import com.hsbc.approvalengine.dto.file.FileStatusResponse;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.repository.AppliedPolicySummaryProjection;
import com.hsbc.approvalengine.repository.BatchRepository;
import com.hsbc.approvalengine.repository.PaymentFileRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * GET /file/{fileId}/status (API spec 3.4). Built entirely on COUNT/GROUP BY queries rather than
 * loading every Batch/Payment row - a 100k-line file must answer this in the same handful of
 * queries as a 10-line one (NFR 3.1).
 */
@Service
@RequiredArgsConstructor
public class StatusQueryService {

    private final PaymentFileRepository paymentFileRepository;
    private final BatchRepository batchRepository;
    private final PaymentRepository paymentRepository;
    private final FileAccessService fileAccessService;

    /** {@code userId} is required: a user with no entitlement to any account in the file gets a 404, not a status. */
    public FileStatusResponse fileStatus(String userId, String fileId) {
        fileAccessService.assertVisible(userId, fileId);
        PaymentFile file = paymentFileRepository.findById(fileId)
                .orElseThrow(() -> new NotFoundException("File not found: " + fileId));

        long batchesTotal = batchRepository.countByFile_Id(fileId);
        long batchesApproved = batchRepository.countByFile_IdAndStatus(fileId, BatchStatus.APPROVED);
        long paymentsTotal = paymentRepository.countByBatch_File_Id(fileId);
        long paymentsApproved = paymentRepository.countByBatch_File_IdAndStatus(fileId, PaymentStatus.APPROVED);
        long paymentsException = paymentRepository.countByBatch_File_IdAndStatus(fileId, PaymentStatus.EXCEPTION);

        var appliedPolicies = paymentRepository.summarizeAppliedPolicies(fileId).stream()
                .map(this::toSummary)
                .toList();

        return new FileStatusResponse(
                file.getId(), file.getStatus(),
                (int) batchesApproved, (int) batchesTotal,
                paymentsApproved, paymentsTotal,
                paymentsException,
                file.getStatus() == FileStatus.APPROVED || file.getStatus() == FileStatus.RELEASED,
                appliedPolicies
        );
    }

    private AppliedPolicySummary toSummary(AppliedPolicySummaryProjection p) {
        return new AppliedPolicySummary(p.getPolicyType(), p.getPolicyId(), p.getTierId(), p.getPaymentCount());
    }
}
