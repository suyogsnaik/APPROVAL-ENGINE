package com.hsbc.approvalengine.dto.common;

import jakarta.validation.constraints.NotBlank;

/** Body for POST /setup/change-requests/{id}/approve or /reject. */
public record ChangeRequestActionRequest(
        @NotBlank String checkerId,
        String comment
) {
}
