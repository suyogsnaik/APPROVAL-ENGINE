package com.hsbc.approvalengine.domain.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** Signatory Group (A-J, up to 10) used to build the entitlement / sequencing model. */
@Entity
@Table(name = "signatory_groups")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SignatoryGroup {

    @Id
    @Column(length = 20)
    private String id; // e.g. "G1".."G10"

    @Column(length = 100)
    private String name;

    /** Stage order (1..8) used when the owning combination is Sequential. */
    @Column(name = "sequence_order")
    private Integer sequenceOrder;

    @Column(name = "is_sequential")
    @Builder.Default
    private boolean sequential = false;
}
