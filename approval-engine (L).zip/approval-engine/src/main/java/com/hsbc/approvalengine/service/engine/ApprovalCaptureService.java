package com.hsbc.approvalengine.service.engine;

import com.hsbc.approvalengine.domain.entity.AppUser;
import com.hsbc.approvalengine.domain.entity.Approval;
import com.hsbc.approvalengine.domain.entity.Batch;
import com.hsbc.approvalengine.domain.entity.Payment;
import com.hsbc.approvalengine.domain.entity.PaymentFile;
import com.hsbc.approvalengine.domain.entity.TierCombination;
import com.hsbc.approvalengine.domain.enums.AuditAction;
import com.hsbc.approvalengine.domain.enums.BatchStatus;
import com.hsbc.approvalengine.domain.enums.CombinationType;
import com.hsbc.approvalengine.domain.enums.FileStatus;
import com.hsbc.approvalengine.domain.enums.PaymentStatus;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;
import com.hsbc.approvalengine.dto.engine.EligibilityResult;
import com.hsbc.approvalengine.exception.EligibilityViolationException;
import com.hsbc.approvalengine.exception.NotFoundException;
import com.hsbc.approvalengine.repository.AppUserRepository;
import com.hsbc.approvalengine.repository.ApprovalRepository;
import com.hsbc.approvalengine.repository.BatchRepository;
import com.hsbc.approvalengine.repository.PaymentFileRepository;
import com.hsbc.approvalengine.repository.PaymentRepository;
import com.hsbc.approvalengine.repository.TierCombinationRepository;
import com.hsbc.approvalengine.service.audit.AuditService;
import com.hsbc.approvalengine.service.backoffice.BackOfficeService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Feature 4.6 - Approval Capture (MRS 2.3.6). Records one approval action, then cascades
 * completion status Payment -&gt; Batch -&gt; File exactly as the state machine in the architecture
 * pack describes, releasing to Back Office the moment a File becomes fully approved.
 */
@Service
@RequiredArgsConstructor
public class ApprovalCaptureService {

    private final AppUserRepository appUserRepository;
    private final PaymentRepository paymentRepository;
    private final ApprovalRepository approvalRepository;
    private final BatchRepository batchRepository;
    private final PaymentFileRepository paymentFileRepository;
    private final TierCombinationRepository tierCombinationRepository;
    private final EntitlementValidatorService entitlementValidatorService;
    private final AuditService auditService;
    private final BackOfficeService backOfficeService;

    public EligibilityResult validate(String userId, String paymentId) {
        AppUser user = appUserRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found: " + userId));
        Payment payment = paymentRepository.findById(paymentId).orElseThrow(() -> new NotFoundException("Payment not found: " + paymentId));
        return entitlementValidatorService.validate(user, payment);
    }

    @Transactional
    public Approval capture(String userId, String paymentId, String performedBy) {
        AppUser user = appUserRepository.findById(userId).orElseThrow(() -> new NotFoundException("User not found: " + userId));
        Payment payment = paymentRepository.findById(paymentId).orElseThrow(() -> new NotFoundException("Payment not found: " + paymentId));

        EligibilityResult result = entitlementValidatorService.validate(user, payment);
        if (!result.eligible()) {
            auditService.log(SetupEntityType.PAYMENT, paymentId, AuditAction.EXCEPTION, performedBy,
                    "Approval rejected for user " + userId + ": " + result.violations());
            throw new EligibilityViolationException(result.violations());
        }

        Approval approval = Approval.builder()
                .id("APR-" + UUID.randomUUID())
                .payment(payment)
                .user(user)
                .categoryId(result.matchedCategoryId())
                .signatoryGroupId(result.matchedSignatoryGroupId())
                .stage(result.matchedStage())
                .build();
        approvalRepository.save(approval);
        auditService.log(SetupEntityType.PAYMENT, paymentId, AuditAction.CAPTURE_APPROVAL, performedBy,
                "Approved by " + userId + " (category=" + result.matchedCategoryId()
                        + ", signGroup=" + result.matchedSignatoryGroupId() + ", combo=" + result.matchedCombination().getId() + ")");

        updatePaymentStatus(payment);
        cascadeBatchAndFile(payment.getBatch(), performedBy);

        return approval;
    }

    private void updatePaymentStatus(Payment payment) {
        List<Approval> approvals = approvalRepository.findByPayment_Id(payment.getId());
        List<TierCombination> combos = tierCombinationRepository.findAllById(payment.getAppliedCombinationIds());
        boolean anySatisfied = combos.stream().anyMatch(c -> isSatisfied(c, approvals));
        payment.setStatus(anySatisfied ? PaymentStatus.APPROVED : PaymentStatus.PARTIALLY_APPROVED);
        paymentRepository.save(payment);
    }

    /** Feature 4.6 / MRS 2.3.6: AND requires every listed role signed; OR requires any one. */
    private boolean isSatisfied(TierCombination combo, List<Approval> approvals) {
        Set<String> signedCategories = approvals.stream().map(Approval::getCategoryId).filter(java.util.Objects::nonNull)
                .collect(java.util.stream.Collectors.toSet());
        Set<String> signedGroups = approvals.stream().map(Approval::getSignatoryGroupId).filter(java.util.Objects::nonNull)
                .collect(java.util.stream.Collectors.toSet());

        if (combo.getCombinationType() == CombinationType.AND) {
            boolean allCategoriesSigned = combo.getCategoryIds().stream().allMatch(signedCategories::contains);
            boolean allGroupsSigned = combo.getSignatoryGroupIds().stream().allMatch(signedGroups::contains);
            return allCategoriesSigned && allGroupsSigned
                    && !(combo.getCategoryIds().isEmpty() && combo.getSignatoryGroupIds().isEmpty());
        }
        // OR: any one required category or signatory group having signed is enough.
        boolean anyCategorySigned = combo.getCategoryIds().stream().anyMatch(signedCategories::contains);
        boolean anyGroupSigned = combo.getSignatoryGroupIds().stream().anyMatch(signedGroups::contains);
        return anyCategorySigned || anyGroupSigned;
    }

    /**
     * Payment -&gt; Batch -&gt; File cascading completion, per the architecture pack state machine.
     * Uses COUNT queries rather than loading every Payment/Batch row so this stays cheap even
     * when a Batch or File holds tens of thousands of lines (NFR 3.1): "all approved" is answered
     * as "total &gt; 0 and nothing left that isn't approved", not by materialising every row.
     */
    private void cascadeBatchAndFile(Batch batch, String performedBy) {
        long batchTotal = paymentRepository.countByBatch_Id(batch.getId());
        long batchNotApproved = paymentRepository.countByBatch_IdAndStatusNot(batch.getId(), PaymentStatus.APPROVED);
        boolean allApproved = batchTotal > 0 && batchNotApproved == 0;

        if (allApproved && batch.getStatus() != BatchStatus.APPROVED) {
            batch.setStatus(BatchStatus.APPROVED);
            batchRepository.save(batch);
            auditService.log(SetupEntityType.BATCH, batch.getId(), AuditAction.APPROVE, performedBy, "All payments approved - batch approved");
        }

        PaymentFile file = batch.getFile();
        long fileBatchesTotal = batchRepository.countByFile_Id(file.getId());
        long fileBatchesApproved = batchRepository.countByFile_IdAndStatus(file.getId(), BatchStatus.APPROVED);
        boolean allBatchesApproved = fileBatchesTotal > 0 && fileBatchesApproved == fileBatchesTotal;

        if (allBatchesApproved && file.getStatus() != FileStatus.APPROVED && file.getStatus() != FileStatus.RELEASED) {
            file.setStatus(FileStatus.APPROVED);
            paymentFileRepository.save(file);
            auditService.log(SetupEntityType.FILE, file.getId(), AuditAction.APPROVE, performedBy, "All batches approved - file approved");
            backOfficeService.releaseIfFullyApproved(file, performedBy);
        }
    }
}
