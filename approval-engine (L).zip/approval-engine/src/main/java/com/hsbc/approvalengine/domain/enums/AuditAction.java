package com.hsbc.approvalengine.domain.enums;

public enum AuditAction {
    CREATE,
    UPDATE,
    DELETE,
    SUBMIT_FOR_APPROVAL,
    APPROVE,
    REJECT,
    CAPTURE_APPROVAL,
    RELEASE_TO_BACK_OFFICE,
    BACK_OFFICE_ACK,
    EXCEPTION
}
