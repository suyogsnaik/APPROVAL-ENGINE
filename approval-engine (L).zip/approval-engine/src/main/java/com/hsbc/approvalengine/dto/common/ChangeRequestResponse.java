package com.hsbc.approvalengine.dto.common;

import com.hsbc.approvalengine.domain.entity.ChangeRequest;
import com.hsbc.approvalengine.domain.enums.ChangeAction;
import com.hsbc.approvalengine.domain.enums.ChangeRequestStatus;
import com.hsbc.approvalengine.domain.enums.SetupEntityType;

import java.time.Instant;

public record ChangeRequestResponse(
        String id,
        SetupEntityType entityType,
        String entityId,
        ChangeAction action,
        ChangeRequestStatus status,
        String payload,
        String makerId,
        String checkerId,
        Instant createdAt,
        Instant decidedAt,
        String checkerComment
) {
    public static ChangeRequestResponse from(ChangeRequest cr) {
        return new ChangeRequestResponse(cr.getId(), cr.getEntityType(), cr.getEntityId(), cr.getAction(),
                cr.getStatus(), cr.getPayload(), cr.getMakerId(), cr.getCheckerId(), cr.getCreatedAt(),
                cr.getDecidedAt(), cr.getCheckerComment());
    }
}
