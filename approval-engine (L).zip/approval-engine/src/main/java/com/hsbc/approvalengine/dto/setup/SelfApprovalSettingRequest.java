package com.hsbc.approvalengine.dto.setup;

import jakarta.validation.constraints.NotBlank;

public record SelfApprovalSettingRequest(
        @NotBlank String clientId,
        boolean restrictSelfApproval
) {
}
