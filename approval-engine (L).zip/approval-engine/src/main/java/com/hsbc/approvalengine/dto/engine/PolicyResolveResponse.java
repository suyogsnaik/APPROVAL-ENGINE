package com.hsbc.approvalengine.dto.engine;

import com.hsbc.approvalengine.domain.enums.PolicyType;

import java.util.List;

/** POST /approval/policy/resolve response, per API spec 3.1. */
public record PolicyResolveResponse(
        PolicyType policyType,
        String tier,
        List<RequiredCombination> requiredCombinations
) {
    public record RequiredCombination(String combinationId, String combinationType, List<String> categories, List<String> signGroups) {
    }
}
