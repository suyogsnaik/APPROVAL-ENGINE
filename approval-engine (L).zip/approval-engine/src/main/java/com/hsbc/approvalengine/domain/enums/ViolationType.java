package com.hsbc.approvalengine.domain.enums;

/** Reasons an approval attempt can be rejected by the Entitlement Validator / Sequence Engine. */
public enum ViolationType {
    CATEGORY_MISMATCH,
    SIGN_GROUP_MISMATCH,
    ACCOUNT_NOT_ENTITLED,
    SELF_APPROVAL_BLOCKED,
    SEQUENCE_ORDER,
    ALREADY_APPROVED_BY_USER,
    NO_POLICY_FOUND,
    USER_INACTIVE,
    PAYMENT_NOT_PENDING
}
