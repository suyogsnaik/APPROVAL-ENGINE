package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.AccountPolicy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Collection;
import java.util.List;

public interface AccountPolicyRepository extends JpaRepository<AccountPolicy, String> {
    List<AccountPolicy> findByDebitAccountIdAndActiveTrue(String debitAccountId);
    List<AccountPolicy> findByDebitAccountIdAndTier_IdAndActiveTrue(String debitAccountId, String tierId);

    /** Bulk variant for large-file policy resolution: one query for every Debit Account (Batch) in the file instead of one per line. */
    List<AccountPolicy> findByDebitAccountIdInAndActiveTrue(Collection<String> debitAccountIds);
}
