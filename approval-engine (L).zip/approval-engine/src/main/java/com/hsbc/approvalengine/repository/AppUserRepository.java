package com.hsbc.approvalengine.repository;

import com.hsbc.approvalengine.domain.entity.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppUserRepository extends JpaRepository<AppUser, String> {
    AppUser findByLoginId(String loginId);
}
